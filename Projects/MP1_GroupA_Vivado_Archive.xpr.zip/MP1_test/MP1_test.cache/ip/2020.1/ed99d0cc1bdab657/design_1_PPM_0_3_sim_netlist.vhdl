-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.1 (win64) Build 2902540 Wed May 27 19:54:49 MDT 2020
-- Date        : Sun Feb 23 16:14:10 2025
-- Host        : CO2041-09 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_PPM_0_3_sim_netlist.vhdl
-- Design      : design_1_PPM_0_3
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg484-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_Capture_PPM_simp is
  port (
    PPM_capture_done : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 31 downto 0 );
    \out_channel_2_reg[31]_0\ : out STD_LOGIC_VECTOR ( 31 downto 0 );
    \out_channel_3_reg[31]_0\ : out STD_LOGIC_VECTOR ( 31 downto 0 );
    \out_channel_4_reg[31]_0\ : out STD_LOGIC_VECTOR ( 31 downto 0 );
    \out_channel_5_reg[31]_0\ : out STD_LOGIC_VECTOR ( 31 downto 0 );
    \out_channel_6_reg[31]_0\ : out STD_LOGIC_VECTOR ( 31 downto 0 );
    capture_state_probe : out STD_LOGIC_VECTOR ( 2 downto 0 );
    SR : in STD_LOGIC_VECTOR ( 0 to 0 );
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC;
    PPM_Input : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_Capture_PPM_simp;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_Capture_PPM_simp is
  signal \FSM_onehot_PS[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[2]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[3]_i_1__0_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[0]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[1]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[2]\ : STD_LOGIC;
  signal \channel_counter[0]_i_1_n_0\ : STD_LOGIC;
  signal \channel_counter[1]_i_1_n_0\ : STD_LOGIC;
  signal \channel_counter[2]_i_1_n_0\ : STD_LOGIC;
  signal \channel_counter_reg_n_0_[0]\ : STD_LOGIC;
  signal \channel_counter_reg_n_0_[1]\ : STD_LOGIC;
  signal done : STD_LOGIC;
  signal high_valid : STD_LOGIC;
  signal high_valid_i_2_n_0 : STD_LOGIC;
  signal high_valid_i_3_n_0 : STD_LOGIC;
  signal high_valid_i_4_n_0 : STD_LOGIC;
  signal high_valid_reg_n_0 : STD_LOGIC;
  signal low_valid : STD_LOGIC;
  signal low_valid_i_2_n_0 : STD_LOGIC;
  signal low_valid_i_3_n_0 : STD_LOGIC;
  signal low_valid_i_4_n_0 : STD_LOGIC;
  signal low_valid_reg_n_0 : STD_LOGIC;
  signal \out_channel_1[31]_i_1_n_0\ : STD_LOGIC;
  signal \out_channel_1[31]_i_2_n_0\ : STD_LOGIC;
  signal \out_channel_2[31]_i_1_n_0\ : STD_LOGIC;
  signal \out_channel_3[31]_i_1_n_0\ : STD_LOGIC;
  signal \out_channel_4[31]_i_1_n_0\ : STD_LOGIC;
  signal \out_channel_5[31]_i_1_n_0\ : STD_LOGIC;
  signal \out_channel_6[31]_i_1_n_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 19 downto 1 );
  signal \ppm_shift_reg_n_0_[19]\ : STD_LOGIC;
  signal send_output : STD_LOGIC;
  signal state : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \state[0]_i_1_n_0\ : STD_LOGIC;
  signal \state[1]_i_1_n_0\ : STD_LOGIC;
  signal \state[2]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output[0]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output[0]_i_3_n_0\ : STD_LOGIC;
  signal temp_output_reg : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \temp_output_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \temp_output_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \temp_output_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \temp_output_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \temp_output_reg[0]_i_2_n_4\ : STD_LOGIC;
  signal \temp_output_reg[0]_i_2_n_5\ : STD_LOGIC;
  signal \temp_output_reg[0]_i_2_n_6\ : STD_LOGIC;
  signal \temp_output_reg[0]_i_2_n_7\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_4\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_5\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_6\ : STD_LOGIC;
  signal \temp_output_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_1\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_2\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_3\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_4\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_5\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_6\ : STD_LOGIC;
  signal \temp_output_reg[16]_i_1_n_7\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_1\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_2\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_3\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_4\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_5\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_6\ : STD_LOGIC;
  signal \temp_output_reg[20]_i_1_n_7\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_1\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_2\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_3\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_4\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_5\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_6\ : STD_LOGIC;
  signal \temp_output_reg[24]_i_1_n_7\ : STD_LOGIC;
  signal \temp_output_reg[28]_i_1_n_1\ : STD_LOGIC;
  signal \temp_output_reg[28]_i_1_n_2\ : STD_LOGIC;
  signal \temp_output_reg[28]_i_1_n_3\ : STD_LOGIC;
  signal \temp_output_reg[28]_i_1_n_4\ : STD_LOGIC;
  signal \temp_output_reg[28]_i_1_n_5\ : STD_LOGIC;
  signal \temp_output_reg[28]_i_1_n_6\ : STD_LOGIC;
  signal \temp_output_reg[28]_i_1_n_7\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \temp_output_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \temp_output_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal \NLW_temp_output_reg[28]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[0]\ : label is "interchannel:0010,idle:0001,measure:0100,store:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[1]\ : label is "interchannel:0010,idle:0001,measure:0100,store:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[2]\ : label is "interchannel:0010,idle:0001,measure:0100,store:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[3]\ : label is "interchannel:0010,idle:0001,measure:0100,store:1000";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of probe_done_i_1 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \state[0]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \state[1]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \state[2]_i_1\ : label is "soft_lutpair0";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \temp_output_reg[0]_i_2\ : label is 11;
  attribute ADDER_THRESHOLD of \temp_output_reg[12]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \temp_output_reg[16]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \temp_output_reg[20]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \temp_output_reg[24]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \temp_output_reg[28]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \temp_output_reg[4]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \temp_output_reg[8]_i_1\ : label is 11;
begin
\FSM_onehot_PS[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000FFFF80008000"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[1]\,
      I1 => high_valid_reg_n_0,
      I2 => p_0_in,
      I3 => \channel_counter_reg_n_0_[1]\,
      I4 => low_valid_reg_n_0,
      I5 => \FSM_onehot_PS_reg_n_0_[0]\,
      O => \FSM_onehot_PS[0]_i_1_n_0\
    );
\FSM_onehot_PS[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF88F8"
    )
        port map (
      I0 => low_valid_reg_n_0,
      I1 => \FSM_onehot_PS_reg_n_0_[0]\,
      I2 => \FSM_onehot_PS_reg_n_0_[1]\,
      I3 => high_valid_reg_n_0,
      I4 => send_output,
      O => \FSM_onehot_PS[1]_i_1_n_0\
    );
\FSM_onehot_PS[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0888FFFF08880888"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[1]\,
      I1 => high_valid_reg_n_0,
      I2 => p_0_in,
      I3 => \channel_counter_reg_n_0_[1]\,
      I4 => low_valid_reg_n_0,
      I5 => \FSM_onehot_PS_reg_n_0_[2]\,
      O => \FSM_onehot_PS[2]_i_1_n_0\
    );
\FSM_onehot_PS[3]_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[2]\,
      I1 => low_valid_reg_n_0,
      O => \FSM_onehot_PS[3]_i_1__0_n_0\
    );
\FSM_onehot_PS_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[0]_i_1_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[0]\,
      S => SR(0)
    );
\FSM_onehot_PS_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[1]_i_1_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[1]\,
      R => SR(0)
    );
\FSM_onehot_PS_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[2]_i_1_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[2]\,
      R => SR(0)
    );
\FSM_onehot_PS_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[3]_i_1__0_n_0\,
      Q => send_output,
      R => SR(0)
    );
\channel_counter[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0444888888888888"
    )
        port map (
      I0 => \channel_counter_reg_n_0_[0]\,
      I1 => s00_axi_aresetn,
      I2 => \channel_counter_reg_n_0_[1]\,
      I3 => p_0_in,
      I4 => high_valid_reg_n_0,
      I5 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \channel_counter[0]_i_1_n_0\
    );
\channel_counter[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0848C0C0C0C0C0C0"
    )
        port map (
      I0 => \channel_counter_reg_n_0_[0]\,
      I1 => s00_axi_aresetn,
      I2 => \channel_counter_reg_n_0_[1]\,
      I3 => p_0_in,
      I4 => high_valid_reg_n_0,
      I5 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \channel_counter[1]_i_1_n_0\
    );
\channel_counter[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0C80CC00CC00CC00"
    )
        port map (
      I0 => \channel_counter_reg_n_0_[0]\,
      I1 => s00_axi_aresetn,
      I2 => \channel_counter_reg_n_0_[1]\,
      I3 => p_0_in,
      I4 => high_valid_reg_n_0,
      I5 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \channel_counter[2]_i_1_n_0\
    );
\channel_counter_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \channel_counter[0]_i_1_n_0\,
      Q => \channel_counter_reg_n_0_[0]\,
      R => '0'
    );
\channel_counter_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \channel_counter[1]_i_1_n_0\,
      Q => \channel_counter_reg_n_0_[1]\,
      R => '0'
    );
\channel_counter_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \channel_counter[2]_i_1_n_0\,
      Q => p_0_in,
      R => '0'
    );
high_valid_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => high_valid_i_2_n_0,
      I1 => high_valid_i_3_n_0,
      I2 => high_valid_i_4_n_0,
      I3 => p_1_in(1),
      I4 => p_1_in(2),
      O => high_valid
    );
high_valid_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => p_1_in(17),
      I1 => p_1_in(18),
      I2 => p_1_in(15),
      I3 => p_1_in(16),
      I4 => \ppm_shift_reg_n_0_[19]\,
      I5 => p_1_in(19),
      O => high_valid_i_2_n_0
    );
high_valid_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => p_1_in(5),
      I1 => p_1_in(6),
      I2 => p_1_in(3),
      I3 => p_1_in(4),
      I4 => p_1_in(8),
      I5 => p_1_in(7),
      O => high_valid_i_3_n_0
    );
high_valid_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => p_1_in(11),
      I1 => p_1_in(12),
      I2 => p_1_in(9),
      I3 => p_1_in(10),
      I4 => p_1_in(14),
      I5 => p_1_in(13),
      O => high_valid_i_4_n_0
    );
high_valid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => high_valid,
      Q => high_valid_reg_n_0,
      R => SR(0)
    );
low_valid_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => low_valid_i_2_n_0,
      I1 => low_valid_i_3_n_0,
      I2 => low_valid_i_4_n_0,
      I3 => p_1_in(1),
      I4 => p_1_in(2),
      O => low_valid
    );
low_valid_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => p_1_in(17),
      I1 => p_1_in(18),
      I2 => p_1_in(15),
      I3 => p_1_in(16),
      I4 => \ppm_shift_reg_n_0_[19]\,
      I5 => p_1_in(19),
      O => low_valid_i_2_n_0
    );
low_valid_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => p_1_in(5),
      I1 => p_1_in(6),
      I2 => p_1_in(3),
      I3 => p_1_in(4),
      I4 => p_1_in(8),
      I5 => p_1_in(7),
      O => low_valid_i_3_n_0
    );
low_valid_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => p_1_in(11),
      I1 => p_1_in(12),
      I2 => p_1_in(9),
      I3 => p_1_in(10),
      I4 => p_1_in(14),
      I5 => p_1_in(13),
      O => low_valid_i_4_n_0
    );
low_valid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => low_valid,
      Q => low_valid_reg_n_0,
      R => SR(0)
    );
\out_channel_1[31]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0004FFFF"
    )
        port map (
      I0 => p_0_in,
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \channel_counter_reg_n_0_[1]\,
      I3 => \channel_counter_reg_n_0_[0]\,
      I4 => s00_axi_aresetn,
      O => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1[31]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => \channel_counter_reg_n_0_[1]\,
      I1 => \channel_counter_reg_n_0_[0]\,
      I2 => p_0_in,
      I3 => send_output,
      O => \out_channel_1[31]_i_2_n_0\
    );
\out_channel_1_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(0),
      Q => Q(0),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(10),
      Q => Q(10),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(11),
      Q => Q(11),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(12),
      Q => Q(12),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(13),
      Q => Q(13),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(14),
      Q => Q(14),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(15),
      Q => Q(15),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(16),
      Q => Q(16),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(17),
      Q => Q(17),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(18),
      Q => Q(18),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(19),
      Q => Q(19),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(1),
      Q => Q(1),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(20),
      Q => Q(20),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(21),
      Q => Q(21),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(22),
      Q => Q(22),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(23),
      Q => Q(23),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(24),
      Q => Q(24),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(25),
      Q => Q(25),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(26),
      Q => Q(26),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(27),
      Q => Q(27),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(28),
      Q => Q(28),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(29),
      Q => Q(29),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(2),
      Q => Q(2),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(30),
      Q => Q(30),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(31),
      Q => Q(31),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(3),
      Q => Q(3),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(4),
      Q => Q(4),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(5),
      Q => Q(5),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(6),
      Q => Q(6),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(7),
      Q => Q(7),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(8),
      Q => Q(8),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_1_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_1[31]_i_2_n_0\,
      D => temp_output_reg(9),
      Q => Q(9),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => p_0_in,
      I1 => send_output,
      I2 => \channel_counter_reg_n_0_[0]\,
      I3 => \channel_counter_reg_n_0_[1]\,
      O => \out_channel_2[31]_i_1_n_0\
    );
\out_channel_2_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(0),
      Q => \out_channel_2_reg[31]_0\(0),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(10),
      Q => \out_channel_2_reg[31]_0\(10),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(11),
      Q => \out_channel_2_reg[31]_0\(11),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(12),
      Q => \out_channel_2_reg[31]_0\(12),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(13),
      Q => \out_channel_2_reg[31]_0\(13),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(14),
      Q => \out_channel_2_reg[31]_0\(14),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(15),
      Q => \out_channel_2_reg[31]_0\(15),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(16),
      Q => \out_channel_2_reg[31]_0\(16),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(17),
      Q => \out_channel_2_reg[31]_0\(17),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(18),
      Q => \out_channel_2_reg[31]_0\(18),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(19),
      Q => \out_channel_2_reg[31]_0\(19),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(1),
      Q => \out_channel_2_reg[31]_0\(1),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(20),
      Q => \out_channel_2_reg[31]_0\(20),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(21),
      Q => \out_channel_2_reg[31]_0\(21),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(22),
      Q => \out_channel_2_reg[31]_0\(22),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(23),
      Q => \out_channel_2_reg[31]_0\(23),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(24),
      Q => \out_channel_2_reg[31]_0\(24),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(25),
      Q => \out_channel_2_reg[31]_0\(25),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(26),
      Q => \out_channel_2_reg[31]_0\(26),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(27),
      Q => \out_channel_2_reg[31]_0\(27),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(28),
      Q => \out_channel_2_reg[31]_0\(28),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(29),
      Q => \out_channel_2_reg[31]_0\(29),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(2),
      Q => \out_channel_2_reg[31]_0\(2),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(30),
      Q => \out_channel_2_reg[31]_0\(30),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(31),
      Q => \out_channel_2_reg[31]_0\(31),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(3),
      Q => \out_channel_2_reg[31]_0\(3),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(4),
      Q => \out_channel_2_reg[31]_0\(4),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(5),
      Q => \out_channel_2_reg[31]_0\(5),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(6),
      Q => \out_channel_2_reg[31]_0\(6),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(7),
      Q => \out_channel_2_reg[31]_0\(7),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(8),
      Q => \out_channel_2_reg[31]_0\(8),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_2_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_2[31]_i_1_n_0\,
      D => temp_output_reg(9),
      Q => \out_channel_2_reg[31]_0\(9),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => p_0_in,
      I1 => send_output,
      I2 => \channel_counter_reg_n_0_[0]\,
      I3 => \channel_counter_reg_n_0_[1]\,
      O => \out_channel_3[31]_i_1_n_0\
    );
\out_channel_3_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(0),
      Q => \out_channel_3_reg[31]_0\(0),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(10),
      Q => \out_channel_3_reg[31]_0\(10),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(11),
      Q => \out_channel_3_reg[31]_0\(11),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(12),
      Q => \out_channel_3_reg[31]_0\(12),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(13),
      Q => \out_channel_3_reg[31]_0\(13),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(14),
      Q => \out_channel_3_reg[31]_0\(14),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(15),
      Q => \out_channel_3_reg[31]_0\(15),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(16),
      Q => \out_channel_3_reg[31]_0\(16),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(17),
      Q => \out_channel_3_reg[31]_0\(17),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(18),
      Q => \out_channel_3_reg[31]_0\(18),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(19),
      Q => \out_channel_3_reg[31]_0\(19),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(1),
      Q => \out_channel_3_reg[31]_0\(1),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(20),
      Q => \out_channel_3_reg[31]_0\(20),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(21),
      Q => \out_channel_3_reg[31]_0\(21),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(22),
      Q => \out_channel_3_reg[31]_0\(22),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(23),
      Q => \out_channel_3_reg[31]_0\(23),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(24),
      Q => \out_channel_3_reg[31]_0\(24),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(25),
      Q => \out_channel_3_reg[31]_0\(25),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(26),
      Q => \out_channel_3_reg[31]_0\(26),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(27),
      Q => \out_channel_3_reg[31]_0\(27),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(28),
      Q => \out_channel_3_reg[31]_0\(28),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(29),
      Q => \out_channel_3_reg[31]_0\(29),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(2),
      Q => \out_channel_3_reg[31]_0\(2),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(30),
      Q => \out_channel_3_reg[31]_0\(30),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(31),
      Q => \out_channel_3_reg[31]_0\(31),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(3),
      Q => \out_channel_3_reg[31]_0\(3),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(4),
      Q => \out_channel_3_reg[31]_0\(4),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(5),
      Q => \out_channel_3_reg[31]_0\(5),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(6),
      Q => \out_channel_3_reg[31]_0\(6),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(7),
      Q => \out_channel_3_reg[31]_0\(7),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(8),
      Q => \out_channel_3_reg[31]_0\(8),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_3_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_3[31]_i_1_n_0\,
      D => temp_output_reg(9),
      Q => \out_channel_3_reg[31]_0\(9),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1000"
    )
        port map (
      I0 => \channel_counter_reg_n_0_[0]\,
      I1 => \channel_counter_reg_n_0_[1]\,
      I2 => p_0_in,
      I3 => send_output,
      O => \out_channel_4[31]_i_1_n_0\
    );
\out_channel_4_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(0),
      Q => \out_channel_4_reg[31]_0\(0),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(10),
      Q => \out_channel_4_reg[31]_0\(10),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(11),
      Q => \out_channel_4_reg[31]_0\(11),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(12),
      Q => \out_channel_4_reg[31]_0\(12),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(13),
      Q => \out_channel_4_reg[31]_0\(13),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(14),
      Q => \out_channel_4_reg[31]_0\(14),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(15),
      Q => \out_channel_4_reg[31]_0\(15),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(16),
      Q => \out_channel_4_reg[31]_0\(16),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(17),
      Q => \out_channel_4_reg[31]_0\(17),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(18),
      Q => \out_channel_4_reg[31]_0\(18),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(19),
      Q => \out_channel_4_reg[31]_0\(19),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(1),
      Q => \out_channel_4_reg[31]_0\(1),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(20),
      Q => \out_channel_4_reg[31]_0\(20),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(21),
      Q => \out_channel_4_reg[31]_0\(21),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(22),
      Q => \out_channel_4_reg[31]_0\(22),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(23),
      Q => \out_channel_4_reg[31]_0\(23),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(24),
      Q => \out_channel_4_reg[31]_0\(24),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(25),
      Q => \out_channel_4_reg[31]_0\(25),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(26),
      Q => \out_channel_4_reg[31]_0\(26),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(27),
      Q => \out_channel_4_reg[31]_0\(27),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(28),
      Q => \out_channel_4_reg[31]_0\(28),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(29),
      Q => \out_channel_4_reg[31]_0\(29),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(2),
      Q => \out_channel_4_reg[31]_0\(2),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(30),
      Q => \out_channel_4_reg[31]_0\(30),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(31),
      Q => \out_channel_4_reg[31]_0\(31),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(3),
      Q => \out_channel_4_reg[31]_0\(3),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(4),
      Q => \out_channel_4_reg[31]_0\(4),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(5),
      Q => \out_channel_4_reg[31]_0\(5),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(6),
      Q => \out_channel_4_reg[31]_0\(6),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(7),
      Q => \out_channel_4_reg[31]_0\(7),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(8),
      Q => \out_channel_4_reg[31]_0\(8),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_4_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_4[31]_i_1_n_0\,
      D => temp_output_reg(9),
      Q => \out_channel_4_reg[31]_0\(9),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \channel_counter_reg_n_0_[1]\,
      I1 => \channel_counter_reg_n_0_[0]\,
      I2 => p_0_in,
      I3 => send_output,
      O => \out_channel_5[31]_i_1_n_0\
    );
\out_channel_5_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(0),
      Q => \out_channel_5_reg[31]_0\(0),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(10),
      Q => \out_channel_5_reg[31]_0\(10),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(11),
      Q => \out_channel_5_reg[31]_0\(11),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(12),
      Q => \out_channel_5_reg[31]_0\(12),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(13),
      Q => \out_channel_5_reg[31]_0\(13),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(14),
      Q => \out_channel_5_reg[31]_0\(14),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(15),
      Q => \out_channel_5_reg[31]_0\(15),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(16),
      Q => \out_channel_5_reg[31]_0\(16),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(17),
      Q => \out_channel_5_reg[31]_0\(17),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(18),
      Q => \out_channel_5_reg[31]_0\(18),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(19),
      Q => \out_channel_5_reg[31]_0\(19),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(1),
      Q => \out_channel_5_reg[31]_0\(1),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(20),
      Q => \out_channel_5_reg[31]_0\(20),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(21),
      Q => \out_channel_5_reg[31]_0\(21),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(22),
      Q => \out_channel_5_reg[31]_0\(22),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(23),
      Q => \out_channel_5_reg[31]_0\(23),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(24),
      Q => \out_channel_5_reg[31]_0\(24),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(25),
      Q => \out_channel_5_reg[31]_0\(25),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(26),
      Q => \out_channel_5_reg[31]_0\(26),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(27),
      Q => \out_channel_5_reg[31]_0\(27),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(28),
      Q => \out_channel_5_reg[31]_0\(28),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(29),
      Q => \out_channel_5_reg[31]_0\(29),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(2),
      Q => \out_channel_5_reg[31]_0\(2),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(30),
      Q => \out_channel_5_reg[31]_0\(30),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(31),
      Q => \out_channel_5_reg[31]_0\(31),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(3),
      Q => \out_channel_5_reg[31]_0\(3),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(4),
      Q => \out_channel_5_reg[31]_0\(4),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(5),
      Q => \out_channel_5_reg[31]_0\(5),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(6),
      Q => \out_channel_5_reg[31]_0\(6),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(7),
      Q => \out_channel_5_reg[31]_0\(7),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(8),
      Q => \out_channel_5_reg[31]_0\(8),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_5_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_5[31]_i_1_n_0\,
      D => temp_output_reg(9),
      Q => \out_channel_5_reg[31]_0\(9),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6[31]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \channel_counter_reg_n_0_[0]\,
      I1 => \channel_counter_reg_n_0_[1]\,
      I2 => p_0_in,
      I3 => send_output,
      O => \out_channel_6[31]_i_1_n_0\
    );
\out_channel_6_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(0),
      Q => \out_channel_6_reg[31]_0\(0),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(10),
      Q => \out_channel_6_reg[31]_0\(10),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(11),
      Q => \out_channel_6_reg[31]_0\(11),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(12),
      Q => \out_channel_6_reg[31]_0\(12),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(13),
      Q => \out_channel_6_reg[31]_0\(13),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(14),
      Q => \out_channel_6_reg[31]_0\(14),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(15),
      Q => \out_channel_6_reg[31]_0\(15),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(16),
      Q => \out_channel_6_reg[31]_0\(16),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(17),
      Q => \out_channel_6_reg[31]_0\(17),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(18),
      Q => \out_channel_6_reg[31]_0\(18),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(19),
      Q => \out_channel_6_reg[31]_0\(19),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(1),
      Q => \out_channel_6_reg[31]_0\(1),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(20),
      Q => \out_channel_6_reg[31]_0\(20),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(21),
      Q => \out_channel_6_reg[31]_0\(21),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(22),
      Q => \out_channel_6_reg[31]_0\(22),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(23),
      Q => \out_channel_6_reg[31]_0\(23),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(24),
      Q => \out_channel_6_reg[31]_0\(24),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(25),
      Q => \out_channel_6_reg[31]_0\(25),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(26),
      Q => \out_channel_6_reg[31]_0\(26),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(27),
      Q => \out_channel_6_reg[31]_0\(27),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(28),
      Q => \out_channel_6_reg[31]_0\(28),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(29),
      Q => \out_channel_6_reg[31]_0\(29),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(2),
      Q => \out_channel_6_reg[31]_0\(2),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(30),
      Q => \out_channel_6_reg[31]_0\(30),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(31),
      Q => \out_channel_6_reg[31]_0\(31),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(3),
      Q => \out_channel_6_reg[31]_0\(3),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(4),
      Q => \out_channel_6_reg[31]_0\(4),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(5),
      Q => \out_channel_6_reg[31]_0\(5),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(6),
      Q => \out_channel_6_reg[31]_0\(6),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(7),
      Q => \out_channel_6_reg[31]_0\(7),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(8),
      Q => \out_channel_6_reg[31]_0\(8),
      R => \out_channel_1[31]_i_1_n_0\
    );
\out_channel_6_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \out_channel_6[31]_i_1_n_0\,
      D => temp_output_reg(9),
      Q => \out_channel_6_reg[31]_0\(9),
      R => \out_channel_1[31]_i_1_n_0\
    );
\ppm_shift_reg[0]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => PPM_Input,
      Q => p_1_in(1),
      S => SR(0)
    );
\ppm_shift_reg[10]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(10),
      Q => p_1_in(11),
      S => SR(0)
    );
\ppm_shift_reg[11]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(11),
      Q => p_1_in(12),
      S => SR(0)
    );
\ppm_shift_reg[12]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(12),
      Q => p_1_in(13),
      S => SR(0)
    );
\ppm_shift_reg[13]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(13),
      Q => p_1_in(14),
      S => SR(0)
    );
\ppm_shift_reg[14]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(14),
      Q => p_1_in(15),
      S => SR(0)
    );
\ppm_shift_reg[15]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(15),
      Q => p_1_in(16),
      S => SR(0)
    );
\ppm_shift_reg[16]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(16),
      Q => p_1_in(17),
      S => SR(0)
    );
\ppm_shift_reg[17]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(17),
      Q => p_1_in(18),
      S => SR(0)
    );
\ppm_shift_reg[18]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(18),
      Q => p_1_in(19),
      S => SR(0)
    );
\ppm_shift_reg[19]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(19),
      Q => \ppm_shift_reg_n_0_[19]\,
      S => SR(0)
    );
\ppm_shift_reg[1]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(1),
      Q => p_1_in(2),
      S => SR(0)
    );
\ppm_shift_reg[2]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(2),
      Q => p_1_in(3),
      S => SR(0)
    );
\ppm_shift_reg[3]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(3),
      Q => p_1_in(4),
      S => SR(0)
    );
\ppm_shift_reg[4]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(4),
      Q => p_1_in(5),
      S => SR(0)
    );
\ppm_shift_reg[5]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(5),
      Q => p_1_in(6),
      S => SR(0)
    );
\ppm_shift_reg[6]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(6),
      Q => p_1_in(7),
      S => SR(0)
    );
\ppm_shift_reg[7]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(7),
      Q => p_1_in(8),
      S => SR(0)
    );
\ppm_shift_reg[8]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(8),
      Q => p_1_in(9),
      S => SR(0)
    );
\ppm_shift_reg[9]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => p_1_in(9),
      Q => p_1_in(10),
      S => SR(0)
    );
probe_done_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[0]\,
      I1 => low_valid_reg_n_0,
      O => done
    );
probe_done_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => done,
      Q => PPM_capture_done,
      R => '0'
    );
\probe_state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => state(0),
      Q => capture_state_probe(0),
      R => '0'
    );
\probe_state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => state(1),
      Q => capture_state_probe(1),
      R => '0'
    );
\probe_state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => state(2),
      Q => capture_state_probe(2),
      R => '0'
    );
\state[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[2]\,
      I1 => \FSM_onehot_PS_reg_n_0_[0]\,
      O => \state[0]_i_1_n_0\
    );
\state[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"0E"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[1]\,
      I1 => \FSM_onehot_PS_reg_n_0_[2]\,
      I2 => \FSM_onehot_PS_reg_n_0_[0]\,
      O => \state[1]_i_1_n_0\
    );
\state[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[2]\,
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => send_output,
      I3 => \FSM_onehot_PS_reg_n_0_[0]\,
      O => \state[2]_i_1_n_0\
    );
\state_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \state[0]_i_1_n_0\,
      Q => state(0),
      R => '0'
    );
\state_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \state[1]_i_1_n_0\,
      Q => state(1),
      R => '0'
    );
\state_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \state[2]_i_1_n_0\,
      Q => state(2),
      R => '0'
    );
\temp_output[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => send_output,
      I1 => s00_axi_aresetn,
      O => \temp_output[0]_i_1_n_0\
    );
\temp_output[0]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => temp_output_reg(0),
      O => \temp_output[0]_i_3_n_0\
    );
\temp_output_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[0]_i_2_n_7\,
      Q => temp_output_reg(0),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \temp_output_reg[0]_i_2_n_0\,
      CO(2) => \temp_output_reg[0]_i_2_n_1\,
      CO(1) => \temp_output_reg[0]_i_2_n_2\,
      CO(0) => \temp_output_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \temp_output_reg[0]_i_2_n_4\,
      O(2) => \temp_output_reg[0]_i_2_n_5\,
      O(1) => \temp_output_reg[0]_i_2_n_6\,
      O(0) => \temp_output_reg[0]_i_2_n_7\,
      S(3 downto 1) => temp_output_reg(3 downto 1),
      S(0) => \temp_output[0]_i_3_n_0\
    );
\temp_output_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[8]_i_1_n_5\,
      Q => temp_output_reg(10),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[8]_i_1_n_4\,
      Q => temp_output_reg(11),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[12]_i_1_n_7\,
      Q => temp_output_reg(12),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \temp_output_reg[8]_i_1_n_0\,
      CO(3) => \temp_output_reg[12]_i_1_n_0\,
      CO(2) => \temp_output_reg[12]_i_1_n_1\,
      CO(1) => \temp_output_reg[12]_i_1_n_2\,
      CO(0) => \temp_output_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \temp_output_reg[12]_i_1_n_4\,
      O(2) => \temp_output_reg[12]_i_1_n_5\,
      O(1) => \temp_output_reg[12]_i_1_n_6\,
      O(0) => \temp_output_reg[12]_i_1_n_7\,
      S(3 downto 0) => temp_output_reg(15 downto 12)
    );
\temp_output_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[12]_i_1_n_6\,
      Q => temp_output_reg(13),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[12]_i_1_n_5\,
      Q => temp_output_reg(14),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[12]_i_1_n_4\,
      Q => temp_output_reg(15),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[16]_i_1_n_7\,
      Q => temp_output_reg(16),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[16]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \temp_output_reg[12]_i_1_n_0\,
      CO(3) => \temp_output_reg[16]_i_1_n_0\,
      CO(2) => \temp_output_reg[16]_i_1_n_1\,
      CO(1) => \temp_output_reg[16]_i_1_n_2\,
      CO(0) => \temp_output_reg[16]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \temp_output_reg[16]_i_1_n_4\,
      O(2) => \temp_output_reg[16]_i_1_n_5\,
      O(1) => \temp_output_reg[16]_i_1_n_6\,
      O(0) => \temp_output_reg[16]_i_1_n_7\,
      S(3 downto 0) => temp_output_reg(19 downto 16)
    );
\temp_output_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[16]_i_1_n_6\,
      Q => temp_output_reg(17),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[16]_i_1_n_5\,
      Q => temp_output_reg(18),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[16]_i_1_n_4\,
      Q => temp_output_reg(19),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[0]_i_2_n_6\,
      Q => temp_output_reg(1),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[20]_i_1_n_7\,
      Q => temp_output_reg(20),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[20]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \temp_output_reg[16]_i_1_n_0\,
      CO(3) => \temp_output_reg[20]_i_1_n_0\,
      CO(2) => \temp_output_reg[20]_i_1_n_1\,
      CO(1) => \temp_output_reg[20]_i_1_n_2\,
      CO(0) => \temp_output_reg[20]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \temp_output_reg[20]_i_1_n_4\,
      O(2) => \temp_output_reg[20]_i_1_n_5\,
      O(1) => \temp_output_reg[20]_i_1_n_6\,
      O(0) => \temp_output_reg[20]_i_1_n_7\,
      S(3 downto 0) => temp_output_reg(23 downto 20)
    );
\temp_output_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[20]_i_1_n_6\,
      Q => temp_output_reg(21),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[20]_i_1_n_5\,
      Q => temp_output_reg(22),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[20]_i_1_n_4\,
      Q => temp_output_reg(23),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[24]_i_1_n_7\,
      Q => temp_output_reg(24),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[24]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \temp_output_reg[20]_i_1_n_0\,
      CO(3) => \temp_output_reg[24]_i_1_n_0\,
      CO(2) => \temp_output_reg[24]_i_1_n_1\,
      CO(1) => \temp_output_reg[24]_i_1_n_2\,
      CO(0) => \temp_output_reg[24]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \temp_output_reg[24]_i_1_n_4\,
      O(2) => \temp_output_reg[24]_i_1_n_5\,
      O(1) => \temp_output_reg[24]_i_1_n_6\,
      O(0) => \temp_output_reg[24]_i_1_n_7\,
      S(3 downto 0) => temp_output_reg(27 downto 24)
    );
\temp_output_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[24]_i_1_n_6\,
      Q => temp_output_reg(25),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[24]_i_1_n_5\,
      Q => temp_output_reg(26),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[24]_i_1_n_4\,
      Q => temp_output_reg(27),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[28]_i_1_n_7\,
      Q => temp_output_reg(28),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[28]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \temp_output_reg[24]_i_1_n_0\,
      CO(3) => \NLW_temp_output_reg[28]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \temp_output_reg[28]_i_1_n_1\,
      CO(1) => \temp_output_reg[28]_i_1_n_2\,
      CO(0) => \temp_output_reg[28]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \temp_output_reg[28]_i_1_n_4\,
      O(2) => \temp_output_reg[28]_i_1_n_5\,
      O(1) => \temp_output_reg[28]_i_1_n_6\,
      O(0) => \temp_output_reg[28]_i_1_n_7\,
      S(3 downto 0) => temp_output_reg(31 downto 28)
    );
\temp_output_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[28]_i_1_n_6\,
      Q => temp_output_reg(29),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[0]_i_2_n_5\,
      Q => temp_output_reg(2),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[28]_i_1_n_5\,
      Q => temp_output_reg(30),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[28]_i_1_n_4\,
      Q => temp_output_reg(31),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[0]_i_2_n_4\,
      Q => temp_output_reg(3),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[4]_i_1_n_7\,
      Q => temp_output_reg(4),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \temp_output_reg[0]_i_2_n_0\,
      CO(3) => \temp_output_reg[4]_i_1_n_0\,
      CO(2) => \temp_output_reg[4]_i_1_n_1\,
      CO(1) => \temp_output_reg[4]_i_1_n_2\,
      CO(0) => \temp_output_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \temp_output_reg[4]_i_1_n_4\,
      O(2) => \temp_output_reg[4]_i_1_n_5\,
      O(1) => \temp_output_reg[4]_i_1_n_6\,
      O(0) => \temp_output_reg[4]_i_1_n_7\,
      S(3 downto 0) => temp_output_reg(7 downto 4)
    );
\temp_output_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[4]_i_1_n_6\,
      Q => temp_output_reg(5),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[4]_i_1_n_5\,
      Q => temp_output_reg(6),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[4]_i_1_n_4\,
      Q => temp_output_reg(7),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[8]_i_1_n_7\,
      Q => temp_output_reg(8),
      R => \temp_output[0]_i_1_n_0\
    );
\temp_output_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \temp_output_reg[4]_i_1_n_0\,
      CO(3) => \temp_output_reg[8]_i_1_n_0\,
      CO(2) => \temp_output_reg[8]_i_1_n_1\,
      CO(1) => \temp_output_reg[8]_i_1_n_2\,
      CO(0) => \temp_output_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \temp_output_reg[8]_i_1_n_4\,
      O(2) => \temp_output_reg[8]_i_1_n_5\,
      O(1) => \temp_output_reg[8]_i_1_n_6\,
      O(0) => \temp_output_reg[8]_i_1_n_7\,
      S(3 downto 0) => temp_output_reg(11 downto 8)
    );
\temp_output_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \FSM_onehot_PS[2]_i_1_n_0\,
      D => \temp_output_reg[8]_i_1_n_6\,
      Q => temp_output_reg(9),
      R => \temp_output[0]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_GeneratePPM is
  port (
    PPM_generator_done : out STD_LOGIC;
    PPM_Output : out STD_LOGIC;
    SR : in STD_LOGIC_VECTOR ( 0 to 0 );
    s00_axi_aclk : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 0 to 0 );
    PPM_Input : in STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC;
    \pulse_widths_reg[0][21]_0\ : in STD_LOGIC_VECTOR ( 21 downto 0 );
    \pulse_widths_reg[1][21]_0\ : in STD_LOGIC_VECTOR ( 21 downto 0 );
    \pulse_widths_reg[2][21]_0\ : in STD_LOGIC_VECTOR ( 21 downto 0 );
    \pulse_widths_reg[3][21]_0\ : in STD_LOGIC_VECTOR ( 21 downto 0 );
    \pulse_widths_reg[4][21]_0\ : in STD_LOGIC_VECTOR ( 21 downto 0 );
    \pulse_widths_reg[5][21]_0\ : in STD_LOGIC_VECTOR ( 21 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_GeneratePPM;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_GeneratePPM is
  signal \FSM_onehot_PS[0]_i_1__0_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[0]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[0]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[1]_i_1__0_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[2]_i_1__0_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[4]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_10_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_5_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_6_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_7_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_8_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[5]_i_9_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS[6]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[0]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[1]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[2]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[3]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[4]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[5]\ : STD_LOGIC;
  signal \FSM_onehot_PS_reg_n_0_[6]\ : STD_LOGIC;
  signal PPM_Done_i_1_n_0 : STD_LOGIC;
  signal PPM_Done_i_2_n_0 : STD_LOGIC;
  signal \^ppm_generator_done\ : STD_LOGIC;
  signal PPM_generator_input : STD_LOGIC;
  signal \channel_index[0]_i_1_n_0\ : STD_LOGIC;
  signal \channel_index[1]_i_1_n_0\ : STD_LOGIC;
  signal \channel_index[2]_i_1_n_0\ : STD_LOGIC;
  signal \channel_index[2]_i_2_n_0\ : STD_LOGIC;
  signal \channel_index_reg_n_0_[0]\ : STD_LOGIC;
  signal \channel_index_reg_n_0_[1]\ : STD_LOGIC;
  signal \channel_index_reg_n_0_[2]\ : STD_LOGIC;
  signal cycle_counter : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \cycle_counter[0]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[10]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[11]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[12]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[13]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[14]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[15]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[16]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[17]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[18]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[19]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[1]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[20]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[21]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[2]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[3]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[4]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[5]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[6]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[7]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[8]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter[9]_i_1_n_0\ : STD_LOGIC;
  signal cycle_counter_total : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \cycle_counter_total[0]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[10]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[11]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[12]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[13]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[14]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[15]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[16]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[17]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[18]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[19]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[1]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[20]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[21]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[21]_i_2_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[2]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[3]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[4]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[5]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[6]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[7]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[8]_i_1_n_0\ : STD_LOGIC;
  signal \cycle_counter_total[9]_i_1_n_0\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry__0_n_0\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry__0_n_1\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry__0_n_2\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry__1_n_1\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry__1_n_2\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry__1_n_3\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \geqOp_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \i__carry__0_i_10_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_11_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_12_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_13_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_14_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_15_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_16_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_17_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_18_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_19_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_20_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_21_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_22_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_23_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_24_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_7_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_8_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_9_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_10_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_11_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_12_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_13_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_14_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_15_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_16_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_17_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_18_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_1_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_2_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_3_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_4_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_7_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_8_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_9_n_0\ : STD_LOGIC;
  signal \i__carry_i_10_n_0\ : STD_LOGIC;
  signal \i__carry_i_11_n_0\ : STD_LOGIC;
  signal \i__carry_i_12_n_0\ : STD_LOGIC;
  signal \i__carry_i_13_n_0\ : STD_LOGIC;
  signal \i__carry_i_14_n_0\ : STD_LOGIC;
  signal \i__carry_i_15_n_0\ : STD_LOGIC;
  signal \i__carry_i_16_n_0\ : STD_LOGIC;
  signal \i__carry_i_17_n_0\ : STD_LOGIC;
  signal \i__carry_i_18_n_0\ : STD_LOGIC;
  signal \i__carry_i_19_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_20_n_0\ : STD_LOGIC;
  signal \i__carry_i_21_n_0\ : STD_LOGIC;
  signal \i__carry_i_22_n_0\ : STD_LOGIC;
  signal \i__carry_i_23_n_0\ : STD_LOGIC;
  signal \i__carry_i_24_n_0\ : STD_LOGIC;
  signal \i__carry_i_25_n_0\ : STD_LOGIC;
  signal \i__carry_i_26_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_4_n_0\ : STD_LOGIC;
  signal \i__carry_i_5_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_0\ : STD_LOGIC;
  signal \i__carry_i_9_n_0\ : STD_LOGIC;
  signal in7 : STD_LOGIC_VECTOR ( 21 downto 1 );
  signal in8 : STD_LOGIC_VECTOR ( 21 downto 1 );
  signal minusOp : STD_LOGIC_VECTOR ( 21 downto 5 );
  signal \minusOp_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \minusOp_carry__0_n_0\ : STD_LOGIC;
  signal \minusOp_carry__0_n_1\ : STD_LOGIC;
  signal \minusOp_carry__0_n_2\ : STD_LOGIC;
  signal \minusOp_carry__0_n_3\ : STD_LOGIC;
  signal \minusOp_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \minusOp_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \minusOp_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \minusOp_carry__1_n_0\ : STD_LOGIC;
  signal \minusOp_carry__1_n_1\ : STD_LOGIC;
  signal \minusOp_carry__1_n_2\ : STD_LOGIC;
  signal \minusOp_carry__1_n_3\ : STD_LOGIC;
  signal \minusOp_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \minusOp_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \minusOp_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \minusOp_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \minusOp_carry__2_n_0\ : STD_LOGIC;
  signal \minusOp_carry__2_n_1\ : STD_LOGIC;
  signal \minusOp_carry__2_n_2\ : STD_LOGIC;
  signal \minusOp_carry__2_n_3\ : STD_LOGIC;
  signal \minusOp_carry__3_i_1_n_0\ : STD_LOGIC;
  signal minusOp_carry_i_1_n_0 : STD_LOGIC;
  signal minusOp_carry_i_2_n_0 : STD_LOGIC;
  signal minusOp_carry_i_3_n_0 : STD_LOGIC;
  signal minusOp_carry_n_0 : STD_LOGIC;
  signal minusOp_carry_n_1 : STD_LOGIC;
  signal minusOp_carry_n_2 : STD_LOGIC;
  signal minusOp_carry_n_3 : STD_LOGIC;
  signal \plusOp_carry__0_n_0\ : STD_LOGIC;
  signal \plusOp_carry__0_n_1\ : STD_LOGIC;
  signal \plusOp_carry__0_n_2\ : STD_LOGIC;
  signal \plusOp_carry__0_n_3\ : STD_LOGIC;
  signal \plusOp_carry__1_n_0\ : STD_LOGIC;
  signal \plusOp_carry__1_n_1\ : STD_LOGIC;
  signal \plusOp_carry__1_n_2\ : STD_LOGIC;
  signal \plusOp_carry__1_n_3\ : STD_LOGIC;
  signal \plusOp_carry__2_n_0\ : STD_LOGIC;
  signal \plusOp_carry__2_n_1\ : STD_LOGIC;
  signal \plusOp_carry__2_n_2\ : STD_LOGIC;
  signal \plusOp_carry__2_n_3\ : STD_LOGIC;
  signal \plusOp_carry__3_n_0\ : STD_LOGIC;
  signal \plusOp_carry__3_n_1\ : STD_LOGIC;
  signal \plusOp_carry__3_n_2\ : STD_LOGIC;
  signal \plusOp_carry__3_n_3\ : STD_LOGIC;
  signal plusOp_carry_n_0 : STD_LOGIC;
  signal plusOp_carry_n_1 : STD_LOGIC;
  signal plusOp_carry_n_2 : STD_LOGIC;
  signal plusOp_carry_n_3 : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__0_n_0\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__0_n_1\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__0_n_2\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__1_n_0\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__1_n_1\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__1_n_2\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__1_n_3\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__2_n_0\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__2_n_1\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__2_n_2\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__2_n_3\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__3_n_0\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__3_n_1\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__3_n_2\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry__3_n_3\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \plusOp_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \pulse_widths_reg[0]_0\ : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \pulse_widths_reg[1]_1\ : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \pulse_widths_reg[2]_2\ : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \pulse_widths_reg[3]_3\ : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \pulse_widths_reg[4]_4\ : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal \pulse_widths_reg[5]_5\ : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal sw_PPM_Output_i_1_n_0 : STD_LOGIC;
  signal \NLW_geqOp_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_geqOp_inferred__0/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_geqOp_inferred__0/i__carry__1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_geqOp_inferred__0/i__carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_minusOp_carry__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_minusOp_carry__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_plusOp_carry__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_plusOp_carry__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_plusOp_inferred__0/i__carry__4_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_plusOp_inferred__0/i__carry__4_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_PS[0]_i_4\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \FSM_onehot_PS[1]_i_1__0\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \FSM_onehot_PS[3]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \FSM_onehot_PS[6]_i_1\ : label is "soft_lutpair3";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[0]\ : label is "idle:0000001,idle_low_pulse:0010000,idle_pulse:0100000,gap_low:0000010,pulse_high:0000100,next_channel:1000000,frame_complete:0001000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[1]\ : label is "idle:0000001,idle_low_pulse:0010000,idle_pulse:0100000,gap_low:0000010,pulse_high:0000100,next_channel:1000000,frame_complete:0001000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[2]\ : label is "idle:0000001,idle_low_pulse:0010000,idle_pulse:0100000,gap_low:0000010,pulse_high:0000100,next_channel:1000000,frame_complete:0001000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[3]\ : label is "idle:0000001,idle_low_pulse:0010000,idle_pulse:0100000,gap_low:0000010,pulse_high:0000100,next_channel:1000000,frame_complete:0001000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[4]\ : label is "idle:0000001,idle_low_pulse:0010000,idle_pulse:0100000,gap_low:0000010,pulse_high:0000100,next_channel:1000000,frame_complete:0001000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[5]\ : label is "idle:0000001,idle_low_pulse:0010000,idle_pulse:0100000,gap_low:0000010,pulse_high:0000100,next_channel:1000000,frame_complete:0001000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_PS_reg[6]\ : label is "idle:0000001,idle_low_pulse:0010000,idle_pulse:0100000,gap_low:0000010,pulse_high:0000100,next_channel:1000000,frame_complete:0001000";
  attribute SOFT_HLUTNM of PPM_Done_i_2 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \channel_index[0]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \channel_index[2]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \cycle_counter[0]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \cycle_counter[10]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \cycle_counter[11]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \cycle_counter[12]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \cycle_counter[13]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \cycle_counter[14]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cycle_counter[15]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cycle_counter[16]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \cycle_counter[17]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \cycle_counter[18]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \cycle_counter[19]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \cycle_counter[1]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \cycle_counter[20]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \cycle_counter[21]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \cycle_counter[2]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \cycle_counter[3]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \cycle_counter[4]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \cycle_counter[5]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \cycle_counter[6]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \cycle_counter[7]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \cycle_counter[8]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \cycle_counter[9]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \cycle_counter_total[0]_i_1\ : label is "soft_lutpair2";
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of \geqOp_inferred__0/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \geqOp_inferred__0/i__carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \geqOp_inferred__0/i__carry__1\ : label is 11;
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of minusOp_carry : label is 35;
  attribute ADDER_THRESHOLD of \minusOp_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \minusOp_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \minusOp_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \minusOp_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of plusOp_carry : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_inferred__0/i__carry\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_inferred__0/i__carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_inferred__0/i__carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_inferred__0/i__carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_inferred__0/i__carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \plusOp_inferred__0/i__carry__4\ : label is 35;
begin
  PPM_generator_done <= \^ppm_generator_done\;
\FSM_onehot_PS[0]_i_1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFBAA0000"
    )
        port map (
      I0 => cycle_counter_total(21),
      I1 => \FSM_onehot_PS[0]_i_2_n_0\,
      I2 => \FSM_onehot_PS[0]_i_3_n_0\,
      I3 => cycle_counter_total(20),
      I4 => \FSM_onehot_PS_reg_n_0_[5]\,
      I5 => \FSM_onehot_PS[0]_i_4_n_0\,
      O => \FSM_onehot_PS[0]_i_1__0_n_0\
    );
\FSM_onehot_PS[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF11111151"
    )
        port map (
      I0 => \FSM_onehot_PS[5]_i_7_n_0\,
      I1 => cycle_counter_total(12),
      I2 => \FSM_onehot_PS[5]_i_6_n_0\,
      I3 => cycle_counter_total(11),
      I4 => cycle_counter_total(10),
      I5 => \FSM_onehot_PS[5]_i_4_n_0\,
      O => \FSM_onehot_PS[0]_i_2_n_0\
    );
\FSM_onehot_PS[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => cycle_counter_total(19),
      I1 => cycle_counter_total(18),
      O => \FSM_onehot_PS[0]_i_3_n_0\
    );
\FSM_onehot_PS[0]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[0]\,
      I1 => s00_axi_aresetn,
      O => \FSM_onehot_PS[0]_i_4_n_0\
    );
\FSM_onehot_PS[1]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF8"
    )
        port map (
      I0 => \FSM_onehot_PS[5]_i_3_n_0\,
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[0]\,
      I3 => \FSM_onehot_PS_reg_n_0_[6]\,
      O => \FSM_onehot_PS[1]_i_1__0_n_0\
    );
\FSM_onehot_PS[2]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4F44"
    )
        port map (
      I0 => \geqOp_inferred__0/i__carry__1_n_1\,
      I1 => \FSM_onehot_PS_reg_n_0_[2]\,
      I2 => \FSM_onehot_PS[5]_i_3_n_0\,
      I3 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \FSM_onehot_PS[2]_i_1__0_n_0\
    );
\FSM_onehot_PS[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"40000000"
    )
        port map (
      I0 => \channel_index_reg_n_0_[1]\,
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \channel_index_reg_n_0_[2]\,
      I3 => \geqOp_inferred__0/i__carry__1_n_1\,
      I4 => \FSM_onehot_PS_reg_n_0_[2]\,
      O => \FSM_onehot_PS[3]_i_1_n_0\
    );
\FSM_onehot_PS[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EA"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[3]\,
      I1 => \FSM_onehot_PS[5]_i_3_n_0\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \FSM_onehot_PS[4]_i_1_n_0\
    );
\FSM_onehot_PS[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4500FFFF45004500"
    )
        port map (
      I0 => cycle_counter_total(21),
      I1 => \FSM_onehot_PS[5]_i_2_n_0\,
      I2 => cycle_counter_total(20),
      I3 => \FSM_onehot_PS_reg_n_0_[5]\,
      I4 => \FSM_onehot_PS[5]_i_3_n_0\,
      I5 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \FSM_onehot_PS[5]_i_1_n_0\
    );
\FSM_onehot_PS[5]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => cycle_counter(17),
      I1 => cycle_counter(20),
      I2 => cycle_counter(21),
      I3 => cycle_counter(19),
      I4 => cycle_counter(18),
      I5 => cycle_counter(16),
      O => \FSM_onehot_PS[5]_i_10_n_0\
    );
\FSM_onehot_PS[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAABAFF"
    )
        port map (
      I0 => \FSM_onehot_PS[5]_i_4_n_0\,
      I1 => \FSM_onehot_PS[5]_i_5_n_0\,
      I2 => \FSM_onehot_PS[5]_i_6_n_0\,
      I3 => cycle_counter_total(12),
      I4 => \FSM_onehot_PS[5]_i_7_n_0\,
      I5 => \FSM_onehot_PS[0]_i_3_n_0\,
      O => \FSM_onehot_PS[5]_i_2_n_0\
    );
\FSM_onehot_PS[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000EFFFF"
    )
        port map (
      I0 => \FSM_onehot_PS[5]_i_8_n_0\,
      I1 => \FSM_onehot_PS[5]_i_9_n_0\,
      I2 => cycle_counter(13),
      I3 => cycle_counter(14),
      I4 => cycle_counter(15),
      I5 => \FSM_onehot_PS[5]_i_10_n_0\,
      O => \FSM_onehot_PS[5]_i_3_n_0\
    );
\FSM_onehot_PS[5]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => cycle_counter_total(17),
      I1 => cycle_counter_total(16),
      O => \FSM_onehot_PS[5]_i_4_n_0\
    );
\FSM_onehot_PS[5]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => cycle_counter_total(11),
      I1 => cycle_counter_total(10),
      O => \FSM_onehot_PS[5]_i_5_n_0\
    );
\FSM_onehot_PS[5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555555557FFFFFF"
    )
        port map (
      I0 => cycle_counter_total(9),
      I1 => cycle_counter_total(5),
      I2 => cycle_counter_total(4),
      I3 => cycle_counter_total(6),
      I4 => cycle_counter_total(7),
      I5 => cycle_counter_total(8),
      O => \FSM_onehot_PS[5]_i_6_n_0\
    );
\FSM_onehot_PS[5]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => cycle_counter_total(15),
      I1 => cycle_counter_total(13),
      I2 => cycle_counter_total(14),
      O => \FSM_onehot_PS[5]_i_7_n_0\
    );
\FSM_onehot_PS[5]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => cycle_counter(11),
      I1 => cycle_counter(10),
      I2 => cycle_counter(12),
      O => \FSM_onehot_PS[5]_i_8_n_0\
    );
\FSM_onehot_PS[5]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => cycle_counter(8),
      I1 => cycle_counter(9),
      I2 => cycle_counter(6),
      I3 => cycle_counter(7),
      O => \FSM_onehot_PS[5]_i_9_n_0\
    );
\FSM_onehot_PS[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BF000000"
    )
        port map (
      I0 => \channel_index_reg_n_0_[1]\,
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \channel_index_reg_n_0_[2]\,
      I3 => \geqOp_inferred__0/i__carry__1_n_1\,
      I4 => \FSM_onehot_PS_reg_n_0_[2]\,
      O => \FSM_onehot_PS[6]_i_1_n_0\
    );
\FSM_onehot_PS_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[0]_i_1__0_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[0]\,
      S => SR(0)
    );
\FSM_onehot_PS_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[1]_i_1__0_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[1]\,
      R => SR(0)
    );
\FSM_onehot_PS_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[2]_i_1__0_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[2]\,
      R => SR(0)
    );
\FSM_onehot_PS_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[3]_i_1_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[3]\,
      R => SR(0)
    );
\FSM_onehot_PS_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[4]_i_1_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[4]\,
      R => SR(0)
    );
\FSM_onehot_PS_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[5]_i_1_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[5]\,
      R => SR(0)
    );
\FSM_onehot_PS_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \FSM_onehot_PS[6]_i_1_n_0\,
      Q => \FSM_onehot_PS_reg_n_0_[6]\,
      R => SR(0)
    );
PPM_Done_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF01FF00FF00FF00"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[6]\,
      I1 => \FSM_onehot_PS_reg_n_0_[3]\,
      I2 => \FSM_onehot_PS_reg_n_0_[0]\,
      I3 => \FSM_onehot_PS_reg_n_0_[5]\,
      I4 => PPM_Done_i_2_n_0,
      I5 => \^ppm_generator_done\,
      O => PPM_Done_i_1_n_0
    );
PPM_Done_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[4]\,
      I1 => \FSM_onehot_PS_reg_n_0_[2]\,
      I2 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => PPM_Done_i_2_n_0
    );
PPM_Done_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => PPM_Done_i_1_n_0,
      Q => \^ppm_generator_done\,
      R => SR(0)
    );
PPM_Output_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => PPM_generator_input,
      I1 => Q(0),
      I2 => PPM_Input,
      O => PPM_Output
    );
\channel_index[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0001FF00"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[5]\,
      I1 => \FSM_onehot_PS_reg_n_0_[0]\,
      I2 => \FSM_onehot_PS_reg_n_0_[3]\,
      I3 => \FSM_onehot_PS_reg_n_0_[6]\,
      I4 => \channel_index_reg_n_0_[0]\,
      O => \channel_index[0]_i_1_n_0\
    );
\channel_index[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55550003AAAA0000"
    )
        port map (
      I0 => \channel_index_reg_n_0_[0]\,
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[0]\,
      I3 => \FSM_onehot_PS_reg_n_0_[3]\,
      I4 => \FSM_onehot_PS_reg_n_0_[6]\,
      I5 => \channel_index_reg_n_0_[1]\,
      O => \channel_index[1]_i_1_n_0\
    );
\channel_index[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"2AFF8000"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[6]\,
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \channel_index[2]_i_2_n_0\,
      I4 => \channel_index_reg_n_0_[2]\,
      O => \channel_index[2]_i_1_n_0\
    );
\channel_index[2]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[5]\,
      I1 => \FSM_onehot_PS_reg_n_0_[0]\,
      I2 => \FSM_onehot_PS_reg_n_0_[3]\,
      I3 => \FSM_onehot_PS_reg_n_0_[6]\,
      O => \channel_index[2]_i_2_n_0\
    );
\channel_index_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \channel_index[0]_i_1_n_0\,
      Q => \channel_index_reg_n_0_[0]\,
      R => SR(0)
    );
\channel_index_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \channel_index[1]_i_1_n_0\,
      Q => \channel_index_reg_n_0_[1]\,
      R => SR(0)
    );
\channel_index_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \channel_index[2]_i_1_n_0\,
      Q => \channel_index_reg_n_0_[2]\,
      R => SR(0)
    );
\cycle_counter[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5554"
    )
        port map (
      I0 => cycle_counter(0),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[0]_i_1_n_0\
    );
\cycle_counter[10]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(10),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[10]_i_1_n_0\
    );
\cycle_counter[11]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(11),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[11]_i_1_n_0\
    );
\cycle_counter[12]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(12),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[12]_i_1_n_0\
    );
\cycle_counter[13]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(13),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[13]_i_1_n_0\
    );
\cycle_counter[14]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(14),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[14]_i_1_n_0\
    );
\cycle_counter[15]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(15),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[15]_i_1_n_0\
    );
\cycle_counter[16]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(16),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[16]_i_1_n_0\
    );
\cycle_counter[17]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(17),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[17]_i_1_n_0\
    );
\cycle_counter[18]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(18),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[18]_i_1_n_0\
    );
\cycle_counter[19]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(19),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[19]_i_1_n_0\
    );
\cycle_counter[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(1),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[1]_i_1_n_0\
    );
\cycle_counter[20]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(20),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[20]_i_1_n_0\
    );
\cycle_counter[21]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(21),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[21]_i_1_n_0\
    );
\cycle_counter[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(2),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[2]_i_1_n_0\
    );
\cycle_counter[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(3),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[3]_i_1_n_0\
    );
\cycle_counter[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(4),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[4]_i_1_n_0\
    );
\cycle_counter[5]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(5),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[5]_i_1_n_0\
    );
\cycle_counter[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(6),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[6]_i_1_n_0\
    );
\cycle_counter[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(7),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[7]_i_1_n_0\
    );
\cycle_counter[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(8),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[8]_i_1_n_0\
    );
\cycle_counter[9]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAA8"
    )
        port map (
      I0 => in7(9),
      I1 => \FSM_onehot_PS_reg_n_0_[1]\,
      I2 => \FSM_onehot_PS_reg_n_0_[2]\,
      I3 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter[9]_i_1_n_0\
    );
\cycle_counter_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[0]_i_1_n_0\,
      Q => cycle_counter(0),
      R => SR(0)
    );
\cycle_counter_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[10]_i_1_n_0\,
      Q => cycle_counter(10),
      R => SR(0)
    );
\cycle_counter_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[11]_i_1_n_0\,
      Q => cycle_counter(11),
      R => SR(0)
    );
\cycle_counter_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[12]_i_1_n_0\,
      Q => cycle_counter(12),
      R => SR(0)
    );
\cycle_counter_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[13]_i_1_n_0\,
      Q => cycle_counter(13),
      R => SR(0)
    );
\cycle_counter_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[14]_i_1_n_0\,
      Q => cycle_counter(14),
      R => SR(0)
    );
\cycle_counter_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[15]_i_1_n_0\,
      Q => cycle_counter(15),
      R => SR(0)
    );
\cycle_counter_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[16]_i_1_n_0\,
      Q => cycle_counter(16),
      R => SR(0)
    );
\cycle_counter_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[17]_i_1_n_0\,
      Q => cycle_counter(17),
      R => SR(0)
    );
\cycle_counter_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[18]_i_1_n_0\,
      Q => cycle_counter(18),
      R => SR(0)
    );
\cycle_counter_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[19]_i_1_n_0\,
      Q => cycle_counter(19),
      R => SR(0)
    );
\cycle_counter_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[1]_i_1_n_0\,
      Q => cycle_counter(1),
      R => SR(0)
    );
\cycle_counter_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[20]_i_1_n_0\,
      Q => cycle_counter(20),
      R => SR(0)
    );
\cycle_counter_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[21]_i_1_n_0\,
      Q => cycle_counter(21),
      R => SR(0)
    );
\cycle_counter_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[2]_i_1_n_0\,
      Q => cycle_counter(2),
      R => SR(0)
    );
\cycle_counter_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[3]_i_1_n_0\,
      Q => cycle_counter(3),
      R => SR(0)
    );
\cycle_counter_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[4]_i_1_n_0\,
      Q => cycle_counter(4),
      R => SR(0)
    );
\cycle_counter_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[5]_i_1_n_0\,
      Q => cycle_counter(5),
      R => SR(0)
    );
\cycle_counter_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[6]_i_1_n_0\,
      Q => cycle_counter(6),
      R => SR(0)
    );
\cycle_counter_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[7]_i_1_n_0\,
      Q => cycle_counter(7),
      R => SR(0)
    );
\cycle_counter_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[8]_i_1_n_0\,
      Q => cycle_counter(8),
      R => SR(0)
    );
\cycle_counter_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \cycle_counter[9]_i_1_n_0\,
      Q => cycle_counter(9),
      R => SR(0)
    );
\cycle_counter_total[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555554"
    )
        port map (
      I0 => cycle_counter_total(0),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[0]_i_1_n_0\
    );
\cycle_counter_total[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(10),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[10]_i_1_n_0\
    );
\cycle_counter_total[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(11),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[11]_i_1_n_0\
    );
\cycle_counter_total[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(12),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[12]_i_1_n_0\
    );
\cycle_counter_total[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(13),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[13]_i_1_n_0\
    );
\cycle_counter_total[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(14),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[14]_i_1_n_0\
    );
\cycle_counter_total[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(15),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[15]_i_1_n_0\
    );
\cycle_counter_total[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(16),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[16]_i_1_n_0\
    );
\cycle_counter_total[17]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(17),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[17]_i_1_n_0\
    );
\cycle_counter_total[18]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(18),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[18]_i_1_n_0\
    );
\cycle_counter_total[19]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(19),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[19]_i_1_n_0\
    );
\cycle_counter_total[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(1),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[1]_i_1_n_0\
    );
\cycle_counter_total[20]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(20),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[20]_i_1_n_0\
    );
\cycle_counter_total[21]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[5]\,
      I1 => \FSM_onehot_PS_reg_n_0_[0]\,
      I2 => \FSM_onehot_PS_reg_n_0_[1]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[4]\,
      O => \cycle_counter_total[21]_i_1_n_0\
    );
\cycle_counter_total[21]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(21),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[21]_i_2_n_0\
    );
\cycle_counter_total[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(2),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[2]_i_1_n_0\
    );
\cycle_counter_total[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(3),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[3]_i_1_n_0\
    );
\cycle_counter_total[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(4),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[4]_i_1_n_0\
    );
\cycle_counter_total[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(5),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[5]_i_1_n_0\
    );
\cycle_counter_total[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(6),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[6]_i_1_n_0\
    );
\cycle_counter_total[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(7),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[7]_i_1_n_0\
    );
\cycle_counter_total[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(8),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[8]_i_1_n_0\
    );
\cycle_counter_total[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => in8(9),
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[4]\,
      I3 => \FSM_onehot_PS_reg_n_0_[2]\,
      I4 => \FSM_onehot_PS_reg_n_0_[1]\,
      O => \cycle_counter_total[9]_i_1_n_0\
    );
\cycle_counter_total_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[0]_i_1_n_0\,
      Q => cycle_counter_total(0),
      R => SR(0)
    );
\cycle_counter_total_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[10]_i_1_n_0\,
      Q => cycle_counter_total(10),
      R => SR(0)
    );
\cycle_counter_total_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[11]_i_1_n_0\,
      Q => cycle_counter_total(11),
      R => SR(0)
    );
\cycle_counter_total_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[12]_i_1_n_0\,
      Q => cycle_counter_total(12),
      R => SR(0)
    );
\cycle_counter_total_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[13]_i_1_n_0\,
      Q => cycle_counter_total(13),
      R => SR(0)
    );
\cycle_counter_total_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[14]_i_1_n_0\,
      Q => cycle_counter_total(14),
      R => SR(0)
    );
\cycle_counter_total_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[15]_i_1_n_0\,
      Q => cycle_counter_total(15),
      R => SR(0)
    );
\cycle_counter_total_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[16]_i_1_n_0\,
      Q => cycle_counter_total(16),
      R => SR(0)
    );
\cycle_counter_total_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[17]_i_1_n_0\,
      Q => cycle_counter_total(17),
      R => SR(0)
    );
\cycle_counter_total_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[18]_i_1_n_0\,
      Q => cycle_counter_total(18),
      R => SR(0)
    );
\cycle_counter_total_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[19]_i_1_n_0\,
      Q => cycle_counter_total(19),
      R => SR(0)
    );
\cycle_counter_total_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[1]_i_1_n_0\,
      Q => cycle_counter_total(1),
      R => SR(0)
    );
\cycle_counter_total_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[20]_i_1_n_0\,
      Q => cycle_counter_total(20),
      R => SR(0)
    );
\cycle_counter_total_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[21]_i_2_n_0\,
      Q => cycle_counter_total(21),
      R => SR(0)
    );
\cycle_counter_total_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[2]_i_1_n_0\,
      Q => cycle_counter_total(2),
      R => SR(0)
    );
\cycle_counter_total_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[3]_i_1_n_0\,
      Q => cycle_counter_total(3),
      R => SR(0)
    );
\cycle_counter_total_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[4]_i_1_n_0\,
      Q => cycle_counter_total(4),
      R => SR(0)
    );
\cycle_counter_total_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[5]_i_1_n_0\,
      Q => cycle_counter_total(5),
      R => SR(0)
    );
\cycle_counter_total_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[6]_i_1_n_0\,
      Q => cycle_counter_total(6),
      R => SR(0)
    );
\cycle_counter_total_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[7]_i_1_n_0\,
      Q => cycle_counter_total(7),
      R => SR(0)
    );
\cycle_counter_total_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[8]_i_1_n_0\,
      Q => cycle_counter_total(8),
      R => SR(0)
    );
\cycle_counter_total_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => \cycle_counter_total[9]_i_1_n_0\,
      Q => cycle_counter_total(9),
      R => SR(0)
    );
\geqOp_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \geqOp_inferred__0/i__carry_n_0\,
      CO(2) => \geqOp_inferred__0/i__carry_n_1\,
      CO(1) => \geqOp_inferred__0/i__carry_n_2\,
      CO(0) => \geqOp_inferred__0/i__carry_n_3\,
      CYINIT => '1',
      DI(3) => \i__carry_i_1_n_0\,
      DI(2) => \i__carry_i_2_n_0\,
      DI(1) => \i__carry_i_3_n_0\,
      DI(0) => \i__carry_i_4_n_0\,
      O(3 downto 0) => \NLW_geqOp_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5_n_0\,
      S(2) => \i__carry_i_6_n_0\,
      S(1) => \i__carry_i_7_n_0\,
      S(0) => \i__carry_i_8_n_0\
    );
\geqOp_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \geqOp_inferred__0/i__carry_n_0\,
      CO(3) => \geqOp_inferred__0/i__carry__0_n_0\,
      CO(2) => \geqOp_inferred__0/i__carry__0_n_1\,
      CO(1) => \geqOp_inferred__0/i__carry__0_n_2\,
      CO(0) => \geqOp_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry__0_i_1_n_0\,
      DI(2) => \i__carry__0_i_2_n_0\,
      DI(1) => \i__carry__0_i_3_n_0\,
      DI(0) => \i__carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_geqOp_inferred__0/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry__0_i_5_n_0\,
      S(2) => \i__carry__0_i_6_n_0\,
      S(1) => \i__carry__0_i_7_n_0\,
      S(0) => \i__carry__0_i_8_n_0\
    );
\geqOp_inferred__0/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \geqOp_inferred__0/i__carry__0_n_0\,
      CO(3) => \NLW_geqOp_inferred__0/i__carry__1_CO_UNCONNECTED\(3),
      CO(2) => \geqOp_inferred__0/i__carry__1_n_1\,
      CO(1) => \geqOp_inferred__0/i__carry__1_n_2\,
      CO(0) => \geqOp_inferred__0/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \i__carry__1_i_1_n_0\,
      DI(1) => \i__carry__1_i_2_n_0\,
      DI(0) => \i__carry__1_i_3_n_0\,
      O(3 downto 0) => \NLW_geqOp_inferred__0/i__carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \i__carry__1_i_4_n_0\,
      S(1) => \i__carry__1_i_5_n_0\,
      S(0) => \i__carry__1_i_6_n_0\
    );
\i__carry__0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(15),
      I1 => \i__carry__0_i_9_n_0\,
      I2 => minusOp(14),
      I3 => \i__carry__0_i_10_n_0\,
      O => \i__carry__0_i_1_n_0\
    );
\i__carry__0_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(14),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(14),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_18_n_0\,
      O => \i__carry__0_i_10_n_0\
    );
\i__carry__0_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(13),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(13),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_19_n_0\,
      O => \i__carry__0_i_11_n_0\
    );
\i__carry__0_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(12),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(12),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_20_n_0\,
      O => \i__carry__0_i_12_n_0\
    );
\i__carry__0_i_13\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(11),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(11),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_21_n_0\,
      O => \i__carry__0_i_13_n_0\
    );
\i__carry__0_i_14\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(10),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(10),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_22_n_0\,
      O => \i__carry__0_i_14_n_0\
    );
\i__carry__0_i_15\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(9),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(9),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_23_n_0\,
      O => \i__carry__0_i_15_n_0\
    );
\i__carry__0_i_16\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(8),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(8),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_24_n_0\,
      O => \i__carry__0_i_16_n_0\
    );
\i__carry__0_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(15),
      I1 => \pulse_widths_reg[2]_2\(15),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(15),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(15),
      O => \i__carry__0_i_17_n_0\
    );
\i__carry__0_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(14),
      I1 => \pulse_widths_reg[2]_2\(14),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(14),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(14),
      O => \i__carry__0_i_18_n_0\
    );
\i__carry__0_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(13),
      I1 => \pulse_widths_reg[2]_2\(13),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(13),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(13),
      O => \i__carry__0_i_19_n_0\
    );
\i__carry__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(13),
      I1 => \i__carry__0_i_11_n_0\,
      I2 => minusOp(12),
      I3 => \i__carry__0_i_12_n_0\,
      O => \i__carry__0_i_2_n_0\
    );
\i__carry__0_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(12),
      I1 => \pulse_widths_reg[2]_2\(12),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(12),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(12),
      O => \i__carry__0_i_20_n_0\
    );
\i__carry__0_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(11),
      I1 => \pulse_widths_reg[2]_2\(11),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(11),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(11),
      O => \i__carry__0_i_21_n_0\
    );
\i__carry__0_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(10),
      I1 => \pulse_widths_reg[2]_2\(10),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(10),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(10),
      O => \i__carry__0_i_22_n_0\
    );
\i__carry__0_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(9),
      I1 => \pulse_widths_reg[2]_2\(9),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(9),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(9),
      O => \i__carry__0_i_23_n_0\
    );
\i__carry__0_i_24\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(8),
      I1 => \pulse_widths_reg[2]_2\(8),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(8),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(8),
      O => \i__carry__0_i_24_n_0\
    );
\i__carry__0_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(11),
      I1 => \i__carry__0_i_13_n_0\,
      I2 => minusOp(10),
      I3 => \i__carry__0_i_14_n_0\,
      O => \i__carry__0_i_3_n_0\
    );
\i__carry__0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(9),
      I1 => \i__carry__0_i_15_n_0\,
      I2 => minusOp(8),
      I3 => \i__carry__0_i_16_n_0\,
      O => \i__carry__0_i_4_n_0\
    );
\i__carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry__0_i_9_n_0\,
      I1 => minusOp(15),
      I2 => \i__carry__0_i_10_n_0\,
      I3 => minusOp(14),
      O => \i__carry__0_i_5_n_0\
    );
\i__carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry__0_i_11_n_0\,
      I1 => minusOp(13),
      I2 => \i__carry__0_i_12_n_0\,
      I3 => minusOp(12),
      O => \i__carry__0_i_6_n_0\
    );
\i__carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry__0_i_13_n_0\,
      I1 => minusOp(11),
      I2 => \i__carry__0_i_14_n_0\,
      I3 => minusOp(10),
      O => \i__carry__0_i_7_n_0\
    );
\i__carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry__0_i_15_n_0\,
      I1 => minusOp(9),
      I2 => \i__carry__0_i_16_n_0\,
      I3 => minusOp(8),
      O => \i__carry__0_i_8_n_0\
    );
\i__carry__0_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(15),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(15),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__0_i_17_n_0\,
      O => \i__carry__0_i_9_n_0\
    );
\i__carry__1_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(21),
      I1 => \i__carry__1_i_7_n_0\,
      I2 => minusOp(20),
      I3 => \i__carry__1_i_8_n_0\,
      O => \i__carry__1_i_1_n_0\
    );
\i__carry__1_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(18),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(18),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__1_i_16_n_0\,
      O => \i__carry__1_i_10_n_0\
    );
\i__carry__1_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(17),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(17),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__1_i_17_n_0\,
      O => \i__carry__1_i_11_n_0\
    );
\i__carry__1_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(16),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(16),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__1_i_18_n_0\,
      O => \i__carry__1_i_12_n_0\
    );
\i__carry__1_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(21),
      I1 => \pulse_widths_reg[2]_2\(21),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(21),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(21),
      O => \i__carry__1_i_13_n_0\
    );
\i__carry__1_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(20),
      I1 => \pulse_widths_reg[2]_2\(20),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(20),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(20),
      O => \i__carry__1_i_14_n_0\
    );
\i__carry__1_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(19),
      I1 => \pulse_widths_reg[2]_2\(19),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(19),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(19),
      O => \i__carry__1_i_15_n_0\
    );
\i__carry__1_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(18),
      I1 => \pulse_widths_reg[2]_2\(18),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(18),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(18),
      O => \i__carry__1_i_16_n_0\
    );
\i__carry__1_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(17),
      I1 => \pulse_widths_reg[2]_2\(17),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(17),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(17),
      O => \i__carry__1_i_17_n_0\
    );
\i__carry__1_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(16),
      I1 => \pulse_widths_reg[2]_2\(16),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(16),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(16),
      O => \i__carry__1_i_18_n_0\
    );
\i__carry__1_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(19),
      I1 => \i__carry__1_i_9_n_0\,
      I2 => minusOp(18),
      I3 => \i__carry__1_i_10_n_0\,
      O => \i__carry__1_i_2_n_0\
    );
\i__carry__1_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(17),
      I1 => \i__carry__1_i_11_n_0\,
      I2 => minusOp(16),
      I3 => \i__carry__1_i_12_n_0\,
      O => \i__carry__1_i_3_n_0\
    );
\i__carry__1_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry__1_i_7_n_0\,
      I1 => minusOp(21),
      I2 => \i__carry__1_i_8_n_0\,
      I3 => minusOp(20),
      O => \i__carry__1_i_4_n_0\
    );
\i__carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry__1_i_9_n_0\,
      I1 => minusOp(19),
      I2 => \i__carry__1_i_10_n_0\,
      I3 => minusOp(18),
      O => \i__carry__1_i_5_n_0\
    );
\i__carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry__1_i_11_n_0\,
      I1 => minusOp(17),
      I2 => \i__carry__1_i_12_n_0\,
      I3 => minusOp(16),
      O => \i__carry__1_i_6_n_0\
    );
\i__carry__1_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(21),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(21),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__1_i_13_n_0\,
      O => \i__carry__1_i_7_n_0\
    );
\i__carry__1_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(20),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(20),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__1_i_14_n_0\,
      O => \i__carry__1_i_8_n_0\
    );
\i__carry__1_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(19),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(19),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry__1_i_15_n_0\,
      O => \i__carry__1_i_9_n_0\
    );
\i__carry_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(7),
      I1 => \i__carry_i_9_n_0\,
      I2 => minusOp(6),
      I3 => \i__carry_i_10_n_0\,
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(6),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(6),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_20_n_0\,
      O => \i__carry_i_10_n_0\
    );
\i__carry_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(5),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(5),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_21_n_0\,
      O => \i__carry_i_11_n_0\
    );
\i__carry_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(4),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(4),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_22_n_0\,
      O => \i__carry_i_12_n_0\
    );
\i__carry_i_13\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(3),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(3),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_23_n_0\,
      O => \i__carry_i_13_n_0\
    );
\i__carry_i_14\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(2),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(2),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_24_n_0\,
      O => \i__carry_i_14_n_0\
    );
\i__carry_i_15\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(1),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(1),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_25_n_0\,
      O => \i__carry_i_15_n_0\
    );
\i__carry_i_16\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(0),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(0),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_26_n_0\,
      O => \i__carry_i_16_n_0\
    );
\i__carry_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A9A9A9595959A959"
    )
        port map (
      I0 => cycle_counter(3),
      I1 => \i__carry_i_23_n_0\,
      I2 => \channel_index_reg_n_0_[2]\,
      I3 => \pulse_widths_reg[4]_4\(3),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[5]_5\(3),
      O => \i__carry_i_17_n_0\
    );
\i__carry_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A9A9A9595959A959"
    )
        port map (
      I0 => cycle_counter(1),
      I1 => \i__carry_i_25_n_0\,
      I2 => \channel_index_reg_n_0_[2]\,
      I3 => \pulse_widths_reg[4]_4\(1),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[5]_5\(1),
      O => \i__carry_i_18_n_0\
    );
\i__carry_i_19\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(7),
      I1 => \pulse_widths_reg[2]_2\(7),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(7),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(7),
      O => \i__carry_i_19_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => minusOp(5),
      I1 => \i__carry_i_11_n_0\,
      I2 => cycle_counter(4),
      I3 => \i__carry_i_12_n_0\,
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_20\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(6),
      I1 => \pulse_widths_reg[2]_2\(6),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(6),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(6),
      O => \i__carry_i_20_n_0\
    );
\i__carry_i_21\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(5),
      I1 => \pulse_widths_reg[2]_2\(5),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(5),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(5),
      O => \i__carry_i_21_n_0\
    );
\i__carry_i_22\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(4),
      I1 => \pulse_widths_reg[2]_2\(4),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(4),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(4),
      O => \i__carry_i_22_n_0\
    );
\i__carry_i_23\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(3),
      I1 => \pulse_widths_reg[2]_2\(3),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(3),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(3),
      O => \i__carry_i_23_n_0\
    );
\i__carry_i_24\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(2),
      I1 => \pulse_widths_reg[2]_2\(2),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(2),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(2),
      O => \i__carry_i_24_n_0\
    );
\i__carry_i_25\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(1),
      I1 => \pulse_widths_reg[2]_2\(1),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(1),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(1),
      O => \i__carry_i_25_n_0\
    );
\i__carry_i_26\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \pulse_widths_reg[3]_3\(0),
      I1 => \pulse_widths_reg[2]_2\(0),
      I2 => \channel_index_reg_n_0_[1]\,
      I3 => \pulse_widths_reg[1]_1\(0),
      I4 => \channel_index_reg_n_0_[0]\,
      I5 => \pulse_widths_reg[0]_0\(0),
      O => \i__carry_i_26_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => cycle_counter(3),
      I1 => \i__carry_i_13_n_0\,
      I2 => cycle_counter(2),
      I3 => \i__carry_i_14_n_0\,
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"22B2"
    )
        port map (
      I0 => cycle_counter(1),
      I1 => \i__carry_i_15_n_0\,
      I2 => cycle_counter(0),
      I3 => \i__carry_i_16_n_0\,
      O => \i__carry_i_4_n_0\
    );
\i__carry_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry_i_9_n_0\,
      I1 => minusOp(7),
      I2 => \i__carry_i_10_n_0\,
      I3 => minusOp(6),
      O => \i__carry_i_5_n_0\
    );
\i__carry_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9009"
    )
        port map (
      I0 => \i__carry_i_11_n_0\,
      I1 => minusOp(5),
      I2 => \i__carry_i_12_n_0\,
      I3 => cycle_counter(4),
      O => \i__carry_i_6_n_0\
    );
\i__carry_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \i__carry_i_17_n_0\,
      I1 => \i__carry_i_14_n_0\,
      I2 => cycle_counter(2),
      O => \i__carry_i_7_n_0\
    );
\i__carry_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"82"
    )
        port map (
      I0 => \i__carry_i_18_n_0\,
      I1 => \i__carry_i_16_n_0\,
      I2 => cycle_counter(0),
      O => \i__carry_i_8_n_0\
    );
\i__carry_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \pulse_widths_reg[5]_5\(7),
      I1 => \channel_index_reg_n_0_[0]\,
      I2 => \pulse_widths_reg[4]_4\(7),
      I3 => \channel_index_reg_n_0_[2]\,
      I4 => \i__carry_i_19_n_0\,
      O => \i__carry_i_9_n_0\
    );
minusOp_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => minusOp_carry_n_0,
      CO(2) => minusOp_carry_n_1,
      CO(1) => minusOp_carry_n_2,
      CO(0) => minusOp_carry_n_3,
      CYINIT => '0',
      DI(3 downto 1) => cycle_counter(8 downto 6),
      DI(0) => '0',
      O(3 downto 0) => minusOp(8 downto 5),
      S(3) => minusOp_carry_i_1_n_0,
      S(2) => minusOp_carry_i_2_n_0,
      S(1) => minusOp_carry_i_3_n_0,
      S(0) => cycle_counter(5)
    );
\minusOp_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => minusOp_carry_n_0,
      CO(3) => \minusOp_carry__0_n_0\,
      CO(2) => \minusOp_carry__0_n_1\,
      CO(1) => \minusOp_carry__0_n_2\,
      CO(0) => \minusOp_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => cycle_counter(9),
      O(3 downto 0) => minusOp(12 downto 9),
      S(3 downto 1) => cycle_counter(12 downto 10),
      S(0) => \minusOp_carry__0_i_1_n_0\
    );
\minusOp_carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(9),
      O => \minusOp_carry__0_i_1_n_0\
    );
\minusOp_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \minusOp_carry__0_n_0\,
      CO(3) => \minusOp_carry__1_n_0\,
      CO(2) => \minusOp_carry__1_n_1\,
      CO(1) => \minusOp_carry__1_n_2\,
      CO(0) => \minusOp_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => cycle_counter(16),
      DI(2) => '0',
      DI(1 downto 0) => cycle_counter(14 downto 13),
      O(3 downto 0) => minusOp(16 downto 13),
      S(3) => \minusOp_carry__1_i_1_n_0\,
      S(2) => cycle_counter(15),
      S(1) => \minusOp_carry__1_i_2_n_0\,
      S(0) => \minusOp_carry__1_i_3_n_0\
    );
\minusOp_carry__1_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(16),
      O => \minusOp_carry__1_i_1_n_0\
    );
\minusOp_carry__1_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(14),
      O => \minusOp_carry__1_i_2_n_0\
    );
\minusOp_carry__1_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(13),
      O => \minusOp_carry__1_i_3_n_0\
    );
\minusOp_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \minusOp_carry__1_n_0\,
      CO(3) => \minusOp_carry__2_n_0\,
      CO(2) => \minusOp_carry__2_n_1\,
      CO(1) => \minusOp_carry__2_n_2\,
      CO(0) => \minusOp_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => cycle_counter(20 downto 17),
      O(3 downto 0) => minusOp(20 downto 17),
      S(3) => \minusOp_carry__2_i_1_n_0\,
      S(2) => \minusOp_carry__2_i_2_n_0\,
      S(1) => \minusOp_carry__2_i_3_n_0\,
      S(0) => \minusOp_carry__2_i_4_n_0\
    );
\minusOp_carry__2_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(20),
      O => \minusOp_carry__2_i_1_n_0\
    );
\minusOp_carry__2_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(19),
      O => \minusOp_carry__2_i_2_n_0\
    );
\minusOp_carry__2_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(18),
      O => \minusOp_carry__2_i_3_n_0\
    );
\minusOp_carry__2_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(17),
      O => \minusOp_carry__2_i_4_n_0\
    );
\minusOp_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \minusOp_carry__2_n_0\,
      CO(3 downto 0) => \NLW_minusOp_carry__3_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_minusOp_carry__3_O_UNCONNECTED\(3 downto 1),
      O(0) => minusOp(21),
      S(3 downto 1) => B"000",
      S(0) => \minusOp_carry__3_i_1_n_0\
    );
\minusOp_carry__3_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(21),
      O => \minusOp_carry__3_i_1_n_0\
    );
minusOp_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(8),
      O => minusOp_carry_i_1_n_0
    );
minusOp_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(7),
      O => minusOp_carry_i_2_n_0
    );
minusOp_carry_i_3: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => cycle_counter(6),
      O => minusOp_carry_i_3_n_0
    );
plusOp_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => plusOp_carry_n_0,
      CO(2) => plusOp_carry_n_1,
      CO(1) => plusOp_carry_n_2,
      CO(0) => plusOp_carry_n_3,
      CYINIT => cycle_counter_total(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in8(4 downto 1),
      S(3 downto 0) => cycle_counter_total(4 downto 1)
    );
\plusOp_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => plusOp_carry_n_0,
      CO(3) => \plusOp_carry__0_n_0\,
      CO(2) => \plusOp_carry__0_n_1\,
      CO(1) => \plusOp_carry__0_n_2\,
      CO(0) => \plusOp_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in8(8 downto 5),
      S(3 downto 0) => cycle_counter_total(8 downto 5)
    );
\plusOp_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_carry__0_n_0\,
      CO(3) => \plusOp_carry__1_n_0\,
      CO(2) => \plusOp_carry__1_n_1\,
      CO(1) => \plusOp_carry__1_n_2\,
      CO(0) => \plusOp_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in8(12 downto 9),
      S(3 downto 0) => cycle_counter_total(12 downto 9)
    );
\plusOp_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_carry__1_n_0\,
      CO(3) => \plusOp_carry__2_n_0\,
      CO(2) => \plusOp_carry__2_n_1\,
      CO(1) => \plusOp_carry__2_n_2\,
      CO(0) => \plusOp_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in8(16 downto 13),
      S(3 downto 0) => cycle_counter_total(16 downto 13)
    );
\plusOp_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_carry__2_n_0\,
      CO(3) => \plusOp_carry__3_n_0\,
      CO(2) => \plusOp_carry__3_n_1\,
      CO(1) => \plusOp_carry__3_n_2\,
      CO(0) => \plusOp_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in8(20 downto 17),
      S(3 downto 0) => cycle_counter_total(20 downto 17)
    );
\plusOp_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_carry__3_n_0\,
      CO(3 downto 0) => \NLW_plusOp_carry__4_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_plusOp_carry__4_O_UNCONNECTED\(3 downto 1),
      O(0) => in8(21),
      S(3 downto 1) => B"000",
      S(0) => cycle_counter_total(21)
    );
\plusOp_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \plusOp_inferred__0/i__carry_n_0\,
      CO(2) => \plusOp_inferred__0/i__carry_n_1\,
      CO(1) => \plusOp_inferred__0/i__carry_n_2\,
      CO(0) => \plusOp_inferred__0/i__carry_n_3\,
      CYINIT => cycle_counter(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in7(4 downto 1),
      S(3 downto 0) => cycle_counter(4 downto 1)
    );
\plusOp_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_inferred__0/i__carry_n_0\,
      CO(3) => \plusOp_inferred__0/i__carry__0_n_0\,
      CO(2) => \plusOp_inferred__0/i__carry__0_n_1\,
      CO(1) => \plusOp_inferred__0/i__carry__0_n_2\,
      CO(0) => \plusOp_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in7(8 downto 5),
      S(3 downto 0) => cycle_counter(8 downto 5)
    );
\plusOp_inferred__0/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_inferred__0/i__carry__0_n_0\,
      CO(3) => \plusOp_inferred__0/i__carry__1_n_0\,
      CO(2) => \plusOp_inferred__0/i__carry__1_n_1\,
      CO(1) => \plusOp_inferred__0/i__carry__1_n_2\,
      CO(0) => \plusOp_inferred__0/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in7(12 downto 9),
      S(3 downto 0) => cycle_counter(12 downto 9)
    );
\plusOp_inferred__0/i__carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_inferred__0/i__carry__1_n_0\,
      CO(3) => \plusOp_inferred__0/i__carry__2_n_0\,
      CO(2) => \plusOp_inferred__0/i__carry__2_n_1\,
      CO(1) => \plusOp_inferred__0/i__carry__2_n_2\,
      CO(0) => \plusOp_inferred__0/i__carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in7(16 downto 13),
      S(3 downto 0) => cycle_counter(16 downto 13)
    );
\plusOp_inferred__0/i__carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_inferred__0/i__carry__2_n_0\,
      CO(3) => \plusOp_inferred__0/i__carry__3_n_0\,
      CO(2) => \plusOp_inferred__0/i__carry__3_n_1\,
      CO(1) => \plusOp_inferred__0/i__carry__3_n_2\,
      CO(0) => \plusOp_inferred__0/i__carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => in7(20 downto 17),
      S(3 downto 0) => cycle_counter(20 downto 17)
    );
\plusOp_inferred__0/i__carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \plusOp_inferred__0/i__carry__3_n_0\,
      CO(3 downto 0) => \NLW_plusOp_inferred__0/i__carry__4_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_plusOp_inferred__0/i__carry__4_O_UNCONNECTED\(3 downto 1),
      O(0) => in7(21),
      S(3 downto 1) => B"000",
      S(0) => cycle_counter(21)
    );
\pulse_widths_reg[0][0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(0),
      Q => \pulse_widths_reg[0]_0\(0),
      R => SR(0)
    );
\pulse_widths_reg[0][10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(10),
      Q => \pulse_widths_reg[0]_0\(10),
      R => SR(0)
    );
\pulse_widths_reg[0][11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(11),
      Q => \pulse_widths_reg[0]_0\(11),
      R => SR(0)
    );
\pulse_widths_reg[0][12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(12),
      Q => \pulse_widths_reg[0]_0\(12),
      R => SR(0)
    );
\pulse_widths_reg[0][13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(13),
      Q => \pulse_widths_reg[0]_0\(13),
      R => SR(0)
    );
\pulse_widths_reg[0][14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(14),
      Q => \pulse_widths_reg[0]_0\(14),
      R => SR(0)
    );
\pulse_widths_reg[0][15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(15),
      Q => \pulse_widths_reg[0]_0\(15),
      R => SR(0)
    );
\pulse_widths_reg[0][16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(16),
      Q => \pulse_widths_reg[0]_0\(16),
      R => SR(0)
    );
\pulse_widths_reg[0][17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(17),
      Q => \pulse_widths_reg[0]_0\(17),
      R => SR(0)
    );
\pulse_widths_reg[0][18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(18),
      Q => \pulse_widths_reg[0]_0\(18),
      R => SR(0)
    );
\pulse_widths_reg[0][19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(19),
      Q => \pulse_widths_reg[0]_0\(19),
      R => SR(0)
    );
\pulse_widths_reg[0][1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(1),
      Q => \pulse_widths_reg[0]_0\(1),
      R => SR(0)
    );
\pulse_widths_reg[0][20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(20),
      Q => \pulse_widths_reg[0]_0\(20),
      R => SR(0)
    );
\pulse_widths_reg[0][21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(21),
      Q => \pulse_widths_reg[0]_0\(21),
      R => SR(0)
    );
\pulse_widths_reg[0][2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(2),
      Q => \pulse_widths_reg[0]_0\(2),
      R => SR(0)
    );
\pulse_widths_reg[0][3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(3),
      Q => \pulse_widths_reg[0]_0\(3),
      R => SR(0)
    );
\pulse_widths_reg[0][4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(4),
      Q => \pulse_widths_reg[0]_0\(4),
      R => SR(0)
    );
\pulse_widths_reg[0][5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(5),
      Q => \pulse_widths_reg[0]_0\(5),
      R => SR(0)
    );
\pulse_widths_reg[0][6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(6),
      Q => \pulse_widths_reg[0]_0\(6),
      R => SR(0)
    );
\pulse_widths_reg[0][7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(7),
      Q => \pulse_widths_reg[0]_0\(7),
      R => SR(0)
    );
\pulse_widths_reg[0][8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(8),
      Q => \pulse_widths_reg[0]_0\(8),
      R => SR(0)
    );
\pulse_widths_reg[0][9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[0][21]_0\(9),
      Q => \pulse_widths_reg[0]_0\(9),
      R => SR(0)
    );
\pulse_widths_reg[1][0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(0),
      Q => \pulse_widths_reg[1]_1\(0),
      R => SR(0)
    );
\pulse_widths_reg[1][10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(10),
      Q => \pulse_widths_reg[1]_1\(10),
      R => SR(0)
    );
\pulse_widths_reg[1][11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(11),
      Q => \pulse_widths_reg[1]_1\(11),
      R => SR(0)
    );
\pulse_widths_reg[1][12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(12),
      Q => \pulse_widths_reg[1]_1\(12),
      R => SR(0)
    );
\pulse_widths_reg[1][13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(13),
      Q => \pulse_widths_reg[1]_1\(13),
      R => SR(0)
    );
\pulse_widths_reg[1][14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(14),
      Q => \pulse_widths_reg[1]_1\(14),
      R => SR(0)
    );
\pulse_widths_reg[1][15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(15),
      Q => \pulse_widths_reg[1]_1\(15),
      R => SR(0)
    );
\pulse_widths_reg[1][16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(16),
      Q => \pulse_widths_reg[1]_1\(16),
      R => SR(0)
    );
\pulse_widths_reg[1][17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(17),
      Q => \pulse_widths_reg[1]_1\(17),
      R => SR(0)
    );
\pulse_widths_reg[1][18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(18),
      Q => \pulse_widths_reg[1]_1\(18),
      R => SR(0)
    );
\pulse_widths_reg[1][19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(19),
      Q => \pulse_widths_reg[1]_1\(19),
      R => SR(0)
    );
\pulse_widths_reg[1][1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(1),
      Q => \pulse_widths_reg[1]_1\(1),
      R => SR(0)
    );
\pulse_widths_reg[1][20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(20),
      Q => \pulse_widths_reg[1]_1\(20),
      R => SR(0)
    );
\pulse_widths_reg[1][21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(21),
      Q => \pulse_widths_reg[1]_1\(21),
      R => SR(0)
    );
\pulse_widths_reg[1][2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(2),
      Q => \pulse_widths_reg[1]_1\(2),
      R => SR(0)
    );
\pulse_widths_reg[1][3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(3),
      Q => \pulse_widths_reg[1]_1\(3),
      R => SR(0)
    );
\pulse_widths_reg[1][4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(4),
      Q => \pulse_widths_reg[1]_1\(4),
      R => SR(0)
    );
\pulse_widths_reg[1][5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(5),
      Q => \pulse_widths_reg[1]_1\(5),
      R => SR(0)
    );
\pulse_widths_reg[1][6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(6),
      Q => \pulse_widths_reg[1]_1\(6),
      R => SR(0)
    );
\pulse_widths_reg[1][7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(7),
      Q => \pulse_widths_reg[1]_1\(7),
      R => SR(0)
    );
\pulse_widths_reg[1][8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(8),
      Q => \pulse_widths_reg[1]_1\(8),
      R => SR(0)
    );
\pulse_widths_reg[1][9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[1][21]_0\(9),
      Q => \pulse_widths_reg[1]_1\(9),
      R => SR(0)
    );
\pulse_widths_reg[2][0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(0),
      Q => \pulse_widths_reg[2]_2\(0),
      R => SR(0)
    );
\pulse_widths_reg[2][10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(10),
      Q => \pulse_widths_reg[2]_2\(10),
      R => SR(0)
    );
\pulse_widths_reg[2][11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(11),
      Q => \pulse_widths_reg[2]_2\(11),
      R => SR(0)
    );
\pulse_widths_reg[2][12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(12),
      Q => \pulse_widths_reg[2]_2\(12),
      R => SR(0)
    );
\pulse_widths_reg[2][13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(13),
      Q => \pulse_widths_reg[2]_2\(13),
      R => SR(0)
    );
\pulse_widths_reg[2][14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(14),
      Q => \pulse_widths_reg[2]_2\(14),
      R => SR(0)
    );
\pulse_widths_reg[2][15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(15),
      Q => \pulse_widths_reg[2]_2\(15),
      R => SR(0)
    );
\pulse_widths_reg[2][16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(16),
      Q => \pulse_widths_reg[2]_2\(16),
      R => SR(0)
    );
\pulse_widths_reg[2][17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(17),
      Q => \pulse_widths_reg[2]_2\(17),
      R => SR(0)
    );
\pulse_widths_reg[2][18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(18),
      Q => \pulse_widths_reg[2]_2\(18),
      R => SR(0)
    );
\pulse_widths_reg[2][19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(19),
      Q => \pulse_widths_reg[2]_2\(19),
      R => SR(0)
    );
\pulse_widths_reg[2][1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(1),
      Q => \pulse_widths_reg[2]_2\(1),
      R => SR(0)
    );
\pulse_widths_reg[2][20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(20),
      Q => \pulse_widths_reg[2]_2\(20),
      R => SR(0)
    );
\pulse_widths_reg[2][21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(21),
      Q => \pulse_widths_reg[2]_2\(21),
      R => SR(0)
    );
\pulse_widths_reg[2][2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(2),
      Q => \pulse_widths_reg[2]_2\(2),
      R => SR(0)
    );
\pulse_widths_reg[2][3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(3),
      Q => \pulse_widths_reg[2]_2\(3),
      R => SR(0)
    );
\pulse_widths_reg[2][4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(4),
      Q => \pulse_widths_reg[2]_2\(4),
      R => SR(0)
    );
\pulse_widths_reg[2][5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(5),
      Q => \pulse_widths_reg[2]_2\(5),
      R => SR(0)
    );
\pulse_widths_reg[2][6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(6),
      Q => \pulse_widths_reg[2]_2\(6),
      R => SR(0)
    );
\pulse_widths_reg[2][7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(7),
      Q => \pulse_widths_reg[2]_2\(7),
      R => SR(0)
    );
\pulse_widths_reg[2][8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(8),
      Q => \pulse_widths_reg[2]_2\(8),
      R => SR(0)
    );
\pulse_widths_reg[2][9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[2][21]_0\(9),
      Q => \pulse_widths_reg[2]_2\(9),
      R => SR(0)
    );
\pulse_widths_reg[3][0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(0),
      Q => \pulse_widths_reg[3]_3\(0),
      R => SR(0)
    );
\pulse_widths_reg[3][10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(10),
      Q => \pulse_widths_reg[3]_3\(10),
      R => SR(0)
    );
\pulse_widths_reg[3][11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(11),
      Q => \pulse_widths_reg[3]_3\(11),
      R => SR(0)
    );
\pulse_widths_reg[3][12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(12),
      Q => \pulse_widths_reg[3]_3\(12),
      R => SR(0)
    );
\pulse_widths_reg[3][13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(13),
      Q => \pulse_widths_reg[3]_3\(13),
      R => SR(0)
    );
\pulse_widths_reg[3][14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(14),
      Q => \pulse_widths_reg[3]_3\(14),
      R => SR(0)
    );
\pulse_widths_reg[3][15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(15),
      Q => \pulse_widths_reg[3]_3\(15),
      R => SR(0)
    );
\pulse_widths_reg[3][16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(16),
      Q => \pulse_widths_reg[3]_3\(16),
      R => SR(0)
    );
\pulse_widths_reg[3][17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(17),
      Q => \pulse_widths_reg[3]_3\(17),
      R => SR(0)
    );
\pulse_widths_reg[3][18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(18),
      Q => \pulse_widths_reg[3]_3\(18),
      R => SR(0)
    );
\pulse_widths_reg[3][19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(19),
      Q => \pulse_widths_reg[3]_3\(19),
      R => SR(0)
    );
\pulse_widths_reg[3][1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(1),
      Q => \pulse_widths_reg[3]_3\(1),
      R => SR(0)
    );
\pulse_widths_reg[3][20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(20),
      Q => \pulse_widths_reg[3]_3\(20),
      R => SR(0)
    );
\pulse_widths_reg[3][21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(21),
      Q => \pulse_widths_reg[3]_3\(21),
      R => SR(0)
    );
\pulse_widths_reg[3][2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(2),
      Q => \pulse_widths_reg[3]_3\(2),
      R => SR(0)
    );
\pulse_widths_reg[3][3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(3),
      Q => \pulse_widths_reg[3]_3\(3),
      R => SR(0)
    );
\pulse_widths_reg[3][4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(4),
      Q => \pulse_widths_reg[3]_3\(4),
      R => SR(0)
    );
\pulse_widths_reg[3][5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(5),
      Q => \pulse_widths_reg[3]_3\(5),
      R => SR(0)
    );
\pulse_widths_reg[3][6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(6),
      Q => \pulse_widths_reg[3]_3\(6),
      R => SR(0)
    );
\pulse_widths_reg[3][7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(7),
      Q => \pulse_widths_reg[3]_3\(7),
      R => SR(0)
    );
\pulse_widths_reg[3][8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(8),
      Q => \pulse_widths_reg[3]_3\(8),
      R => SR(0)
    );
\pulse_widths_reg[3][9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[3][21]_0\(9),
      Q => \pulse_widths_reg[3]_3\(9),
      R => SR(0)
    );
\pulse_widths_reg[4][0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(0),
      Q => \pulse_widths_reg[4]_4\(0),
      R => SR(0)
    );
\pulse_widths_reg[4][10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(10),
      Q => \pulse_widths_reg[4]_4\(10),
      R => SR(0)
    );
\pulse_widths_reg[4][11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(11),
      Q => \pulse_widths_reg[4]_4\(11),
      R => SR(0)
    );
\pulse_widths_reg[4][12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(12),
      Q => \pulse_widths_reg[4]_4\(12),
      R => SR(0)
    );
\pulse_widths_reg[4][13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(13),
      Q => \pulse_widths_reg[4]_4\(13),
      R => SR(0)
    );
\pulse_widths_reg[4][14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(14),
      Q => \pulse_widths_reg[4]_4\(14),
      R => SR(0)
    );
\pulse_widths_reg[4][15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(15),
      Q => \pulse_widths_reg[4]_4\(15),
      R => SR(0)
    );
\pulse_widths_reg[4][16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(16),
      Q => \pulse_widths_reg[4]_4\(16),
      R => SR(0)
    );
\pulse_widths_reg[4][17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(17),
      Q => \pulse_widths_reg[4]_4\(17),
      R => SR(0)
    );
\pulse_widths_reg[4][18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(18),
      Q => \pulse_widths_reg[4]_4\(18),
      R => SR(0)
    );
\pulse_widths_reg[4][19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(19),
      Q => \pulse_widths_reg[4]_4\(19),
      R => SR(0)
    );
\pulse_widths_reg[4][1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(1),
      Q => \pulse_widths_reg[4]_4\(1),
      R => SR(0)
    );
\pulse_widths_reg[4][20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(20),
      Q => \pulse_widths_reg[4]_4\(20),
      R => SR(0)
    );
\pulse_widths_reg[4][21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(21),
      Q => \pulse_widths_reg[4]_4\(21),
      R => SR(0)
    );
\pulse_widths_reg[4][2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(2),
      Q => \pulse_widths_reg[4]_4\(2),
      R => SR(0)
    );
\pulse_widths_reg[4][3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(3),
      Q => \pulse_widths_reg[4]_4\(3),
      R => SR(0)
    );
\pulse_widths_reg[4][4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(4),
      Q => \pulse_widths_reg[4]_4\(4),
      R => SR(0)
    );
\pulse_widths_reg[4][5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(5),
      Q => \pulse_widths_reg[4]_4\(5),
      R => SR(0)
    );
\pulse_widths_reg[4][6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(6),
      Q => \pulse_widths_reg[4]_4\(6),
      R => SR(0)
    );
\pulse_widths_reg[4][7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(7),
      Q => \pulse_widths_reg[4]_4\(7),
      R => SR(0)
    );
\pulse_widths_reg[4][8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(8),
      Q => \pulse_widths_reg[4]_4\(8),
      R => SR(0)
    );
\pulse_widths_reg[4][9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[4][21]_0\(9),
      Q => \pulse_widths_reg[4]_4\(9),
      R => SR(0)
    );
\pulse_widths_reg[5][0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(0),
      Q => \pulse_widths_reg[5]_5\(0),
      R => SR(0)
    );
\pulse_widths_reg[5][10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(10),
      Q => \pulse_widths_reg[5]_5\(10),
      R => SR(0)
    );
\pulse_widths_reg[5][11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(11),
      Q => \pulse_widths_reg[5]_5\(11),
      R => SR(0)
    );
\pulse_widths_reg[5][12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(12),
      Q => \pulse_widths_reg[5]_5\(12),
      R => SR(0)
    );
\pulse_widths_reg[5][13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(13),
      Q => \pulse_widths_reg[5]_5\(13),
      R => SR(0)
    );
\pulse_widths_reg[5][14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(14),
      Q => \pulse_widths_reg[5]_5\(14),
      R => SR(0)
    );
\pulse_widths_reg[5][15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(15),
      Q => \pulse_widths_reg[5]_5\(15),
      R => SR(0)
    );
\pulse_widths_reg[5][16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(16),
      Q => \pulse_widths_reg[5]_5\(16),
      R => SR(0)
    );
\pulse_widths_reg[5][17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(17),
      Q => \pulse_widths_reg[5]_5\(17),
      R => SR(0)
    );
\pulse_widths_reg[5][18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(18),
      Q => \pulse_widths_reg[5]_5\(18),
      R => SR(0)
    );
\pulse_widths_reg[5][19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(19),
      Q => \pulse_widths_reg[5]_5\(19),
      R => SR(0)
    );
\pulse_widths_reg[5][1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(1),
      Q => \pulse_widths_reg[5]_5\(1),
      R => SR(0)
    );
\pulse_widths_reg[5][20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(20),
      Q => \pulse_widths_reg[5]_5\(20),
      R => SR(0)
    );
\pulse_widths_reg[5][21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(21),
      Q => \pulse_widths_reg[5]_5\(21),
      R => SR(0)
    );
\pulse_widths_reg[5][2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(2),
      Q => \pulse_widths_reg[5]_5\(2),
      R => SR(0)
    );
\pulse_widths_reg[5][3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(3),
      Q => \pulse_widths_reg[5]_5\(3),
      R => SR(0)
    );
\pulse_widths_reg[5][4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(4),
      Q => \pulse_widths_reg[5]_5\(4),
      R => SR(0)
    );
\pulse_widths_reg[5][5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(5),
      Q => \pulse_widths_reg[5]_5\(5),
      R => SR(0)
    );
\pulse_widths_reg[5][6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(6),
      Q => \pulse_widths_reg[5]_5\(6),
      R => SR(0)
    );
\pulse_widths_reg[5][7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(7),
      Q => \pulse_widths_reg[5]_5\(7),
      R => SR(0)
    );
\pulse_widths_reg[5][8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(8),
      Q => \pulse_widths_reg[5]_5\(8),
      R => SR(0)
    );
\pulse_widths_reg[5][9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \pulse_widths_reg[5][21]_0\(9),
      Q => \pulse_widths_reg[5]_5\(9),
      R => SR(0)
    );
sw_PPM_Output_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \FSM_onehot_PS_reg_n_0_[2]\,
      I1 => \FSM_onehot_PS_reg_n_0_[5]\,
      I2 => \FSM_onehot_PS_reg_n_0_[0]\,
      O => sw_PPM_Output_i_1_n_0
    );
sw_PPM_Output_reg: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => \cycle_counter_total[21]_i_1_n_0\,
      D => sw_PPM_Output_i_1_n_0,
      Q => PPM_generator_input,
      S => SR(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0_S00_AXI is
  port (
    axi_awready_reg_0 : out STD_LOGIC;
    SR : out STD_LOGIC_VECTOR ( 0 to 0 );
    axi_wready_reg_0 : out STD_LOGIC;
    axi_arready_reg_0 : out STD_LOGIC;
    s00_axi_bvalid : out STD_LOGIC;
    s00_axi_rvalid : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 0 to 0 );
    \PPM_generator_output_0_reg[21]_0\ : out STD_LOGIC_VECTOR ( 21 downto 0 );
    \PPM_generator_output_1_reg[21]_0\ : out STD_LOGIC_VECTOR ( 21 downto 0 );
    \PPM_generator_output_2_reg[21]_0\ : out STD_LOGIC_VECTOR ( 21 downto 0 );
    \PPM_generator_output_3_reg[21]_0\ : out STD_LOGIC_VECTOR ( 21 downto 0 );
    \PPM_generator_output_4_reg[21]_0\ : out STD_LOGIC_VECTOR ( 21 downto 0 );
    \PPM_generator_output_5_reg[21]_0\ : out STD_LOGIC_VECTOR ( 21 downto 0 );
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    PPM_capture_done : in STD_LOGIC;
    PPM_generator_done : in STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC;
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_bready : in STD_LOGIC;
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_rready : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    D : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \slv_reg11_reg[31]_0\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \slv_reg12_reg[31]_0\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \slv_reg13_reg[31]_0\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \slv_reg14_reg[31]_0\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    \slv_reg15_reg[31]_0\ : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0_S00_AXI;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0_S00_AXI is
  signal \^q\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^sr\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal aw_en_i_1_n_0 : STD_LOGIC;
  signal aw_en_reg_n_0 : STD_LOGIC;
  signal axi_arready0 : STD_LOGIC;
  signal \^axi_arready_reg_0\ : STD_LOGIC;
  signal axi_awready0 : STD_LOGIC;
  signal \^axi_awready_reg_0\ : STD_LOGIC;
  signal axi_bvalid_i_1_n_0 : STD_LOGIC;
  signal \axi_rdata[0]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[0]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[0]_i_6_n_0\ : STD_LOGIC;
  signal \axi_rdata[0]_i_7_n_0\ : STD_LOGIC;
  signal \axi_rdata[10]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[10]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[10]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[10]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[11]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[11]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[11]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[11]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[12]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[12]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[12]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[12]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[13]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[13]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[13]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[13]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[14]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[14]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[14]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[14]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[15]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[15]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[15]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[15]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[16]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[16]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[16]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[16]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[17]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[17]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[17]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[17]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[18]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[18]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[18]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[18]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[19]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[19]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[19]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[19]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[1]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[1]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[1]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[1]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[20]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[20]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[20]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[20]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[21]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[21]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[21]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[21]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[22]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[22]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[22]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[22]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[23]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[23]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[23]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[23]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[24]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[24]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[24]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[24]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[25]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[25]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[25]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[25]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[26]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[26]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[26]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[26]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[27]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[27]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[27]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[27]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[28]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[28]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[28]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[28]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[29]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[29]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[29]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[29]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[2]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[2]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[2]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[2]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[30]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[30]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[30]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[30]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[31]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[31]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[31]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[31]_i_6_n_0\ : STD_LOGIC;
  signal \axi_rdata[3]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[3]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[3]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[3]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[4]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[4]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[4]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[4]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[5]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[5]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[5]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[5]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[6]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[6]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[6]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[6]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[7]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[7]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[7]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[7]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[8]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[8]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[8]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[8]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata[9]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata[9]_i_3_n_0\ : STD_LOGIC;
  signal \axi_rdata[9]_i_4_n_0\ : STD_LOGIC;
  signal \axi_rdata[9]_i_5_n_0\ : STD_LOGIC;
  signal \axi_rdata_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \axi_rdata_reg[0]_i_3_n_0\ : STD_LOGIC;
  signal axi_rvalid_i_1_n_0 : STD_LOGIC;
  signal axi_wready0 : STD_LOGIC;
  signal \^axi_wready_reg_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal p_1_in : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal reg_data_out : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \^s00_axi_bvalid\ : STD_LOGIC;
  signal \^s00_axi_rvalid\ : STD_LOGIC;
  signal sel0 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \slv_reg0__0\ : STD_LOGIC_VECTOR ( 31 downto 1 );
  signal slv_reg10 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal slv_reg11 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal slv_reg12 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal slv_reg13 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal slv_reg14 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal slv_reg15 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal slv_reg2 : STD_LOGIC_VECTOR ( 0 to 0 );
  signal slv_reg3 : STD_LOGIC_VECTOR ( 0 to 0 );
  signal slv_reg4 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \slv_reg4[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg4[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg4[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg4[7]_i_1_n_0\ : STD_LOGIC;
  signal slv_reg5 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \slv_reg5[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg5[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg5[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg5[7]_i_1_n_0\ : STD_LOGIC;
  signal slv_reg6 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \slv_reg6[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg6[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg6[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg6[7]_i_1_n_0\ : STD_LOGIC;
  signal slv_reg7 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \slv_reg7[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg7[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg7[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg7[7]_i_1_n_0\ : STD_LOGIC;
  signal slv_reg8 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \slv_reg8[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg8[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg8[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg8[7]_i_1_n_0\ : STD_LOGIC;
  signal slv_reg9 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \slv_reg9[15]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg9[23]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg9[31]_i_1_n_0\ : STD_LOGIC;
  signal \slv_reg9[7]_i_1_n_0\ : STD_LOGIC;
  signal slv_reg_rden : STD_LOGIC;
  signal \slv_reg_wren__2\ : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \axi_rdata[10]_i_5\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \axi_rdata[11]_i_5\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \axi_rdata[12]_i_5\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \axi_rdata[13]_i_5\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \axi_rdata[14]_i_5\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \axi_rdata[15]_i_5\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \axi_rdata[16]_i_5\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \axi_rdata[17]_i_5\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \axi_rdata[18]_i_5\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \axi_rdata[19]_i_5\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \axi_rdata[1]_i_5\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \axi_rdata[20]_i_5\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \axi_rdata[21]_i_5\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \axi_rdata[22]_i_5\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \axi_rdata[23]_i_5\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \axi_rdata[24]_i_5\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \axi_rdata[25]_i_5\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \axi_rdata[26]_i_5\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \axi_rdata[27]_i_5\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \axi_rdata[28]_i_5\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \axi_rdata[29]_i_5\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \axi_rdata[2]_i_5\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \axi_rdata[30]_i_5\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \axi_rdata[3]_i_5\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \axi_rdata[4]_i_5\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \axi_rdata[5]_i_5\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \axi_rdata[6]_i_5\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \axi_rdata[7]_i_5\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \axi_rdata[8]_i_5\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \axi_rdata[9]_i_5\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of axi_wready_i_1 : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \slv_reg0[31]_i_2\ : label is "soft_lutpair17";
begin
  Q(0) <= \^q\(0);
  SR(0) <= \^sr\(0);
  axi_arready_reg_0 <= \^axi_arready_reg_0\;
  axi_awready_reg_0 <= \^axi_awready_reg_0\;
  axi_wready_reg_0 <= \^axi_wready_reg_0\;
  s00_axi_bvalid <= \^s00_axi_bvalid\;
  s00_axi_rvalid <= \^s00_axi_rvalid\;
\PPM_generator_output_0_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(0),
      Q => \PPM_generator_output_0_reg[21]_0\(0),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(10),
      Q => \PPM_generator_output_0_reg[21]_0\(10),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(11),
      Q => \PPM_generator_output_0_reg[21]_0\(11),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(12),
      Q => \PPM_generator_output_0_reg[21]_0\(12),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(13),
      Q => \PPM_generator_output_0_reg[21]_0\(13),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(14),
      Q => \PPM_generator_output_0_reg[21]_0\(14),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(15),
      Q => \PPM_generator_output_0_reg[21]_0\(15),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(16),
      Q => \PPM_generator_output_0_reg[21]_0\(16),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(17),
      Q => \PPM_generator_output_0_reg[21]_0\(17),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(18),
      Q => \PPM_generator_output_0_reg[21]_0\(18),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(19),
      Q => \PPM_generator_output_0_reg[21]_0\(19),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(1),
      Q => \PPM_generator_output_0_reg[21]_0\(1),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(20),
      Q => \PPM_generator_output_0_reg[21]_0\(20),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(21),
      Q => \PPM_generator_output_0_reg[21]_0\(21),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(2),
      Q => \PPM_generator_output_0_reg[21]_0\(2),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(3),
      Q => \PPM_generator_output_0_reg[21]_0\(3),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(4),
      Q => \PPM_generator_output_0_reg[21]_0\(4),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(5),
      Q => \PPM_generator_output_0_reg[21]_0\(5),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(6),
      Q => \PPM_generator_output_0_reg[21]_0\(6),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(7),
      Q => \PPM_generator_output_0_reg[21]_0\(7),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(8),
      Q => \PPM_generator_output_0_reg[21]_0\(8),
      R => \^sr\(0)
    );
\PPM_generator_output_0_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg4(9),
      Q => \PPM_generator_output_0_reg[21]_0\(9),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(0),
      Q => \PPM_generator_output_1_reg[21]_0\(0),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(10),
      Q => \PPM_generator_output_1_reg[21]_0\(10),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(11),
      Q => \PPM_generator_output_1_reg[21]_0\(11),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(12),
      Q => \PPM_generator_output_1_reg[21]_0\(12),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(13),
      Q => \PPM_generator_output_1_reg[21]_0\(13),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(14),
      Q => \PPM_generator_output_1_reg[21]_0\(14),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(15),
      Q => \PPM_generator_output_1_reg[21]_0\(15),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(16),
      Q => \PPM_generator_output_1_reg[21]_0\(16),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(17),
      Q => \PPM_generator_output_1_reg[21]_0\(17),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(18),
      Q => \PPM_generator_output_1_reg[21]_0\(18),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(19),
      Q => \PPM_generator_output_1_reg[21]_0\(19),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(1),
      Q => \PPM_generator_output_1_reg[21]_0\(1),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(20),
      Q => \PPM_generator_output_1_reg[21]_0\(20),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(21),
      Q => \PPM_generator_output_1_reg[21]_0\(21),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(2),
      Q => \PPM_generator_output_1_reg[21]_0\(2),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(3),
      Q => \PPM_generator_output_1_reg[21]_0\(3),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(4),
      Q => \PPM_generator_output_1_reg[21]_0\(4),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(5),
      Q => \PPM_generator_output_1_reg[21]_0\(5),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(6),
      Q => \PPM_generator_output_1_reg[21]_0\(6),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(7),
      Q => \PPM_generator_output_1_reg[21]_0\(7),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(8),
      Q => \PPM_generator_output_1_reg[21]_0\(8),
      R => \^sr\(0)
    );
\PPM_generator_output_1_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg5(9),
      Q => \PPM_generator_output_1_reg[21]_0\(9),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(0),
      Q => \PPM_generator_output_2_reg[21]_0\(0),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(10),
      Q => \PPM_generator_output_2_reg[21]_0\(10),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(11),
      Q => \PPM_generator_output_2_reg[21]_0\(11),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(12),
      Q => \PPM_generator_output_2_reg[21]_0\(12),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(13),
      Q => \PPM_generator_output_2_reg[21]_0\(13),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(14),
      Q => \PPM_generator_output_2_reg[21]_0\(14),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(15),
      Q => \PPM_generator_output_2_reg[21]_0\(15),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(16),
      Q => \PPM_generator_output_2_reg[21]_0\(16),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(17),
      Q => \PPM_generator_output_2_reg[21]_0\(17),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(18),
      Q => \PPM_generator_output_2_reg[21]_0\(18),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(19),
      Q => \PPM_generator_output_2_reg[21]_0\(19),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(1),
      Q => \PPM_generator_output_2_reg[21]_0\(1),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(20),
      Q => \PPM_generator_output_2_reg[21]_0\(20),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(21),
      Q => \PPM_generator_output_2_reg[21]_0\(21),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(2),
      Q => \PPM_generator_output_2_reg[21]_0\(2),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(3),
      Q => \PPM_generator_output_2_reg[21]_0\(3),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(4),
      Q => \PPM_generator_output_2_reg[21]_0\(4),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(5),
      Q => \PPM_generator_output_2_reg[21]_0\(5),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(6),
      Q => \PPM_generator_output_2_reg[21]_0\(6),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(7),
      Q => \PPM_generator_output_2_reg[21]_0\(7),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(8),
      Q => \PPM_generator_output_2_reg[21]_0\(8),
      R => \^sr\(0)
    );
\PPM_generator_output_2_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg6(9),
      Q => \PPM_generator_output_2_reg[21]_0\(9),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(0),
      Q => \PPM_generator_output_3_reg[21]_0\(0),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(10),
      Q => \PPM_generator_output_3_reg[21]_0\(10),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(11),
      Q => \PPM_generator_output_3_reg[21]_0\(11),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(12),
      Q => \PPM_generator_output_3_reg[21]_0\(12),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(13),
      Q => \PPM_generator_output_3_reg[21]_0\(13),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(14),
      Q => \PPM_generator_output_3_reg[21]_0\(14),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(15),
      Q => \PPM_generator_output_3_reg[21]_0\(15),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(16),
      Q => \PPM_generator_output_3_reg[21]_0\(16),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(17),
      Q => \PPM_generator_output_3_reg[21]_0\(17),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(18),
      Q => \PPM_generator_output_3_reg[21]_0\(18),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(19),
      Q => \PPM_generator_output_3_reg[21]_0\(19),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(1),
      Q => \PPM_generator_output_3_reg[21]_0\(1),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(20),
      Q => \PPM_generator_output_3_reg[21]_0\(20),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(21),
      Q => \PPM_generator_output_3_reg[21]_0\(21),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(2),
      Q => \PPM_generator_output_3_reg[21]_0\(2),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(3),
      Q => \PPM_generator_output_3_reg[21]_0\(3),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(4),
      Q => \PPM_generator_output_3_reg[21]_0\(4),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(5),
      Q => \PPM_generator_output_3_reg[21]_0\(5),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(6),
      Q => \PPM_generator_output_3_reg[21]_0\(6),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(7),
      Q => \PPM_generator_output_3_reg[21]_0\(7),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(8),
      Q => \PPM_generator_output_3_reg[21]_0\(8),
      R => \^sr\(0)
    );
\PPM_generator_output_3_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg7(9),
      Q => \PPM_generator_output_3_reg[21]_0\(9),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(0),
      Q => \PPM_generator_output_4_reg[21]_0\(0),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(10),
      Q => \PPM_generator_output_4_reg[21]_0\(10),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(11),
      Q => \PPM_generator_output_4_reg[21]_0\(11),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(12),
      Q => \PPM_generator_output_4_reg[21]_0\(12),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(13),
      Q => \PPM_generator_output_4_reg[21]_0\(13),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(14),
      Q => \PPM_generator_output_4_reg[21]_0\(14),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(15),
      Q => \PPM_generator_output_4_reg[21]_0\(15),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(16),
      Q => \PPM_generator_output_4_reg[21]_0\(16),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(17),
      Q => \PPM_generator_output_4_reg[21]_0\(17),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(18),
      Q => \PPM_generator_output_4_reg[21]_0\(18),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(19),
      Q => \PPM_generator_output_4_reg[21]_0\(19),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(1),
      Q => \PPM_generator_output_4_reg[21]_0\(1),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(20),
      Q => \PPM_generator_output_4_reg[21]_0\(20),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(21),
      Q => \PPM_generator_output_4_reg[21]_0\(21),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(2),
      Q => \PPM_generator_output_4_reg[21]_0\(2),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(3),
      Q => \PPM_generator_output_4_reg[21]_0\(3),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(4),
      Q => \PPM_generator_output_4_reg[21]_0\(4),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(5),
      Q => \PPM_generator_output_4_reg[21]_0\(5),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(6),
      Q => \PPM_generator_output_4_reg[21]_0\(6),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(7),
      Q => \PPM_generator_output_4_reg[21]_0\(7),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(8),
      Q => \PPM_generator_output_4_reg[21]_0\(8),
      R => \^sr\(0)
    );
\PPM_generator_output_4_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg8(9),
      Q => \PPM_generator_output_4_reg[21]_0\(9),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(0),
      Q => \PPM_generator_output_5_reg[21]_0\(0),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(10),
      Q => \PPM_generator_output_5_reg[21]_0\(10),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(11),
      Q => \PPM_generator_output_5_reg[21]_0\(11),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(12),
      Q => \PPM_generator_output_5_reg[21]_0\(12),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(13),
      Q => \PPM_generator_output_5_reg[21]_0\(13),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(14),
      Q => \PPM_generator_output_5_reg[21]_0\(14),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(15),
      Q => \PPM_generator_output_5_reg[21]_0\(15),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(16),
      Q => \PPM_generator_output_5_reg[21]_0\(16),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(17),
      Q => \PPM_generator_output_5_reg[21]_0\(17),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(18),
      Q => \PPM_generator_output_5_reg[21]_0\(18),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(19),
      Q => \PPM_generator_output_5_reg[21]_0\(19),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(1),
      Q => \PPM_generator_output_5_reg[21]_0\(1),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(20),
      Q => \PPM_generator_output_5_reg[21]_0\(20),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(21),
      Q => \PPM_generator_output_5_reg[21]_0\(21),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(2),
      Q => \PPM_generator_output_5_reg[21]_0\(2),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(3),
      Q => \PPM_generator_output_5_reg[21]_0\(3),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(4),
      Q => \PPM_generator_output_5_reg[21]_0\(4),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(5),
      Q => \PPM_generator_output_5_reg[21]_0\(5),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(6),
      Q => \PPM_generator_output_5_reg[21]_0\(6),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(7),
      Q => \PPM_generator_output_5_reg[21]_0\(7),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(8),
      Q => \PPM_generator_output_5_reg[21]_0\(8),
      R => \^sr\(0)
    );
\PPM_generator_output_5_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => slv_reg9(9),
      Q => \PPM_generator_output_5_reg[21]_0\(9),
      R => \^sr\(0)
    );
aw_en_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFFBF00BF00BF00"
    )
        port map (
      I0 => \^axi_awready_reg_0\,
      I1 => s00_axi_awvalid,
      I2 => s00_axi_wvalid,
      I3 => aw_en_reg_n_0,
      I4 => s00_axi_bready,
      I5 => \^s00_axi_bvalid\,
      O => aw_en_i_1_n_0
    );
aw_en_reg: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => aw_en_i_1_n_0,
      Q => aw_en_reg_n_0,
      S => \^sr\(0)
    );
\axi_araddr_reg[2]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready0,
      D => s00_axi_araddr(0),
      Q => sel0(0),
      S => \^sr\(0)
    );
\axi_araddr_reg[3]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready0,
      D => s00_axi_araddr(1),
      Q => sel0(1),
      S => \^sr\(0)
    );
\axi_araddr_reg[4]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready0,
      D => s00_axi_araddr(2),
      Q => sel0(2),
      S => \^sr\(0)
    );
\axi_araddr_reg[5]\: unisim.vcomponents.FDSE
     port map (
      C => s00_axi_aclk,
      CE => axi_arready0,
      D => s00_axi_araddr(3),
      Q => sel0(3),
      S => \^sr\(0)
    );
axi_arready_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => s00_axi_arvalid,
      I1 => \^axi_arready_reg_0\,
      O => axi_arready0
    );
axi_arready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_arready0,
      Q => \^axi_arready_reg_0\,
      R => \^sr\(0)
    );
\axi_awaddr_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(0),
      Q => p_0_in(0),
      R => \^sr\(0)
    );
\axi_awaddr_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(1),
      Q => p_0_in(1),
      R => \^sr\(0)
    );
\axi_awaddr_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(2),
      Q => p_0_in(2),
      R => \^sr\(0)
    );
\axi_awaddr_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => axi_awready0,
      D => s00_axi_awaddr(3),
      Q => p_0_in(3),
      R => \^sr\(0)
    );
axi_awready_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s00_axi_aresetn,
      O => \^sr\(0)
    );
axi_awready_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => aw_en_reg_n_0,
      I1 => s00_axi_wvalid,
      I2 => s00_axi_awvalid,
      I3 => \^axi_awready_reg_0\,
      O => axi_awready0
    );
axi_awready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_awready0,
      Q => \^axi_awready_reg_0\,
      R => \^sr\(0)
    );
axi_bvalid_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFFF80008000"
    )
        port map (
      I0 => s00_axi_awvalid,
      I1 => \^axi_awready_reg_0\,
      I2 => \^axi_wready_reg_0\,
      I3 => s00_axi_wvalid,
      I4 => s00_axi_bready,
      I5 => \^s00_axi_bvalid\,
      O => axi_bvalid_i_1_n_0
    );
axi_bvalid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_bvalid_i_1_n_0,
      Q => \^s00_axi_bvalid\,
      R => \^sr\(0)
    );
\axi_rdata[0]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A0A0CFC0"
    )
        port map (
      I0 => slv_reg3(0),
      I1 => slv_reg2(0),
      I2 => sel0(1),
      I3 => \^q\(0),
      I4 => sel0(0),
      O => \axi_rdata[0]_i_4_n_0\
    );
\axi_rdata[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(0),
      I1 => slv_reg6(0),
      I2 => sel0(1),
      I3 => slv_reg5(0),
      I4 => sel0(0),
      I5 => slv_reg4(0),
      O => \axi_rdata[0]_i_5_n_0\
    );
\axi_rdata[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(0),
      I1 => slv_reg10(0),
      I2 => sel0(1),
      I3 => slv_reg9(0),
      I4 => sel0(0),
      I5 => slv_reg8(0),
      O => \axi_rdata[0]_i_6_n_0\
    );
\axi_rdata[0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(0),
      I1 => slv_reg14(0),
      I2 => sel0(1),
      I3 => slv_reg13(0),
      I4 => sel0(0),
      I5 => slv_reg12(0),
      O => \axi_rdata[0]_i_7_n_0\
    );
\axi_rdata[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[10]_i_2_n_0\,
      I1 => \axi_rdata[10]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[10]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[10]_i_5_n_0\,
      O => reg_data_out(10)
    );
\axi_rdata[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(10),
      I1 => slv_reg14(10),
      I2 => sel0(1),
      I3 => slv_reg13(10),
      I4 => sel0(0),
      I5 => slv_reg12(10),
      O => \axi_rdata[10]_i_2_n_0\
    );
\axi_rdata[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(10),
      I1 => slv_reg10(10),
      I2 => sel0(1),
      I3 => slv_reg9(10),
      I4 => sel0(0),
      I5 => slv_reg8(10),
      O => \axi_rdata[10]_i_3_n_0\
    );
\axi_rdata[10]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(10),
      I1 => slv_reg6(10),
      I2 => sel0(1),
      I3 => slv_reg5(10),
      I4 => sel0(0),
      I5 => slv_reg4(10),
      O => \axi_rdata[10]_i_4_n_0\
    );
\axi_rdata[10]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(10),
      I2 => sel0(1),
      O => \axi_rdata[10]_i_5_n_0\
    );
\axi_rdata[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[11]_i_2_n_0\,
      I1 => \axi_rdata[11]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[11]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[11]_i_5_n_0\,
      O => reg_data_out(11)
    );
\axi_rdata[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(11),
      I1 => slv_reg14(11),
      I2 => sel0(1),
      I3 => slv_reg13(11),
      I4 => sel0(0),
      I5 => slv_reg12(11),
      O => \axi_rdata[11]_i_2_n_0\
    );
\axi_rdata[11]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(11),
      I1 => slv_reg10(11),
      I2 => sel0(1),
      I3 => slv_reg9(11),
      I4 => sel0(0),
      I5 => slv_reg8(11),
      O => \axi_rdata[11]_i_3_n_0\
    );
\axi_rdata[11]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(11),
      I1 => slv_reg6(11),
      I2 => sel0(1),
      I3 => slv_reg5(11),
      I4 => sel0(0),
      I5 => slv_reg4(11),
      O => \axi_rdata[11]_i_4_n_0\
    );
\axi_rdata[11]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(11),
      I2 => sel0(1),
      O => \axi_rdata[11]_i_5_n_0\
    );
\axi_rdata[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[12]_i_2_n_0\,
      I1 => \axi_rdata[12]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[12]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[12]_i_5_n_0\,
      O => reg_data_out(12)
    );
\axi_rdata[12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(12),
      I1 => slv_reg14(12),
      I2 => sel0(1),
      I3 => slv_reg13(12),
      I4 => sel0(0),
      I5 => slv_reg12(12),
      O => \axi_rdata[12]_i_2_n_0\
    );
\axi_rdata[12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(12),
      I1 => slv_reg10(12),
      I2 => sel0(1),
      I3 => slv_reg9(12),
      I4 => sel0(0),
      I5 => slv_reg8(12),
      O => \axi_rdata[12]_i_3_n_0\
    );
\axi_rdata[12]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(12),
      I1 => slv_reg6(12),
      I2 => sel0(1),
      I3 => slv_reg5(12),
      I4 => sel0(0),
      I5 => slv_reg4(12),
      O => \axi_rdata[12]_i_4_n_0\
    );
\axi_rdata[12]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(12),
      I2 => sel0(1),
      O => \axi_rdata[12]_i_5_n_0\
    );
\axi_rdata[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[13]_i_2_n_0\,
      I1 => \axi_rdata[13]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[13]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[13]_i_5_n_0\,
      O => reg_data_out(13)
    );
\axi_rdata[13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(13),
      I1 => slv_reg14(13),
      I2 => sel0(1),
      I3 => slv_reg13(13),
      I4 => sel0(0),
      I5 => slv_reg12(13),
      O => \axi_rdata[13]_i_2_n_0\
    );
\axi_rdata[13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(13),
      I1 => slv_reg10(13),
      I2 => sel0(1),
      I3 => slv_reg9(13),
      I4 => sel0(0),
      I5 => slv_reg8(13),
      O => \axi_rdata[13]_i_3_n_0\
    );
\axi_rdata[13]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(13),
      I1 => slv_reg6(13),
      I2 => sel0(1),
      I3 => slv_reg5(13),
      I4 => sel0(0),
      I5 => slv_reg4(13),
      O => \axi_rdata[13]_i_4_n_0\
    );
\axi_rdata[13]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(13),
      I2 => sel0(1),
      O => \axi_rdata[13]_i_5_n_0\
    );
\axi_rdata[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[14]_i_2_n_0\,
      I1 => \axi_rdata[14]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[14]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[14]_i_5_n_0\,
      O => reg_data_out(14)
    );
\axi_rdata[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(14),
      I1 => slv_reg14(14),
      I2 => sel0(1),
      I3 => slv_reg13(14),
      I4 => sel0(0),
      I5 => slv_reg12(14),
      O => \axi_rdata[14]_i_2_n_0\
    );
\axi_rdata[14]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(14),
      I1 => slv_reg10(14),
      I2 => sel0(1),
      I3 => slv_reg9(14),
      I4 => sel0(0),
      I5 => slv_reg8(14),
      O => \axi_rdata[14]_i_3_n_0\
    );
\axi_rdata[14]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(14),
      I1 => slv_reg6(14),
      I2 => sel0(1),
      I3 => slv_reg5(14),
      I4 => sel0(0),
      I5 => slv_reg4(14),
      O => \axi_rdata[14]_i_4_n_0\
    );
\axi_rdata[14]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(14),
      I2 => sel0(1),
      O => \axi_rdata[14]_i_5_n_0\
    );
\axi_rdata[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[15]_i_2_n_0\,
      I1 => \axi_rdata[15]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[15]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[15]_i_5_n_0\,
      O => reg_data_out(15)
    );
\axi_rdata[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(15),
      I1 => slv_reg14(15),
      I2 => sel0(1),
      I3 => slv_reg13(15),
      I4 => sel0(0),
      I5 => slv_reg12(15),
      O => \axi_rdata[15]_i_2_n_0\
    );
\axi_rdata[15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(15),
      I1 => slv_reg10(15),
      I2 => sel0(1),
      I3 => slv_reg9(15),
      I4 => sel0(0),
      I5 => slv_reg8(15),
      O => \axi_rdata[15]_i_3_n_0\
    );
\axi_rdata[15]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(15),
      I1 => slv_reg6(15),
      I2 => sel0(1),
      I3 => slv_reg5(15),
      I4 => sel0(0),
      I5 => slv_reg4(15),
      O => \axi_rdata[15]_i_4_n_0\
    );
\axi_rdata[15]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(15),
      I2 => sel0(1),
      O => \axi_rdata[15]_i_5_n_0\
    );
\axi_rdata[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[16]_i_2_n_0\,
      I1 => \axi_rdata[16]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[16]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[16]_i_5_n_0\,
      O => reg_data_out(16)
    );
\axi_rdata[16]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(16),
      I1 => slv_reg14(16),
      I2 => sel0(1),
      I3 => slv_reg13(16),
      I4 => sel0(0),
      I5 => slv_reg12(16),
      O => \axi_rdata[16]_i_2_n_0\
    );
\axi_rdata[16]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(16),
      I1 => slv_reg10(16),
      I2 => sel0(1),
      I3 => slv_reg9(16),
      I4 => sel0(0),
      I5 => slv_reg8(16),
      O => \axi_rdata[16]_i_3_n_0\
    );
\axi_rdata[16]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(16),
      I1 => slv_reg6(16),
      I2 => sel0(1),
      I3 => slv_reg5(16),
      I4 => sel0(0),
      I5 => slv_reg4(16),
      O => \axi_rdata[16]_i_4_n_0\
    );
\axi_rdata[16]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(16),
      I2 => sel0(1),
      O => \axi_rdata[16]_i_5_n_0\
    );
\axi_rdata[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[17]_i_2_n_0\,
      I1 => \axi_rdata[17]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[17]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[17]_i_5_n_0\,
      O => reg_data_out(17)
    );
\axi_rdata[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(17),
      I1 => slv_reg14(17),
      I2 => sel0(1),
      I3 => slv_reg13(17),
      I4 => sel0(0),
      I5 => slv_reg12(17),
      O => \axi_rdata[17]_i_2_n_0\
    );
\axi_rdata[17]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(17),
      I1 => slv_reg10(17),
      I2 => sel0(1),
      I3 => slv_reg9(17),
      I4 => sel0(0),
      I5 => slv_reg8(17),
      O => \axi_rdata[17]_i_3_n_0\
    );
\axi_rdata[17]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(17),
      I1 => slv_reg6(17),
      I2 => sel0(1),
      I3 => slv_reg5(17),
      I4 => sel0(0),
      I5 => slv_reg4(17),
      O => \axi_rdata[17]_i_4_n_0\
    );
\axi_rdata[17]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(17),
      I2 => sel0(1),
      O => \axi_rdata[17]_i_5_n_0\
    );
\axi_rdata[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[18]_i_2_n_0\,
      I1 => \axi_rdata[18]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[18]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[18]_i_5_n_0\,
      O => reg_data_out(18)
    );
\axi_rdata[18]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(18),
      I1 => slv_reg14(18),
      I2 => sel0(1),
      I3 => slv_reg13(18),
      I4 => sel0(0),
      I5 => slv_reg12(18),
      O => \axi_rdata[18]_i_2_n_0\
    );
\axi_rdata[18]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(18),
      I1 => slv_reg10(18),
      I2 => sel0(1),
      I3 => slv_reg9(18),
      I4 => sel0(0),
      I5 => slv_reg8(18),
      O => \axi_rdata[18]_i_3_n_0\
    );
\axi_rdata[18]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(18),
      I1 => slv_reg6(18),
      I2 => sel0(1),
      I3 => slv_reg5(18),
      I4 => sel0(0),
      I5 => slv_reg4(18),
      O => \axi_rdata[18]_i_4_n_0\
    );
\axi_rdata[18]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(18),
      I2 => sel0(1),
      O => \axi_rdata[18]_i_5_n_0\
    );
\axi_rdata[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[19]_i_2_n_0\,
      I1 => \axi_rdata[19]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[19]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[19]_i_5_n_0\,
      O => reg_data_out(19)
    );
\axi_rdata[19]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(19),
      I1 => slv_reg14(19),
      I2 => sel0(1),
      I3 => slv_reg13(19),
      I4 => sel0(0),
      I5 => slv_reg12(19),
      O => \axi_rdata[19]_i_2_n_0\
    );
\axi_rdata[19]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(19),
      I1 => slv_reg10(19),
      I2 => sel0(1),
      I3 => slv_reg9(19),
      I4 => sel0(0),
      I5 => slv_reg8(19),
      O => \axi_rdata[19]_i_3_n_0\
    );
\axi_rdata[19]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(19),
      I1 => slv_reg6(19),
      I2 => sel0(1),
      I3 => slv_reg5(19),
      I4 => sel0(0),
      I5 => slv_reg4(19),
      O => \axi_rdata[19]_i_4_n_0\
    );
\axi_rdata[19]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(19),
      I2 => sel0(1),
      O => \axi_rdata[19]_i_5_n_0\
    );
\axi_rdata[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[1]_i_2_n_0\,
      I1 => \axi_rdata[1]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[1]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[1]_i_5_n_0\,
      O => reg_data_out(1)
    );
\axi_rdata[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(1),
      I1 => slv_reg14(1),
      I2 => sel0(1),
      I3 => slv_reg13(1),
      I4 => sel0(0),
      I5 => slv_reg12(1),
      O => \axi_rdata[1]_i_2_n_0\
    );
\axi_rdata[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(1),
      I1 => slv_reg10(1),
      I2 => sel0(1),
      I3 => slv_reg9(1),
      I4 => sel0(0),
      I5 => slv_reg8(1),
      O => \axi_rdata[1]_i_3_n_0\
    );
\axi_rdata[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(1),
      I1 => slv_reg6(1),
      I2 => sel0(1),
      I3 => slv_reg5(1),
      I4 => sel0(0),
      I5 => slv_reg4(1),
      O => \axi_rdata[1]_i_4_n_0\
    );
\axi_rdata[1]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(1),
      I2 => sel0(1),
      O => \axi_rdata[1]_i_5_n_0\
    );
\axi_rdata[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[20]_i_2_n_0\,
      I1 => \axi_rdata[20]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[20]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[20]_i_5_n_0\,
      O => reg_data_out(20)
    );
\axi_rdata[20]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(20),
      I1 => slv_reg14(20),
      I2 => sel0(1),
      I3 => slv_reg13(20),
      I4 => sel0(0),
      I5 => slv_reg12(20),
      O => \axi_rdata[20]_i_2_n_0\
    );
\axi_rdata[20]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(20),
      I1 => slv_reg10(20),
      I2 => sel0(1),
      I3 => slv_reg9(20),
      I4 => sel0(0),
      I5 => slv_reg8(20),
      O => \axi_rdata[20]_i_3_n_0\
    );
\axi_rdata[20]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(20),
      I1 => slv_reg6(20),
      I2 => sel0(1),
      I3 => slv_reg5(20),
      I4 => sel0(0),
      I5 => slv_reg4(20),
      O => \axi_rdata[20]_i_4_n_0\
    );
\axi_rdata[20]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(20),
      I2 => sel0(1),
      O => \axi_rdata[20]_i_5_n_0\
    );
\axi_rdata[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[21]_i_2_n_0\,
      I1 => \axi_rdata[21]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[21]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[21]_i_5_n_0\,
      O => reg_data_out(21)
    );
\axi_rdata[21]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(21),
      I1 => slv_reg14(21),
      I2 => sel0(1),
      I3 => slv_reg13(21),
      I4 => sel0(0),
      I5 => slv_reg12(21),
      O => \axi_rdata[21]_i_2_n_0\
    );
\axi_rdata[21]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(21),
      I1 => slv_reg10(21),
      I2 => sel0(1),
      I3 => slv_reg9(21),
      I4 => sel0(0),
      I5 => slv_reg8(21),
      O => \axi_rdata[21]_i_3_n_0\
    );
\axi_rdata[21]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(21),
      I1 => slv_reg6(21),
      I2 => sel0(1),
      I3 => slv_reg5(21),
      I4 => sel0(0),
      I5 => slv_reg4(21),
      O => \axi_rdata[21]_i_4_n_0\
    );
\axi_rdata[21]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(21),
      I2 => sel0(1),
      O => \axi_rdata[21]_i_5_n_0\
    );
\axi_rdata[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[22]_i_2_n_0\,
      I1 => \axi_rdata[22]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[22]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[22]_i_5_n_0\,
      O => reg_data_out(22)
    );
\axi_rdata[22]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(22),
      I1 => slv_reg14(22),
      I2 => sel0(1),
      I3 => slv_reg13(22),
      I4 => sel0(0),
      I5 => slv_reg12(22),
      O => \axi_rdata[22]_i_2_n_0\
    );
\axi_rdata[22]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(22),
      I1 => slv_reg10(22),
      I2 => sel0(1),
      I3 => slv_reg9(22),
      I4 => sel0(0),
      I5 => slv_reg8(22),
      O => \axi_rdata[22]_i_3_n_0\
    );
\axi_rdata[22]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(22),
      I1 => slv_reg6(22),
      I2 => sel0(1),
      I3 => slv_reg5(22),
      I4 => sel0(0),
      I5 => slv_reg4(22),
      O => \axi_rdata[22]_i_4_n_0\
    );
\axi_rdata[22]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(22),
      I2 => sel0(1),
      O => \axi_rdata[22]_i_5_n_0\
    );
\axi_rdata[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[23]_i_2_n_0\,
      I1 => \axi_rdata[23]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[23]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[23]_i_5_n_0\,
      O => reg_data_out(23)
    );
\axi_rdata[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(23),
      I1 => slv_reg14(23),
      I2 => sel0(1),
      I3 => slv_reg13(23),
      I4 => sel0(0),
      I5 => slv_reg12(23),
      O => \axi_rdata[23]_i_2_n_0\
    );
\axi_rdata[23]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(23),
      I1 => slv_reg10(23),
      I2 => sel0(1),
      I3 => slv_reg9(23),
      I4 => sel0(0),
      I5 => slv_reg8(23),
      O => \axi_rdata[23]_i_3_n_0\
    );
\axi_rdata[23]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(23),
      I1 => slv_reg6(23),
      I2 => sel0(1),
      I3 => slv_reg5(23),
      I4 => sel0(0),
      I5 => slv_reg4(23),
      O => \axi_rdata[23]_i_4_n_0\
    );
\axi_rdata[23]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(23),
      I2 => sel0(1),
      O => \axi_rdata[23]_i_5_n_0\
    );
\axi_rdata[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[24]_i_2_n_0\,
      I1 => \axi_rdata[24]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[24]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[24]_i_5_n_0\,
      O => reg_data_out(24)
    );
\axi_rdata[24]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(24),
      I1 => slv_reg14(24),
      I2 => sel0(1),
      I3 => slv_reg13(24),
      I4 => sel0(0),
      I5 => slv_reg12(24),
      O => \axi_rdata[24]_i_2_n_0\
    );
\axi_rdata[24]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(24),
      I1 => slv_reg10(24),
      I2 => sel0(1),
      I3 => slv_reg9(24),
      I4 => sel0(0),
      I5 => slv_reg8(24),
      O => \axi_rdata[24]_i_3_n_0\
    );
\axi_rdata[24]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(24),
      I1 => slv_reg6(24),
      I2 => sel0(1),
      I3 => slv_reg5(24),
      I4 => sel0(0),
      I5 => slv_reg4(24),
      O => \axi_rdata[24]_i_4_n_0\
    );
\axi_rdata[24]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(24),
      I2 => sel0(1),
      O => \axi_rdata[24]_i_5_n_0\
    );
\axi_rdata[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[25]_i_2_n_0\,
      I1 => \axi_rdata[25]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[25]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[25]_i_5_n_0\,
      O => reg_data_out(25)
    );
\axi_rdata[25]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(25),
      I1 => slv_reg14(25),
      I2 => sel0(1),
      I3 => slv_reg13(25),
      I4 => sel0(0),
      I5 => slv_reg12(25),
      O => \axi_rdata[25]_i_2_n_0\
    );
\axi_rdata[25]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(25),
      I1 => slv_reg10(25),
      I2 => sel0(1),
      I3 => slv_reg9(25),
      I4 => sel0(0),
      I5 => slv_reg8(25),
      O => \axi_rdata[25]_i_3_n_0\
    );
\axi_rdata[25]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(25),
      I1 => slv_reg6(25),
      I2 => sel0(1),
      I3 => slv_reg5(25),
      I4 => sel0(0),
      I5 => slv_reg4(25),
      O => \axi_rdata[25]_i_4_n_0\
    );
\axi_rdata[25]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(25),
      I2 => sel0(1),
      O => \axi_rdata[25]_i_5_n_0\
    );
\axi_rdata[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[26]_i_2_n_0\,
      I1 => \axi_rdata[26]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[26]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[26]_i_5_n_0\,
      O => reg_data_out(26)
    );
\axi_rdata[26]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(26),
      I1 => slv_reg14(26),
      I2 => sel0(1),
      I3 => slv_reg13(26),
      I4 => sel0(0),
      I5 => slv_reg12(26),
      O => \axi_rdata[26]_i_2_n_0\
    );
\axi_rdata[26]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(26),
      I1 => slv_reg10(26),
      I2 => sel0(1),
      I3 => slv_reg9(26),
      I4 => sel0(0),
      I5 => slv_reg8(26),
      O => \axi_rdata[26]_i_3_n_0\
    );
\axi_rdata[26]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(26),
      I1 => slv_reg6(26),
      I2 => sel0(1),
      I3 => slv_reg5(26),
      I4 => sel0(0),
      I5 => slv_reg4(26),
      O => \axi_rdata[26]_i_4_n_0\
    );
\axi_rdata[26]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(26),
      I2 => sel0(1),
      O => \axi_rdata[26]_i_5_n_0\
    );
\axi_rdata[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[27]_i_2_n_0\,
      I1 => \axi_rdata[27]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[27]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[27]_i_5_n_0\,
      O => reg_data_out(27)
    );
\axi_rdata[27]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(27),
      I1 => slv_reg14(27),
      I2 => sel0(1),
      I3 => slv_reg13(27),
      I4 => sel0(0),
      I5 => slv_reg12(27),
      O => \axi_rdata[27]_i_2_n_0\
    );
\axi_rdata[27]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(27),
      I1 => slv_reg10(27),
      I2 => sel0(1),
      I3 => slv_reg9(27),
      I4 => sel0(0),
      I5 => slv_reg8(27),
      O => \axi_rdata[27]_i_3_n_0\
    );
\axi_rdata[27]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(27),
      I1 => slv_reg6(27),
      I2 => sel0(1),
      I3 => slv_reg5(27),
      I4 => sel0(0),
      I5 => slv_reg4(27),
      O => \axi_rdata[27]_i_4_n_0\
    );
\axi_rdata[27]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(27),
      I2 => sel0(1),
      O => \axi_rdata[27]_i_5_n_0\
    );
\axi_rdata[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[28]_i_2_n_0\,
      I1 => \axi_rdata[28]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[28]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[28]_i_5_n_0\,
      O => reg_data_out(28)
    );
\axi_rdata[28]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(28),
      I1 => slv_reg14(28),
      I2 => sel0(1),
      I3 => slv_reg13(28),
      I4 => sel0(0),
      I5 => slv_reg12(28),
      O => \axi_rdata[28]_i_2_n_0\
    );
\axi_rdata[28]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(28),
      I1 => slv_reg10(28),
      I2 => sel0(1),
      I3 => slv_reg9(28),
      I4 => sel0(0),
      I5 => slv_reg8(28),
      O => \axi_rdata[28]_i_3_n_0\
    );
\axi_rdata[28]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(28),
      I1 => slv_reg6(28),
      I2 => sel0(1),
      I3 => slv_reg5(28),
      I4 => sel0(0),
      I5 => slv_reg4(28),
      O => \axi_rdata[28]_i_4_n_0\
    );
\axi_rdata[28]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(28),
      I2 => sel0(1),
      O => \axi_rdata[28]_i_5_n_0\
    );
\axi_rdata[29]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[29]_i_2_n_0\,
      I1 => \axi_rdata[29]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[29]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[29]_i_5_n_0\,
      O => reg_data_out(29)
    );
\axi_rdata[29]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(29),
      I1 => slv_reg14(29),
      I2 => sel0(1),
      I3 => slv_reg13(29),
      I4 => sel0(0),
      I5 => slv_reg12(29),
      O => \axi_rdata[29]_i_2_n_0\
    );
\axi_rdata[29]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(29),
      I1 => slv_reg10(29),
      I2 => sel0(1),
      I3 => slv_reg9(29),
      I4 => sel0(0),
      I5 => slv_reg8(29),
      O => \axi_rdata[29]_i_3_n_0\
    );
\axi_rdata[29]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(29),
      I1 => slv_reg6(29),
      I2 => sel0(1),
      I3 => slv_reg5(29),
      I4 => sel0(0),
      I5 => slv_reg4(29),
      O => \axi_rdata[29]_i_4_n_0\
    );
\axi_rdata[29]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(29),
      I2 => sel0(1),
      O => \axi_rdata[29]_i_5_n_0\
    );
\axi_rdata[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[2]_i_2_n_0\,
      I1 => \axi_rdata[2]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[2]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[2]_i_5_n_0\,
      O => reg_data_out(2)
    );
\axi_rdata[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(2),
      I1 => slv_reg14(2),
      I2 => sel0(1),
      I3 => slv_reg13(2),
      I4 => sel0(0),
      I5 => slv_reg12(2),
      O => \axi_rdata[2]_i_2_n_0\
    );
\axi_rdata[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(2),
      I1 => slv_reg10(2),
      I2 => sel0(1),
      I3 => slv_reg9(2),
      I4 => sel0(0),
      I5 => slv_reg8(2),
      O => \axi_rdata[2]_i_3_n_0\
    );
\axi_rdata[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(2),
      I1 => slv_reg6(2),
      I2 => sel0(1),
      I3 => slv_reg5(2),
      I4 => sel0(0),
      I5 => slv_reg4(2),
      O => \axi_rdata[2]_i_4_n_0\
    );
\axi_rdata[2]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(2),
      I2 => sel0(1),
      O => \axi_rdata[2]_i_5_n_0\
    );
\axi_rdata[30]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[30]_i_2_n_0\,
      I1 => \axi_rdata[30]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[30]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[30]_i_5_n_0\,
      O => reg_data_out(30)
    );
\axi_rdata[30]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(30),
      I1 => slv_reg14(30),
      I2 => sel0(1),
      I3 => slv_reg13(30),
      I4 => sel0(0),
      I5 => slv_reg12(30),
      O => \axi_rdata[30]_i_2_n_0\
    );
\axi_rdata[30]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(30),
      I1 => slv_reg10(30),
      I2 => sel0(1),
      I3 => slv_reg9(30),
      I4 => sel0(0),
      I5 => slv_reg8(30),
      O => \axi_rdata[30]_i_3_n_0\
    );
\axi_rdata[30]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(30),
      I1 => slv_reg6(30),
      I2 => sel0(1),
      I3 => slv_reg5(30),
      I4 => sel0(0),
      I5 => slv_reg4(30),
      O => \axi_rdata[30]_i_4_n_0\
    );
\axi_rdata[30]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(30),
      I2 => sel0(1),
      O => \axi_rdata[30]_i_5_n_0\
    );
\axi_rdata[31]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => \^axi_arready_reg_0\,
      I1 => s00_axi_arvalid,
      I2 => \^s00_axi_rvalid\,
      O => slv_reg_rden
    );
\axi_rdata[31]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[31]_i_3_n_0\,
      I1 => \axi_rdata[31]_i_4_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[31]_i_5_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[31]_i_6_n_0\,
      O => reg_data_out(31)
    );
\axi_rdata[31]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(31),
      I1 => slv_reg14(31),
      I2 => sel0(1),
      I3 => slv_reg13(31),
      I4 => sel0(0),
      I5 => slv_reg12(31),
      O => \axi_rdata[31]_i_3_n_0\
    );
\axi_rdata[31]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(31),
      I1 => slv_reg10(31),
      I2 => sel0(1),
      I3 => slv_reg9(31),
      I4 => sel0(0),
      I5 => slv_reg8(31),
      O => \axi_rdata[31]_i_4_n_0\
    );
\axi_rdata[31]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(31),
      I1 => slv_reg6(31),
      I2 => sel0(1),
      I3 => slv_reg5(31),
      I4 => sel0(0),
      I5 => slv_reg4(31),
      O => \axi_rdata[31]_i_5_n_0\
    );
\axi_rdata[31]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(31),
      I2 => sel0(1),
      O => \axi_rdata[31]_i_6_n_0\
    );
\axi_rdata[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[3]_i_2_n_0\,
      I1 => \axi_rdata[3]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[3]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[3]_i_5_n_0\,
      O => reg_data_out(3)
    );
\axi_rdata[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(3),
      I1 => slv_reg14(3),
      I2 => sel0(1),
      I3 => slv_reg13(3),
      I4 => sel0(0),
      I5 => slv_reg12(3),
      O => \axi_rdata[3]_i_2_n_0\
    );
\axi_rdata[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(3),
      I1 => slv_reg10(3),
      I2 => sel0(1),
      I3 => slv_reg9(3),
      I4 => sel0(0),
      I5 => slv_reg8(3),
      O => \axi_rdata[3]_i_3_n_0\
    );
\axi_rdata[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(3),
      I1 => slv_reg6(3),
      I2 => sel0(1),
      I3 => slv_reg5(3),
      I4 => sel0(0),
      I5 => slv_reg4(3),
      O => \axi_rdata[3]_i_4_n_0\
    );
\axi_rdata[3]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(3),
      I2 => sel0(1),
      O => \axi_rdata[3]_i_5_n_0\
    );
\axi_rdata[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[4]_i_2_n_0\,
      I1 => \axi_rdata[4]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[4]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[4]_i_5_n_0\,
      O => reg_data_out(4)
    );
\axi_rdata[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(4),
      I1 => slv_reg14(4),
      I2 => sel0(1),
      I3 => slv_reg13(4),
      I4 => sel0(0),
      I5 => slv_reg12(4),
      O => \axi_rdata[4]_i_2_n_0\
    );
\axi_rdata[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(4),
      I1 => slv_reg10(4),
      I2 => sel0(1),
      I3 => slv_reg9(4),
      I4 => sel0(0),
      I5 => slv_reg8(4),
      O => \axi_rdata[4]_i_3_n_0\
    );
\axi_rdata[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(4),
      I1 => slv_reg6(4),
      I2 => sel0(1),
      I3 => slv_reg5(4),
      I4 => sel0(0),
      I5 => slv_reg4(4),
      O => \axi_rdata[4]_i_4_n_0\
    );
\axi_rdata[4]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(4),
      I2 => sel0(1),
      O => \axi_rdata[4]_i_5_n_0\
    );
\axi_rdata[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[5]_i_2_n_0\,
      I1 => \axi_rdata[5]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[5]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[5]_i_5_n_0\,
      O => reg_data_out(5)
    );
\axi_rdata[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(5),
      I1 => slv_reg14(5),
      I2 => sel0(1),
      I3 => slv_reg13(5),
      I4 => sel0(0),
      I5 => slv_reg12(5),
      O => \axi_rdata[5]_i_2_n_0\
    );
\axi_rdata[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(5),
      I1 => slv_reg10(5),
      I2 => sel0(1),
      I3 => slv_reg9(5),
      I4 => sel0(0),
      I5 => slv_reg8(5),
      O => \axi_rdata[5]_i_3_n_0\
    );
\axi_rdata[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(5),
      I1 => slv_reg6(5),
      I2 => sel0(1),
      I3 => slv_reg5(5),
      I4 => sel0(0),
      I5 => slv_reg4(5),
      O => \axi_rdata[5]_i_4_n_0\
    );
\axi_rdata[5]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(5),
      I2 => sel0(1),
      O => \axi_rdata[5]_i_5_n_0\
    );
\axi_rdata[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[6]_i_2_n_0\,
      I1 => \axi_rdata[6]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[6]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[6]_i_5_n_0\,
      O => reg_data_out(6)
    );
\axi_rdata[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(6),
      I1 => slv_reg14(6),
      I2 => sel0(1),
      I3 => slv_reg13(6),
      I4 => sel0(0),
      I5 => slv_reg12(6),
      O => \axi_rdata[6]_i_2_n_0\
    );
\axi_rdata[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(6),
      I1 => slv_reg10(6),
      I2 => sel0(1),
      I3 => slv_reg9(6),
      I4 => sel0(0),
      I5 => slv_reg8(6),
      O => \axi_rdata[6]_i_3_n_0\
    );
\axi_rdata[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(6),
      I1 => slv_reg6(6),
      I2 => sel0(1),
      I3 => slv_reg5(6),
      I4 => sel0(0),
      I5 => slv_reg4(6),
      O => \axi_rdata[6]_i_4_n_0\
    );
\axi_rdata[6]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(6),
      I2 => sel0(1),
      O => \axi_rdata[6]_i_5_n_0\
    );
\axi_rdata[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[7]_i_2_n_0\,
      I1 => \axi_rdata[7]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[7]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[7]_i_5_n_0\,
      O => reg_data_out(7)
    );
\axi_rdata[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(7),
      I1 => slv_reg14(7),
      I2 => sel0(1),
      I3 => slv_reg13(7),
      I4 => sel0(0),
      I5 => slv_reg12(7),
      O => \axi_rdata[7]_i_2_n_0\
    );
\axi_rdata[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(7),
      I1 => slv_reg10(7),
      I2 => sel0(1),
      I3 => slv_reg9(7),
      I4 => sel0(0),
      I5 => slv_reg8(7),
      O => \axi_rdata[7]_i_3_n_0\
    );
\axi_rdata[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(7),
      I1 => slv_reg6(7),
      I2 => sel0(1),
      I3 => slv_reg5(7),
      I4 => sel0(0),
      I5 => slv_reg4(7),
      O => \axi_rdata[7]_i_4_n_0\
    );
\axi_rdata[7]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(7),
      I2 => sel0(1),
      O => \axi_rdata[7]_i_5_n_0\
    );
\axi_rdata[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[8]_i_2_n_0\,
      I1 => \axi_rdata[8]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[8]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[8]_i_5_n_0\,
      O => reg_data_out(8)
    );
\axi_rdata[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(8),
      I1 => slv_reg14(8),
      I2 => sel0(1),
      I3 => slv_reg13(8),
      I4 => sel0(0),
      I5 => slv_reg12(8),
      O => \axi_rdata[8]_i_2_n_0\
    );
\axi_rdata[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(8),
      I1 => slv_reg10(8),
      I2 => sel0(1),
      I3 => slv_reg9(8),
      I4 => sel0(0),
      I5 => slv_reg8(8),
      O => \axi_rdata[8]_i_3_n_0\
    );
\axi_rdata[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(8),
      I1 => slv_reg6(8),
      I2 => sel0(1),
      I3 => slv_reg5(8),
      I4 => sel0(0),
      I5 => slv_reg4(8),
      O => \axi_rdata[8]_i_4_n_0\
    );
\axi_rdata[8]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(8),
      I2 => sel0(1),
      O => \axi_rdata[8]_i_5_n_0\
    );
\axi_rdata[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \axi_rdata[9]_i_2_n_0\,
      I1 => \axi_rdata[9]_i_3_n_0\,
      I2 => sel0(3),
      I3 => \axi_rdata[9]_i_4_n_0\,
      I4 => sel0(2),
      I5 => \axi_rdata[9]_i_5_n_0\,
      O => reg_data_out(9)
    );
\axi_rdata[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg15(9),
      I1 => slv_reg14(9),
      I2 => sel0(1),
      I3 => slv_reg13(9),
      I4 => sel0(0),
      I5 => slv_reg12(9),
      O => \axi_rdata[9]_i_2_n_0\
    );
\axi_rdata[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg11(9),
      I1 => slv_reg10(9),
      I2 => sel0(1),
      I3 => slv_reg9(9),
      I4 => sel0(0),
      I5 => slv_reg8(9),
      O => \axi_rdata[9]_i_3_n_0\
    );
\axi_rdata[9]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => slv_reg7(9),
      I1 => slv_reg6(9),
      I2 => sel0(1),
      I3 => slv_reg5(9),
      I4 => sel0(0),
      I5 => slv_reg4(9),
      O => \axi_rdata[9]_i_4_n_0\
    );
\axi_rdata[9]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => sel0(0),
      I1 => \slv_reg0__0\(9),
      I2 => sel0(1),
      O => \axi_rdata[9]_i_5_n_0\
    );
\axi_rdata_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(0),
      Q => s00_axi_rdata(0),
      R => \^sr\(0)
    );
\axi_rdata_reg[0]_i_1\: unisim.vcomponents.MUXF8
     port map (
      I0 => \axi_rdata_reg[0]_i_2_n_0\,
      I1 => \axi_rdata_reg[0]_i_3_n_0\,
      O => reg_data_out(0),
      S => sel0(3)
    );
\axi_rdata_reg[0]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \axi_rdata[0]_i_4_n_0\,
      I1 => \axi_rdata[0]_i_5_n_0\,
      O => \axi_rdata_reg[0]_i_2_n_0\,
      S => sel0(2)
    );
\axi_rdata_reg[0]_i_3\: unisim.vcomponents.MUXF7
     port map (
      I0 => \axi_rdata[0]_i_6_n_0\,
      I1 => \axi_rdata[0]_i_7_n_0\,
      O => \axi_rdata_reg[0]_i_3_n_0\,
      S => sel0(2)
    );
\axi_rdata_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(10),
      Q => s00_axi_rdata(10),
      R => \^sr\(0)
    );
\axi_rdata_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(11),
      Q => s00_axi_rdata(11),
      R => \^sr\(0)
    );
\axi_rdata_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(12),
      Q => s00_axi_rdata(12),
      R => \^sr\(0)
    );
\axi_rdata_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(13),
      Q => s00_axi_rdata(13),
      R => \^sr\(0)
    );
\axi_rdata_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(14),
      Q => s00_axi_rdata(14),
      R => \^sr\(0)
    );
\axi_rdata_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(15),
      Q => s00_axi_rdata(15),
      R => \^sr\(0)
    );
\axi_rdata_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(16),
      Q => s00_axi_rdata(16),
      R => \^sr\(0)
    );
\axi_rdata_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(17),
      Q => s00_axi_rdata(17),
      R => \^sr\(0)
    );
\axi_rdata_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(18),
      Q => s00_axi_rdata(18),
      R => \^sr\(0)
    );
\axi_rdata_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(19),
      Q => s00_axi_rdata(19),
      R => \^sr\(0)
    );
\axi_rdata_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(1),
      Q => s00_axi_rdata(1),
      R => \^sr\(0)
    );
\axi_rdata_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(20),
      Q => s00_axi_rdata(20),
      R => \^sr\(0)
    );
\axi_rdata_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(21),
      Q => s00_axi_rdata(21),
      R => \^sr\(0)
    );
\axi_rdata_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(22),
      Q => s00_axi_rdata(22),
      R => \^sr\(0)
    );
\axi_rdata_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(23),
      Q => s00_axi_rdata(23),
      R => \^sr\(0)
    );
\axi_rdata_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(24),
      Q => s00_axi_rdata(24),
      R => \^sr\(0)
    );
\axi_rdata_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(25),
      Q => s00_axi_rdata(25),
      R => \^sr\(0)
    );
\axi_rdata_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(26),
      Q => s00_axi_rdata(26),
      R => \^sr\(0)
    );
\axi_rdata_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(27),
      Q => s00_axi_rdata(27),
      R => \^sr\(0)
    );
\axi_rdata_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(28),
      Q => s00_axi_rdata(28),
      R => \^sr\(0)
    );
\axi_rdata_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(29),
      Q => s00_axi_rdata(29),
      R => \^sr\(0)
    );
\axi_rdata_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(2),
      Q => s00_axi_rdata(2),
      R => \^sr\(0)
    );
\axi_rdata_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(30),
      Q => s00_axi_rdata(30),
      R => \^sr\(0)
    );
\axi_rdata_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(31),
      Q => s00_axi_rdata(31),
      R => \^sr\(0)
    );
\axi_rdata_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(3),
      Q => s00_axi_rdata(3),
      R => \^sr\(0)
    );
\axi_rdata_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(4),
      Q => s00_axi_rdata(4),
      R => \^sr\(0)
    );
\axi_rdata_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(5),
      Q => s00_axi_rdata(5),
      R => \^sr\(0)
    );
\axi_rdata_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(6),
      Q => s00_axi_rdata(6),
      R => \^sr\(0)
    );
\axi_rdata_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(7),
      Q => s00_axi_rdata(7),
      R => \^sr\(0)
    );
\axi_rdata_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(8),
      Q => s00_axi_rdata(8),
      R => \^sr\(0)
    );
\axi_rdata_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => slv_reg_rden,
      D => reg_data_out(9),
      Q => s00_axi_rdata(9),
      R => \^sr\(0)
    );
axi_rvalid_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08F8"
    )
        port map (
      I0 => s00_axi_arvalid,
      I1 => \^axi_arready_reg_0\,
      I2 => \^s00_axi_rvalid\,
      I3 => s00_axi_rready,
      O => axi_rvalid_i_1_n_0
    );
axi_rvalid_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_rvalid_i_1_n_0,
      Q => \^s00_axi_rvalid\,
      R => \^sr\(0)
    );
axi_wready_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => aw_en_reg_n_0,
      I1 => s00_axi_wvalid,
      I2 => s00_axi_awvalid,
      I3 => \^axi_wready_reg_0\,
      O => axi_wready0
    );
axi_wready_reg: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => axi_wready0,
      Q => \^axi_wready_reg_0\,
      R => \^sr\(0)
    );
\slv_reg0[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(0),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(1),
      O => p_1_in(15)
    );
\slv_reg0[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(0),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(2),
      O => p_1_in(23)
    );
\slv_reg0[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(0),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(3),
      O => p_1_in(31)
    );
\slv_reg0[31]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => s00_axi_awvalid,
      I1 => \^axi_awready_reg_0\,
      I2 => \^axi_wready_reg_0\,
      I3 => s00_axi_wvalid,
      O => \slv_reg_wren__2\
    );
\slv_reg0[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(0),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(0),
      O => p_1_in(0)
    );
\slv_reg0_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(0),
      Q => \^q\(0),
      R => \^sr\(0)
    );
\slv_reg0_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(10),
      Q => \slv_reg0__0\(10),
      R => \^sr\(0)
    );
\slv_reg0_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(11),
      Q => \slv_reg0__0\(11),
      R => \^sr\(0)
    );
\slv_reg0_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(12),
      Q => \slv_reg0__0\(12),
      R => \^sr\(0)
    );
\slv_reg0_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(13),
      Q => \slv_reg0__0\(13),
      R => \^sr\(0)
    );
\slv_reg0_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(14),
      Q => \slv_reg0__0\(14),
      R => \^sr\(0)
    );
\slv_reg0_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(15),
      Q => \slv_reg0__0\(15),
      R => \^sr\(0)
    );
\slv_reg0_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(16),
      Q => \slv_reg0__0\(16),
      R => \^sr\(0)
    );
\slv_reg0_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(17),
      Q => \slv_reg0__0\(17),
      R => \^sr\(0)
    );
\slv_reg0_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(18),
      Q => \slv_reg0__0\(18),
      R => \^sr\(0)
    );
\slv_reg0_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(19),
      Q => \slv_reg0__0\(19),
      R => \^sr\(0)
    );
\slv_reg0_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(1),
      Q => \slv_reg0__0\(1),
      R => \^sr\(0)
    );
\slv_reg0_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(20),
      Q => \slv_reg0__0\(20),
      R => \^sr\(0)
    );
\slv_reg0_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(21),
      Q => \slv_reg0__0\(21),
      R => \^sr\(0)
    );
\slv_reg0_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(22),
      Q => \slv_reg0__0\(22),
      R => \^sr\(0)
    );
\slv_reg0_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(23),
      D => s00_axi_wdata(23),
      Q => \slv_reg0__0\(23),
      R => \^sr\(0)
    );
\slv_reg0_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(24),
      Q => \slv_reg0__0\(24),
      R => \^sr\(0)
    );
\slv_reg0_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(25),
      Q => \slv_reg0__0\(25),
      R => \^sr\(0)
    );
\slv_reg0_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(26),
      Q => \slv_reg0__0\(26),
      R => \^sr\(0)
    );
\slv_reg0_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(27),
      Q => \slv_reg0__0\(27),
      R => \^sr\(0)
    );
\slv_reg0_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(28),
      Q => \slv_reg0__0\(28),
      R => \^sr\(0)
    );
\slv_reg0_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(29),
      Q => \slv_reg0__0\(29),
      R => \^sr\(0)
    );
\slv_reg0_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(2),
      Q => \slv_reg0__0\(2),
      R => \^sr\(0)
    );
\slv_reg0_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(30),
      Q => \slv_reg0__0\(30),
      R => \^sr\(0)
    );
\slv_reg0_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(31),
      D => s00_axi_wdata(31),
      Q => \slv_reg0__0\(31),
      R => \^sr\(0)
    );
\slv_reg0_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(3),
      Q => \slv_reg0__0\(3),
      R => \^sr\(0)
    );
\slv_reg0_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(4),
      Q => \slv_reg0__0\(4),
      R => \^sr\(0)
    );
\slv_reg0_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(5),
      Q => \slv_reg0__0\(5),
      R => \^sr\(0)
    );
\slv_reg0_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(6),
      Q => \slv_reg0__0\(6),
      R => \^sr\(0)
    );
\slv_reg0_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(0),
      D => s00_axi_wdata(7),
      Q => \slv_reg0__0\(7),
      R => \^sr\(0)
    );
\slv_reg0_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(8),
      Q => \slv_reg0__0\(8),
      R => \^sr\(0)
    );
\slv_reg0_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => p_1_in(15),
      D => s00_axi_wdata(9),
      Q => \slv_reg0__0\(9),
      R => \^sr\(0)
    );
\slv_reg10_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(0),
      Q => slv_reg10(0),
      R => \^sr\(0)
    );
\slv_reg10_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(10),
      Q => slv_reg10(10),
      R => \^sr\(0)
    );
\slv_reg10_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(11),
      Q => slv_reg10(11),
      R => \^sr\(0)
    );
\slv_reg10_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(12),
      Q => slv_reg10(12),
      R => \^sr\(0)
    );
\slv_reg10_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(13),
      Q => slv_reg10(13),
      R => \^sr\(0)
    );
\slv_reg10_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(14),
      Q => slv_reg10(14),
      R => \^sr\(0)
    );
\slv_reg10_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(15),
      Q => slv_reg10(15),
      R => \^sr\(0)
    );
\slv_reg10_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(16),
      Q => slv_reg10(16),
      R => \^sr\(0)
    );
\slv_reg10_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(17),
      Q => slv_reg10(17),
      R => \^sr\(0)
    );
\slv_reg10_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(18),
      Q => slv_reg10(18),
      R => \^sr\(0)
    );
\slv_reg10_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(19),
      Q => slv_reg10(19),
      R => \^sr\(0)
    );
\slv_reg10_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(1),
      Q => slv_reg10(1),
      R => \^sr\(0)
    );
\slv_reg10_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(20),
      Q => slv_reg10(20),
      R => \^sr\(0)
    );
\slv_reg10_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(21),
      Q => slv_reg10(21),
      R => \^sr\(0)
    );
\slv_reg10_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(22),
      Q => slv_reg10(22),
      R => \^sr\(0)
    );
\slv_reg10_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(23),
      Q => slv_reg10(23),
      R => \^sr\(0)
    );
\slv_reg10_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(24),
      Q => slv_reg10(24),
      R => \^sr\(0)
    );
\slv_reg10_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(25),
      Q => slv_reg10(25),
      R => \^sr\(0)
    );
\slv_reg10_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(26),
      Q => slv_reg10(26),
      R => \^sr\(0)
    );
\slv_reg10_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(27),
      Q => slv_reg10(27),
      R => \^sr\(0)
    );
\slv_reg10_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(28),
      Q => slv_reg10(28),
      R => \^sr\(0)
    );
\slv_reg10_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(29),
      Q => slv_reg10(29),
      R => \^sr\(0)
    );
\slv_reg10_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(2),
      Q => slv_reg10(2),
      R => \^sr\(0)
    );
\slv_reg10_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(30),
      Q => slv_reg10(30),
      R => \^sr\(0)
    );
\slv_reg10_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(31),
      Q => slv_reg10(31),
      R => \^sr\(0)
    );
\slv_reg10_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(3),
      Q => slv_reg10(3),
      R => \^sr\(0)
    );
\slv_reg10_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(4),
      Q => slv_reg10(4),
      R => \^sr\(0)
    );
\slv_reg10_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(5),
      Q => slv_reg10(5),
      R => \^sr\(0)
    );
\slv_reg10_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(6),
      Q => slv_reg10(6),
      R => \^sr\(0)
    );
\slv_reg10_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(7),
      Q => slv_reg10(7),
      R => \^sr\(0)
    );
\slv_reg10_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(8),
      Q => slv_reg10(8),
      R => \^sr\(0)
    );
\slv_reg10_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => D(9),
      Q => slv_reg10(9),
      R => \^sr\(0)
    );
\slv_reg11_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(0),
      Q => slv_reg11(0),
      R => \^sr\(0)
    );
\slv_reg11_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(10),
      Q => slv_reg11(10),
      R => \^sr\(0)
    );
\slv_reg11_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(11),
      Q => slv_reg11(11),
      R => \^sr\(0)
    );
\slv_reg11_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(12),
      Q => slv_reg11(12),
      R => \^sr\(0)
    );
\slv_reg11_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(13),
      Q => slv_reg11(13),
      R => \^sr\(0)
    );
\slv_reg11_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(14),
      Q => slv_reg11(14),
      R => \^sr\(0)
    );
\slv_reg11_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(15),
      Q => slv_reg11(15),
      R => \^sr\(0)
    );
\slv_reg11_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(16),
      Q => slv_reg11(16),
      R => \^sr\(0)
    );
\slv_reg11_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(17),
      Q => slv_reg11(17),
      R => \^sr\(0)
    );
\slv_reg11_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(18),
      Q => slv_reg11(18),
      R => \^sr\(0)
    );
\slv_reg11_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(19),
      Q => slv_reg11(19),
      R => \^sr\(0)
    );
\slv_reg11_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(1),
      Q => slv_reg11(1),
      R => \^sr\(0)
    );
\slv_reg11_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(20),
      Q => slv_reg11(20),
      R => \^sr\(0)
    );
\slv_reg11_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(21),
      Q => slv_reg11(21),
      R => \^sr\(0)
    );
\slv_reg11_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(22),
      Q => slv_reg11(22),
      R => \^sr\(0)
    );
\slv_reg11_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(23),
      Q => slv_reg11(23),
      R => \^sr\(0)
    );
\slv_reg11_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(24),
      Q => slv_reg11(24),
      R => \^sr\(0)
    );
\slv_reg11_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(25),
      Q => slv_reg11(25),
      R => \^sr\(0)
    );
\slv_reg11_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(26),
      Q => slv_reg11(26),
      R => \^sr\(0)
    );
\slv_reg11_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(27),
      Q => slv_reg11(27),
      R => \^sr\(0)
    );
\slv_reg11_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(28),
      Q => slv_reg11(28),
      R => \^sr\(0)
    );
\slv_reg11_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(29),
      Q => slv_reg11(29),
      R => \^sr\(0)
    );
\slv_reg11_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(2),
      Q => slv_reg11(2),
      R => \^sr\(0)
    );
\slv_reg11_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(30),
      Q => slv_reg11(30),
      R => \^sr\(0)
    );
\slv_reg11_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(31),
      Q => slv_reg11(31),
      R => \^sr\(0)
    );
\slv_reg11_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(3),
      Q => slv_reg11(3),
      R => \^sr\(0)
    );
\slv_reg11_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(4),
      Q => slv_reg11(4),
      R => \^sr\(0)
    );
\slv_reg11_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(5),
      Q => slv_reg11(5),
      R => \^sr\(0)
    );
\slv_reg11_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(6),
      Q => slv_reg11(6),
      R => \^sr\(0)
    );
\slv_reg11_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(7),
      Q => slv_reg11(7),
      R => \^sr\(0)
    );
\slv_reg11_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(8),
      Q => slv_reg11(8),
      R => \^sr\(0)
    );
\slv_reg11_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg11_reg[31]_0\(9),
      Q => slv_reg11(9),
      R => \^sr\(0)
    );
\slv_reg12_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(0),
      Q => slv_reg12(0),
      R => \^sr\(0)
    );
\slv_reg12_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(10),
      Q => slv_reg12(10),
      R => \^sr\(0)
    );
\slv_reg12_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(11),
      Q => slv_reg12(11),
      R => \^sr\(0)
    );
\slv_reg12_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(12),
      Q => slv_reg12(12),
      R => \^sr\(0)
    );
\slv_reg12_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(13),
      Q => slv_reg12(13),
      R => \^sr\(0)
    );
\slv_reg12_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(14),
      Q => slv_reg12(14),
      R => \^sr\(0)
    );
\slv_reg12_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(15),
      Q => slv_reg12(15),
      R => \^sr\(0)
    );
\slv_reg12_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(16),
      Q => slv_reg12(16),
      R => \^sr\(0)
    );
\slv_reg12_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(17),
      Q => slv_reg12(17),
      R => \^sr\(0)
    );
\slv_reg12_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(18),
      Q => slv_reg12(18),
      R => \^sr\(0)
    );
\slv_reg12_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(19),
      Q => slv_reg12(19),
      R => \^sr\(0)
    );
\slv_reg12_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(1),
      Q => slv_reg12(1),
      R => \^sr\(0)
    );
\slv_reg12_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(20),
      Q => slv_reg12(20),
      R => \^sr\(0)
    );
\slv_reg12_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(21),
      Q => slv_reg12(21),
      R => \^sr\(0)
    );
\slv_reg12_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(22),
      Q => slv_reg12(22),
      R => \^sr\(0)
    );
\slv_reg12_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(23),
      Q => slv_reg12(23),
      R => \^sr\(0)
    );
\slv_reg12_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(24),
      Q => slv_reg12(24),
      R => \^sr\(0)
    );
\slv_reg12_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(25),
      Q => slv_reg12(25),
      R => \^sr\(0)
    );
\slv_reg12_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(26),
      Q => slv_reg12(26),
      R => \^sr\(0)
    );
\slv_reg12_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(27),
      Q => slv_reg12(27),
      R => \^sr\(0)
    );
\slv_reg12_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(28),
      Q => slv_reg12(28),
      R => \^sr\(0)
    );
\slv_reg12_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(29),
      Q => slv_reg12(29),
      R => \^sr\(0)
    );
\slv_reg12_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(2),
      Q => slv_reg12(2),
      R => \^sr\(0)
    );
\slv_reg12_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(30),
      Q => slv_reg12(30),
      R => \^sr\(0)
    );
\slv_reg12_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(31),
      Q => slv_reg12(31),
      R => \^sr\(0)
    );
\slv_reg12_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(3),
      Q => slv_reg12(3),
      R => \^sr\(0)
    );
\slv_reg12_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(4),
      Q => slv_reg12(4),
      R => \^sr\(0)
    );
\slv_reg12_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(5),
      Q => slv_reg12(5),
      R => \^sr\(0)
    );
\slv_reg12_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(6),
      Q => slv_reg12(6),
      R => \^sr\(0)
    );
\slv_reg12_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(7),
      Q => slv_reg12(7),
      R => \^sr\(0)
    );
\slv_reg12_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(8),
      Q => slv_reg12(8),
      R => \^sr\(0)
    );
\slv_reg12_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg12_reg[31]_0\(9),
      Q => slv_reg12(9),
      R => \^sr\(0)
    );
\slv_reg13_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(0),
      Q => slv_reg13(0),
      R => \^sr\(0)
    );
\slv_reg13_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(10),
      Q => slv_reg13(10),
      R => \^sr\(0)
    );
\slv_reg13_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(11),
      Q => slv_reg13(11),
      R => \^sr\(0)
    );
\slv_reg13_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(12),
      Q => slv_reg13(12),
      R => \^sr\(0)
    );
\slv_reg13_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(13),
      Q => slv_reg13(13),
      R => \^sr\(0)
    );
\slv_reg13_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(14),
      Q => slv_reg13(14),
      R => \^sr\(0)
    );
\slv_reg13_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(15),
      Q => slv_reg13(15),
      R => \^sr\(0)
    );
\slv_reg13_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(16),
      Q => slv_reg13(16),
      R => \^sr\(0)
    );
\slv_reg13_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(17),
      Q => slv_reg13(17),
      R => \^sr\(0)
    );
\slv_reg13_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(18),
      Q => slv_reg13(18),
      R => \^sr\(0)
    );
\slv_reg13_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(19),
      Q => slv_reg13(19),
      R => \^sr\(0)
    );
\slv_reg13_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(1),
      Q => slv_reg13(1),
      R => \^sr\(0)
    );
\slv_reg13_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(20),
      Q => slv_reg13(20),
      R => \^sr\(0)
    );
\slv_reg13_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(21),
      Q => slv_reg13(21),
      R => \^sr\(0)
    );
\slv_reg13_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(22),
      Q => slv_reg13(22),
      R => \^sr\(0)
    );
\slv_reg13_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(23),
      Q => slv_reg13(23),
      R => \^sr\(0)
    );
\slv_reg13_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(24),
      Q => slv_reg13(24),
      R => \^sr\(0)
    );
\slv_reg13_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(25),
      Q => slv_reg13(25),
      R => \^sr\(0)
    );
\slv_reg13_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(26),
      Q => slv_reg13(26),
      R => \^sr\(0)
    );
\slv_reg13_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(27),
      Q => slv_reg13(27),
      R => \^sr\(0)
    );
\slv_reg13_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(28),
      Q => slv_reg13(28),
      R => \^sr\(0)
    );
\slv_reg13_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(29),
      Q => slv_reg13(29),
      R => \^sr\(0)
    );
\slv_reg13_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(2),
      Q => slv_reg13(2),
      R => \^sr\(0)
    );
\slv_reg13_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(30),
      Q => slv_reg13(30),
      R => \^sr\(0)
    );
\slv_reg13_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(31),
      Q => slv_reg13(31),
      R => \^sr\(0)
    );
\slv_reg13_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(3),
      Q => slv_reg13(3),
      R => \^sr\(0)
    );
\slv_reg13_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(4),
      Q => slv_reg13(4),
      R => \^sr\(0)
    );
\slv_reg13_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(5),
      Q => slv_reg13(5),
      R => \^sr\(0)
    );
\slv_reg13_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(6),
      Q => slv_reg13(6),
      R => \^sr\(0)
    );
\slv_reg13_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(7),
      Q => slv_reg13(7),
      R => \^sr\(0)
    );
\slv_reg13_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(8),
      Q => slv_reg13(8),
      R => \^sr\(0)
    );
\slv_reg13_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg13_reg[31]_0\(9),
      Q => slv_reg13(9),
      R => \^sr\(0)
    );
\slv_reg14_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(0),
      Q => slv_reg14(0),
      R => \^sr\(0)
    );
\slv_reg14_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(10),
      Q => slv_reg14(10),
      R => \^sr\(0)
    );
\slv_reg14_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(11),
      Q => slv_reg14(11),
      R => \^sr\(0)
    );
\slv_reg14_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(12),
      Q => slv_reg14(12),
      R => \^sr\(0)
    );
\slv_reg14_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(13),
      Q => slv_reg14(13),
      R => \^sr\(0)
    );
\slv_reg14_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(14),
      Q => slv_reg14(14),
      R => \^sr\(0)
    );
\slv_reg14_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(15),
      Q => slv_reg14(15),
      R => \^sr\(0)
    );
\slv_reg14_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(16),
      Q => slv_reg14(16),
      R => \^sr\(0)
    );
\slv_reg14_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(17),
      Q => slv_reg14(17),
      R => \^sr\(0)
    );
\slv_reg14_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(18),
      Q => slv_reg14(18),
      R => \^sr\(0)
    );
\slv_reg14_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(19),
      Q => slv_reg14(19),
      R => \^sr\(0)
    );
\slv_reg14_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(1),
      Q => slv_reg14(1),
      R => \^sr\(0)
    );
\slv_reg14_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(20),
      Q => slv_reg14(20),
      R => \^sr\(0)
    );
\slv_reg14_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(21),
      Q => slv_reg14(21),
      R => \^sr\(0)
    );
\slv_reg14_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(22),
      Q => slv_reg14(22),
      R => \^sr\(0)
    );
\slv_reg14_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(23),
      Q => slv_reg14(23),
      R => \^sr\(0)
    );
\slv_reg14_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(24),
      Q => slv_reg14(24),
      R => \^sr\(0)
    );
\slv_reg14_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(25),
      Q => slv_reg14(25),
      R => \^sr\(0)
    );
\slv_reg14_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(26),
      Q => slv_reg14(26),
      R => \^sr\(0)
    );
\slv_reg14_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(27),
      Q => slv_reg14(27),
      R => \^sr\(0)
    );
\slv_reg14_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(28),
      Q => slv_reg14(28),
      R => \^sr\(0)
    );
\slv_reg14_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(29),
      Q => slv_reg14(29),
      R => \^sr\(0)
    );
\slv_reg14_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(2),
      Q => slv_reg14(2),
      R => \^sr\(0)
    );
\slv_reg14_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(30),
      Q => slv_reg14(30),
      R => \^sr\(0)
    );
\slv_reg14_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(31),
      Q => slv_reg14(31),
      R => \^sr\(0)
    );
\slv_reg14_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(3),
      Q => slv_reg14(3),
      R => \^sr\(0)
    );
\slv_reg14_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(4),
      Q => slv_reg14(4),
      R => \^sr\(0)
    );
\slv_reg14_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(5),
      Q => slv_reg14(5),
      R => \^sr\(0)
    );
\slv_reg14_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(6),
      Q => slv_reg14(6),
      R => \^sr\(0)
    );
\slv_reg14_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(7),
      Q => slv_reg14(7),
      R => \^sr\(0)
    );
\slv_reg14_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(8),
      Q => slv_reg14(8),
      R => \^sr\(0)
    );
\slv_reg14_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg14_reg[31]_0\(9),
      Q => slv_reg14(9),
      R => \^sr\(0)
    );
\slv_reg15_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(0),
      Q => slv_reg15(0),
      R => \^sr\(0)
    );
\slv_reg15_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(10),
      Q => slv_reg15(10),
      R => \^sr\(0)
    );
\slv_reg15_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(11),
      Q => slv_reg15(11),
      R => \^sr\(0)
    );
\slv_reg15_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(12),
      Q => slv_reg15(12),
      R => \^sr\(0)
    );
\slv_reg15_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(13),
      Q => slv_reg15(13),
      R => \^sr\(0)
    );
\slv_reg15_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(14),
      Q => slv_reg15(14),
      R => \^sr\(0)
    );
\slv_reg15_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(15),
      Q => slv_reg15(15),
      R => \^sr\(0)
    );
\slv_reg15_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(16),
      Q => slv_reg15(16),
      R => \^sr\(0)
    );
\slv_reg15_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(17),
      Q => slv_reg15(17),
      R => \^sr\(0)
    );
\slv_reg15_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(18),
      Q => slv_reg15(18),
      R => \^sr\(0)
    );
\slv_reg15_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(19),
      Q => slv_reg15(19),
      R => \^sr\(0)
    );
\slv_reg15_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(1),
      Q => slv_reg15(1),
      R => \^sr\(0)
    );
\slv_reg15_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(20),
      Q => slv_reg15(20),
      R => \^sr\(0)
    );
\slv_reg15_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(21),
      Q => slv_reg15(21),
      R => \^sr\(0)
    );
\slv_reg15_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(22),
      Q => slv_reg15(22),
      R => \^sr\(0)
    );
\slv_reg15_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(23),
      Q => slv_reg15(23),
      R => \^sr\(0)
    );
\slv_reg15_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(24),
      Q => slv_reg15(24),
      R => \^sr\(0)
    );
\slv_reg15_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(25),
      Q => slv_reg15(25),
      R => \^sr\(0)
    );
\slv_reg15_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(26),
      Q => slv_reg15(26),
      R => \^sr\(0)
    );
\slv_reg15_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(27),
      Q => slv_reg15(27),
      R => \^sr\(0)
    );
\slv_reg15_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(28),
      Q => slv_reg15(28),
      R => \^sr\(0)
    );
\slv_reg15_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(29),
      Q => slv_reg15(29),
      R => \^sr\(0)
    );
\slv_reg15_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(2),
      Q => slv_reg15(2),
      R => \^sr\(0)
    );
\slv_reg15_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(30),
      Q => slv_reg15(30),
      R => \^sr\(0)
    );
\slv_reg15_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(31),
      Q => slv_reg15(31),
      R => \^sr\(0)
    );
\slv_reg15_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(3),
      Q => slv_reg15(3),
      R => \^sr\(0)
    );
\slv_reg15_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(4),
      Q => slv_reg15(4),
      R => \^sr\(0)
    );
\slv_reg15_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(5),
      Q => slv_reg15(5),
      R => \^sr\(0)
    );
\slv_reg15_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(6),
      Q => slv_reg15(6),
      R => \^sr\(0)
    );
\slv_reg15_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(7),
      Q => slv_reg15(7),
      R => \^sr\(0)
    );
\slv_reg15_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(8),
      Q => slv_reg15(8),
      R => \^sr\(0)
    );
\slv_reg15_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => \slv_reg15_reg[31]_0\(9),
      Q => slv_reg15(9),
      R => \^sr\(0)
    );
\slv_reg2_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => PPM_capture_done,
      Q => slv_reg2(0),
      R => \^sr\(0)
    );
\slv_reg3_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => '1',
      D => PPM_generator_done,
      Q => slv_reg3(0),
      R => \^sr\(0)
    );
\slv_reg4[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(1),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(2),
      O => \slv_reg4[15]_i_1_n_0\
    );
\slv_reg4[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(2),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(2),
      O => \slv_reg4[23]_i_1_n_0\
    );
\slv_reg4[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(3),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(2),
      O => \slv_reg4[31]_i_1_n_0\
    );
\slv_reg4[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(0),
      I2 => p_0_in(3),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(2),
      O => \slv_reg4[7]_i_1_n_0\
    );
\slv_reg4_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg4(0),
      R => \^sr\(0)
    );
\slv_reg4_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => slv_reg4(10),
      R => \^sr\(0)
    );
\slv_reg4_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => slv_reg4(11),
      R => \^sr\(0)
    );
\slv_reg4_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => slv_reg4(12),
      R => \^sr\(0)
    );
\slv_reg4_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => slv_reg4(13),
      R => \^sr\(0)
    );
\slv_reg4_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => slv_reg4(14),
      R => \^sr\(0)
    );
\slv_reg4_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => slv_reg4(15),
      R => \^sr\(0)
    );
\slv_reg4_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => slv_reg4(16),
      R => \^sr\(0)
    );
\slv_reg4_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => slv_reg4(17),
      R => \^sr\(0)
    );
\slv_reg4_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => slv_reg4(18),
      R => \^sr\(0)
    );
\slv_reg4_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => slv_reg4(19),
      R => \^sr\(0)
    );
\slv_reg4_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg4(1),
      R => \^sr\(0)
    );
\slv_reg4_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => slv_reg4(20),
      R => \^sr\(0)
    );
\slv_reg4_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => slv_reg4(21),
      R => \^sr\(0)
    );
\slv_reg4_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => slv_reg4(22),
      R => \^sr\(0)
    );
\slv_reg4_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => slv_reg4(23),
      R => \^sr\(0)
    );
\slv_reg4_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => slv_reg4(24),
      R => \^sr\(0)
    );
\slv_reg4_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => slv_reg4(25),
      R => \^sr\(0)
    );
\slv_reg4_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => slv_reg4(26),
      R => \^sr\(0)
    );
\slv_reg4_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => slv_reg4(27),
      R => \^sr\(0)
    );
\slv_reg4_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => slv_reg4(28),
      R => \^sr\(0)
    );
\slv_reg4_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => slv_reg4(29),
      R => \^sr\(0)
    );
\slv_reg4_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg4(2),
      R => \^sr\(0)
    );
\slv_reg4_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => slv_reg4(30),
      R => \^sr\(0)
    );
\slv_reg4_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => slv_reg4(31),
      R => \^sr\(0)
    );
\slv_reg4_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg4(3),
      R => \^sr\(0)
    );
\slv_reg4_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg4(4),
      R => \^sr\(0)
    );
\slv_reg4_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg4(5),
      R => \^sr\(0)
    );
\slv_reg4_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg4(6),
      R => \^sr\(0)
    );
\slv_reg4_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg4(7),
      R => \^sr\(0)
    );
\slv_reg4_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg4(8),
      R => \^sr\(0)
    );
\slv_reg4_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg4[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => slv_reg4(9),
      R => \^sr\(0)
    );
\slv_reg5[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(1),
      I2 => p_0_in(0),
      I3 => p_0_in(2),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg5[15]_i_1_n_0\
    );
\slv_reg5[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(2),
      I2 => p_0_in(0),
      I3 => p_0_in(2),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg5[23]_i_1_n_0\
    );
\slv_reg5[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(3),
      I2 => p_0_in(0),
      I3 => p_0_in(2),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg5[31]_i_1_n_0\
    );
\slv_reg5[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(0),
      I2 => p_0_in(0),
      I3 => p_0_in(2),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg5[7]_i_1_n_0\
    );
\slv_reg5_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg5(0),
      R => \^sr\(0)
    );
\slv_reg5_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => slv_reg5(10),
      R => \^sr\(0)
    );
\slv_reg5_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => slv_reg5(11),
      R => \^sr\(0)
    );
\slv_reg5_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => slv_reg5(12),
      R => \^sr\(0)
    );
\slv_reg5_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => slv_reg5(13),
      R => \^sr\(0)
    );
\slv_reg5_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => slv_reg5(14),
      R => \^sr\(0)
    );
\slv_reg5_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => slv_reg5(15),
      R => \^sr\(0)
    );
\slv_reg5_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => slv_reg5(16),
      R => \^sr\(0)
    );
\slv_reg5_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => slv_reg5(17),
      R => \^sr\(0)
    );
\slv_reg5_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => slv_reg5(18),
      R => \^sr\(0)
    );
\slv_reg5_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => slv_reg5(19),
      R => \^sr\(0)
    );
\slv_reg5_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg5(1),
      R => \^sr\(0)
    );
\slv_reg5_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => slv_reg5(20),
      R => \^sr\(0)
    );
\slv_reg5_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => slv_reg5(21),
      R => \^sr\(0)
    );
\slv_reg5_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => slv_reg5(22),
      R => \^sr\(0)
    );
\slv_reg5_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => slv_reg5(23),
      R => \^sr\(0)
    );
\slv_reg5_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => slv_reg5(24),
      R => \^sr\(0)
    );
\slv_reg5_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => slv_reg5(25),
      R => \^sr\(0)
    );
\slv_reg5_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => slv_reg5(26),
      R => \^sr\(0)
    );
\slv_reg5_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => slv_reg5(27),
      R => \^sr\(0)
    );
\slv_reg5_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => slv_reg5(28),
      R => \^sr\(0)
    );
\slv_reg5_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => slv_reg5(29),
      R => \^sr\(0)
    );
\slv_reg5_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg5(2),
      R => \^sr\(0)
    );
\slv_reg5_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => slv_reg5(30),
      R => \^sr\(0)
    );
\slv_reg5_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => slv_reg5(31),
      R => \^sr\(0)
    );
\slv_reg5_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg5(3),
      R => \^sr\(0)
    );
\slv_reg5_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg5(4),
      R => \^sr\(0)
    );
\slv_reg5_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg5(5),
      R => \^sr\(0)
    );
\slv_reg5_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg5(6),
      R => \^sr\(0)
    );
\slv_reg5_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg5(7),
      R => \^sr\(0)
    );
\slv_reg5_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg5(8),
      R => \^sr\(0)
    );
\slv_reg5_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg5[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => slv_reg5(9),
      R => \^sr\(0)
    );
\slv_reg6[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(1),
      I2 => p_0_in(2),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(3),
      O => \slv_reg6[15]_i_1_n_0\
    );
\slv_reg6[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(2),
      I2 => p_0_in(2),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(3),
      O => \slv_reg6[23]_i_1_n_0\
    );
\slv_reg6[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(3),
      I2 => p_0_in(2),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(3),
      O => \slv_reg6[31]_i_1_n_0\
    );
\slv_reg6[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => s00_axi_wstrb(0),
      I2 => p_0_in(2),
      I3 => p_0_in(1),
      I4 => p_0_in(0),
      I5 => p_0_in(3),
      O => \slv_reg6[7]_i_1_n_0\
    );
\slv_reg6_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg6(0),
      R => \^sr\(0)
    );
\slv_reg6_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => slv_reg6(10),
      R => \^sr\(0)
    );
\slv_reg6_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => slv_reg6(11),
      R => \^sr\(0)
    );
\slv_reg6_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => slv_reg6(12),
      R => \^sr\(0)
    );
\slv_reg6_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => slv_reg6(13),
      R => \^sr\(0)
    );
\slv_reg6_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => slv_reg6(14),
      R => \^sr\(0)
    );
\slv_reg6_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => slv_reg6(15),
      R => \^sr\(0)
    );
\slv_reg6_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => slv_reg6(16),
      R => \^sr\(0)
    );
\slv_reg6_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => slv_reg6(17),
      R => \^sr\(0)
    );
\slv_reg6_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => slv_reg6(18),
      R => \^sr\(0)
    );
\slv_reg6_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => slv_reg6(19),
      R => \^sr\(0)
    );
\slv_reg6_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg6(1),
      R => \^sr\(0)
    );
\slv_reg6_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => slv_reg6(20),
      R => \^sr\(0)
    );
\slv_reg6_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => slv_reg6(21),
      R => \^sr\(0)
    );
\slv_reg6_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => slv_reg6(22),
      R => \^sr\(0)
    );
\slv_reg6_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => slv_reg6(23),
      R => \^sr\(0)
    );
\slv_reg6_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => slv_reg6(24),
      R => \^sr\(0)
    );
\slv_reg6_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => slv_reg6(25),
      R => \^sr\(0)
    );
\slv_reg6_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => slv_reg6(26),
      R => \^sr\(0)
    );
\slv_reg6_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => slv_reg6(27),
      R => \^sr\(0)
    );
\slv_reg6_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => slv_reg6(28),
      R => \^sr\(0)
    );
\slv_reg6_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => slv_reg6(29),
      R => \^sr\(0)
    );
\slv_reg6_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg6(2),
      R => \^sr\(0)
    );
\slv_reg6_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => slv_reg6(30),
      R => \^sr\(0)
    );
\slv_reg6_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => slv_reg6(31),
      R => \^sr\(0)
    );
\slv_reg6_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg6(3),
      R => \^sr\(0)
    );
\slv_reg6_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg6(4),
      R => \^sr\(0)
    );
\slv_reg6_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg6(5),
      R => \^sr\(0)
    );
\slv_reg6_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg6(6),
      R => \^sr\(0)
    );
\slv_reg6_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg6(7),
      R => \^sr\(0)
    );
\slv_reg6_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg6(8),
      R => \^sr\(0)
    );
\slv_reg6_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg6[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => slv_reg6(9),
      R => \^sr\(0)
    );
\slv_reg7[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(2),
      I2 => s00_axi_wstrb(1),
      I3 => p_0_in(0),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg7[15]_i_1_n_0\
    );
\slv_reg7[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(2),
      I2 => s00_axi_wstrb(2),
      I3 => p_0_in(0),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg7[23]_i_1_n_0\
    );
\slv_reg7[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(2),
      I2 => s00_axi_wstrb(3),
      I3 => p_0_in(0),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg7[31]_i_1_n_0\
    );
\slv_reg7[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000080000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(2),
      I2 => s00_axi_wstrb(0),
      I3 => p_0_in(0),
      I4 => p_0_in(1),
      I5 => p_0_in(3),
      O => \slv_reg7[7]_i_1_n_0\
    );
\slv_reg7_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg7(0),
      R => \^sr\(0)
    );
\slv_reg7_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => slv_reg7(10),
      R => \^sr\(0)
    );
\slv_reg7_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => slv_reg7(11),
      R => \^sr\(0)
    );
\slv_reg7_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => slv_reg7(12),
      R => \^sr\(0)
    );
\slv_reg7_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => slv_reg7(13),
      R => \^sr\(0)
    );
\slv_reg7_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => slv_reg7(14),
      R => \^sr\(0)
    );
\slv_reg7_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => slv_reg7(15),
      R => \^sr\(0)
    );
\slv_reg7_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => slv_reg7(16),
      R => \^sr\(0)
    );
\slv_reg7_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => slv_reg7(17),
      R => \^sr\(0)
    );
\slv_reg7_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => slv_reg7(18),
      R => \^sr\(0)
    );
\slv_reg7_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => slv_reg7(19),
      R => \^sr\(0)
    );
\slv_reg7_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg7(1),
      R => \^sr\(0)
    );
\slv_reg7_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => slv_reg7(20),
      R => \^sr\(0)
    );
\slv_reg7_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => slv_reg7(21),
      R => \^sr\(0)
    );
\slv_reg7_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => slv_reg7(22),
      R => \^sr\(0)
    );
\slv_reg7_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => slv_reg7(23),
      R => \^sr\(0)
    );
\slv_reg7_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => slv_reg7(24),
      R => \^sr\(0)
    );
\slv_reg7_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => slv_reg7(25),
      R => \^sr\(0)
    );
\slv_reg7_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => slv_reg7(26),
      R => \^sr\(0)
    );
\slv_reg7_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => slv_reg7(27),
      R => \^sr\(0)
    );
\slv_reg7_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => slv_reg7(28),
      R => \^sr\(0)
    );
\slv_reg7_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => slv_reg7(29),
      R => \^sr\(0)
    );
\slv_reg7_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg7(2),
      R => \^sr\(0)
    );
\slv_reg7_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => slv_reg7(30),
      R => \^sr\(0)
    );
\slv_reg7_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => slv_reg7(31),
      R => \^sr\(0)
    );
\slv_reg7_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg7(3),
      R => \^sr\(0)
    );
\slv_reg7_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg7(4),
      R => \^sr\(0)
    );
\slv_reg7_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg7(5),
      R => \^sr\(0)
    );
\slv_reg7_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg7(6),
      R => \^sr\(0)
    );
\slv_reg7_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg7(7),
      R => \^sr\(0)
    );
\slv_reg7_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg7(8),
      R => \^sr\(0)
    );
\slv_reg7_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg7[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => slv_reg7(9),
      R => \^sr\(0)
    );
\slv_reg8[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(1),
      I3 => p_0_in(0),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(1),
      O => \slv_reg8[15]_i_1_n_0\
    );
\slv_reg8[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(1),
      I3 => p_0_in(0),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(2),
      O => \slv_reg8[23]_i_1_n_0\
    );
\slv_reg8[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(1),
      I3 => p_0_in(0),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(3),
      O => \slv_reg8[31]_i_1_n_0\
    );
\slv_reg8[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(1),
      I3 => p_0_in(0),
      I4 => p_0_in(2),
      I5 => s00_axi_wstrb(0),
      O => \slv_reg8[7]_i_1_n_0\
    );
\slv_reg8_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg8(0),
      R => \^sr\(0)
    );
\slv_reg8_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => slv_reg8(10),
      R => \^sr\(0)
    );
\slv_reg8_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => slv_reg8(11),
      R => \^sr\(0)
    );
\slv_reg8_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => slv_reg8(12),
      R => \^sr\(0)
    );
\slv_reg8_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => slv_reg8(13),
      R => \^sr\(0)
    );
\slv_reg8_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => slv_reg8(14),
      R => \^sr\(0)
    );
\slv_reg8_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => slv_reg8(15),
      R => \^sr\(0)
    );
\slv_reg8_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => slv_reg8(16),
      R => \^sr\(0)
    );
\slv_reg8_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => slv_reg8(17),
      R => \^sr\(0)
    );
\slv_reg8_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => slv_reg8(18),
      R => \^sr\(0)
    );
\slv_reg8_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => slv_reg8(19),
      R => \^sr\(0)
    );
\slv_reg8_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg8(1),
      R => \^sr\(0)
    );
\slv_reg8_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => slv_reg8(20),
      R => \^sr\(0)
    );
\slv_reg8_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => slv_reg8(21),
      R => \^sr\(0)
    );
\slv_reg8_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => slv_reg8(22),
      R => \^sr\(0)
    );
\slv_reg8_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => slv_reg8(23),
      R => \^sr\(0)
    );
\slv_reg8_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => slv_reg8(24),
      R => \^sr\(0)
    );
\slv_reg8_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => slv_reg8(25),
      R => \^sr\(0)
    );
\slv_reg8_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => slv_reg8(26),
      R => \^sr\(0)
    );
\slv_reg8_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => slv_reg8(27),
      R => \^sr\(0)
    );
\slv_reg8_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => slv_reg8(28),
      R => \^sr\(0)
    );
\slv_reg8_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => slv_reg8(29),
      R => \^sr\(0)
    );
\slv_reg8_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg8(2),
      R => \^sr\(0)
    );
\slv_reg8_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => slv_reg8(30),
      R => \^sr\(0)
    );
\slv_reg8_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => slv_reg8(31),
      R => \^sr\(0)
    );
\slv_reg8_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg8(3),
      R => \^sr\(0)
    );
\slv_reg8_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg8(4),
      R => \^sr\(0)
    );
\slv_reg8_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg8(5),
      R => \^sr\(0)
    );
\slv_reg8_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg8(6),
      R => \^sr\(0)
    );
\slv_reg8_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg8(7),
      R => \^sr\(0)
    );
\slv_reg8_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg8(8),
      R => \^sr\(0)
    );
\slv_reg8_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg8[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => slv_reg8(9),
      R => \^sr\(0)
    );
\slv_reg9[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(0),
      I3 => s00_axi_wstrb(1),
      I4 => p_0_in(1),
      I5 => p_0_in(2),
      O => \slv_reg9[15]_i_1_n_0\
    );
\slv_reg9[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(0),
      I3 => s00_axi_wstrb(2),
      I4 => p_0_in(1),
      I5 => p_0_in(2),
      O => \slv_reg9[23]_i_1_n_0\
    );
\slv_reg9[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(0),
      I3 => s00_axi_wstrb(3),
      I4 => p_0_in(1),
      I5 => p_0_in(2),
      O => \slv_reg9[31]_i_1_n_0\
    );
\slv_reg9[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \slv_reg_wren__2\,
      I1 => p_0_in(3),
      I2 => p_0_in(0),
      I3 => s00_axi_wstrb(0),
      I4 => p_0_in(1),
      I5 => p_0_in(2),
      O => \slv_reg9[7]_i_1_n_0\
    );
\slv_reg9_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(0),
      Q => slv_reg9(0),
      R => \^sr\(0)
    );
\slv_reg9_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(10),
      Q => slv_reg9(10),
      R => \^sr\(0)
    );
\slv_reg9_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(11),
      Q => slv_reg9(11),
      R => \^sr\(0)
    );
\slv_reg9_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(12),
      Q => slv_reg9(12),
      R => \^sr\(0)
    );
\slv_reg9_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(13),
      Q => slv_reg9(13),
      R => \^sr\(0)
    );
\slv_reg9_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(14),
      Q => slv_reg9(14),
      R => \^sr\(0)
    );
\slv_reg9_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(15),
      Q => slv_reg9(15),
      R => \^sr\(0)
    );
\slv_reg9_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(16),
      Q => slv_reg9(16),
      R => \^sr\(0)
    );
\slv_reg9_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(17),
      Q => slv_reg9(17),
      R => \^sr\(0)
    );
\slv_reg9_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(18),
      Q => slv_reg9(18),
      R => \^sr\(0)
    );
\slv_reg9_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(19),
      Q => slv_reg9(19),
      R => \^sr\(0)
    );
\slv_reg9_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(1),
      Q => slv_reg9(1),
      R => \^sr\(0)
    );
\slv_reg9_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(20),
      Q => slv_reg9(20),
      R => \^sr\(0)
    );
\slv_reg9_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(21),
      Q => slv_reg9(21),
      R => \^sr\(0)
    );
\slv_reg9_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(22),
      Q => slv_reg9(22),
      R => \^sr\(0)
    );
\slv_reg9_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[23]_i_1_n_0\,
      D => s00_axi_wdata(23),
      Q => slv_reg9(23),
      R => \^sr\(0)
    );
\slv_reg9_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(24),
      Q => slv_reg9(24),
      R => \^sr\(0)
    );
\slv_reg9_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(25),
      Q => slv_reg9(25),
      R => \^sr\(0)
    );
\slv_reg9_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(26),
      Q => slv_reg9(26),
      R => \^sr\(0)
    );
\slv_reg9_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(27),
      Q => slv_reg9(27),
      R => \^sr\(0)
    );
\slv_reg9_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(28),
      Q => slv_reg9(28),
      R => \^sr\(0)
    );
\slv_reg9_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(29),
      Q => slv_reg9(29),
      R => \^sr\(0)
    );
\slv_reg9_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(2),
      Q => slv_reg9(2),
      R => \^sr\(0)
    );
\slv_reg9_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(30),
      Q => slv_reg9(30),
      R => \^sr\(0)
    );
\slv_reg9_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[31]_i_1_n_0\,
      D => s00_axi_wdata(31),
      Q => slv_reg9(31),
      R => \^sr\(0)
    );
\slv_reg9_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(3),
      Q => slv_reg9(3),
      R => \^sr\(0)
    );
\slv_reg9_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(4),
      Q => slv_reg9(4),
      R => \^sr\(0)
    );
\slv_reg9_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(5),
      Q => slv_reg9(5),
      R => \^sr\(0)
    );
\slv_reg9_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(6),
      Q => slv_reg9(6),
      R => \^sr\(0)
    );
\slv_reg9_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[7]_i_1_n_0\,
      D => s00_axi_wdata(7),
      Q => slv_reg9(7),
      R => \^sr\(0)
    );
\slv_reg9_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(8),
      Q => slv_reg9(8),
      R => \^sr\(0)
    );
\slv_reg9_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => s00_axi_aclk,
      CE => \slv_reg9[15]_i_1_n_0\,
      D => s00_axi_wdata(9),
      Q => slv_reg9(9),
      R => \^sr\(0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0 is
  port (
    s00_axi_awready : out STD_LOGIC;
    s00_axi_wready : out STD_LOGIC;
    s00_axi_arready : out STD_LOGIC;
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    PPM_Output : out STD_LOGIC;
    s00_axi_rvalid : out STD_LOGIC;
    capture_state_probe : out STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_bvalid : out STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC;
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    PPM_Input : in STD_LOGIC;
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_bready : in STD_LOGIC;
    s00_axi_rready : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0 is
  signal PPM_capture_done : STD_LOGIC;
  signal PPM_capture_input_0 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PPM_capture_input_1 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PPM_capture_input_2 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PPM_capture_input_3 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PPM_capture_input_4 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PPM_capture_input_5 : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PPM_generator_done : STD_LOGIC;
  signal PPM_generator_output_0 : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal PPM_generator_output_1 : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal PPM_generator_output_2 : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal PPM_generator_output_3 : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal PPM_generator_output_4 : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal PPM_generator_output_5 : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal PPM_v1_0_S00_AXI_inst_n_1 : STD_LOGIC;
  signal slv_reg0 : STD_LOGIC_VECTOR ( 0 to 0 );
begin
Capture_PPM_simp_inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_Capture_PPM_simp
     port map (
      PPM_Input => PPM_Input,
      PPM_capture_done => PPM_capture_done,
      Q(31 downto 0) => PPM_capture_input_0(31 downto 0),
      SR(0) => PPM_v1_0_S00_AXI_inst_n_1,
      capture_state_probe(2 downto 0) => capture_state_probe(2 downto 0),
      \out_channel_2_reg[31]_0\(31 downto 0) => PPM_capture_input_1(31 downto 0),
      \out_channel_3_reg[31]_0\(31 downto 0) => PPM_capture_input_2(31 downto 0),
      \out_channel_4_reg[31]_0\(31 downto 0) => PPM_capture_input_3(31 downto 0),
      \out_channel_5_reg[31]_0\(31 downto 0) => PPM_capture_input_4(31 downto 0),
      \out_channel_6_reg[31]_0\(31 downto 0) => PPM_capture_input_5(31 downto 0),
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_aresetn => s00_axi_aresetn
    );
GeneratePPM_inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_GeneratePPM
     port map (
      PPM_Input => PPM_Input,
      PPM_Output => PPM_Output,
      PPM_generator_done => PPM_generator_done,
      Q(0) => slv_reg0(0),
      SR(0) => PPM_v1_0_S00_AXI_inst_n_1,
      \pulse_widths_reg[0][21]_0\(21 downto 0) => PPM_generator_output_0(21 downto 0),
      \pulse_widths_reg[1][21]_0\(21 downto 0) => PPM_generator_output_1(21 downto 0),
      \pulse_widths_reg[2][21]_0\(21 downto 0) => PPM_generator_output_2(21 downto 0),
      \pulse_widths_reg[3][21]_0\(21 downto 0) => PPM_generator_output_3(21 downto 0),
      \pulse_widths_reg[4][21]_0\(21 downto 0) => PPM_generator_output_4(21 downto 0),
      \pulse_widths_reg[5][21]_0\(21 downto 0) => PPM_generator_output_5(21 downto 0),
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_aresetn => s00_axi_aresetn
    );
PPM_v1_0_S00_AXI_inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0_S00_AXI
     port map (
      D(31 downto 0) => PPM_capture_input_0(31 downto 0),
      PPM_capture_done => PPM_capture_done,
      PPM_generator_done => PPM_generator_done,
      \PPM_generator_output_0_reg[21]_0\(21 downto 0) => PPM_generator_output_0(21 downto 0),
      \PPM_generator_output_1_reg[21]_0\(21 downto 0) => PPM_generator_output_1(21 downto 0),
      \PPM_generator_output_2_reg[21]_0\(21 downto 0) => PPM_generator_output_2(21 downto 0),
      \PPM_generator_output_3_reg[21]_0\(21 downto 0) => PPM_generator_output_3(21 downto 0),
      \PPM_generator_output_4_reg[21]_0\(21 downto 0) => PPM_generator_output_4(21 downto 0),
      \PPM_generator_output_5_reg[21]_0\(21 downto 0) => PPM_generator_output_5(21 downto 0),
      Q(0) => slv_reg0(0),
      SR(0) => PPM_v1_0_S00_AXI_inst_n_1,
      axi_arready_reg_0 => s00_axi_arready,
      axi_awready_reg_0 => s00_axi_awready,
      axi_wready_reg_0 => s00_axi_wready,
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_araddr(3 downto 0) => s00_axi_araddr(3 downto 0),
      s00_axi_aresetn => s00_axi_aresetn,
      s00_axi_arvalid => s00_axi_arvalid,
      s00_axi_awaddr(3 downto 0) => s00_axi_awaddr(3 downto 0),
      s00_axi_awvalid => s00_axi_awvalid,
      s00_axi_bready => s00_axi_bready,
      s00_axi_bvalid => s00_axi_bvalid,
      s00_axi_rdata(31 downto 0) => s00_axi_rdata(31 downto 0),
      s00_axi_rready => s00_axi_rready,
      s00_axi_rvalid => s00_axi_rvalid,
      s00_axi_wdata(31 downto 0) => s00_axi_wdata(31 downto 0),
      s00_axi_wstrb(3 downto 0) => s00_axi_wstrb(3 downto 0),
      s00_axi_wvalid => s00_axi_wvalid,
      \slv_reg11_reg[31]_0\(31 downto 0) => PPM_capture_input_1(31 downto 0),
      \slv_reg12_reg[31]_0\(31 downto 0) => PPM_capture_input_2(31 downto 0),
      \slv_reg13_reg[31]_0\(31 downto 0) => PPM_capture_input_3(31 downto 0),
      \slv_reg14_reg[31]_0\(31 downto 0) => PPM_capture_input_4(31 downto 0),
      \slv_reg15_reg[31]_0\(31 downto 0) => PPM_capture_input_5(31 downto 0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    PPM_Input : in STD_LOGIC;
    PPM_Output : out STD_LOGIC;
    capture_state_probe : out STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_aclk : in STD_LOGIC;
    s00_axi_aresetn : in STD_LOGIC;
    s00_axi_awaddr : in STD_LOGIC_VECTOR ( 5 downto 0 );
    s00_axi_awprot : in STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_awvalid : in STD_LOGIC;
    s00_axi_awready : out STD_LOGIC;
    s00_axi_wdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_wstrb : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s00_axi_wvalid : in STD_LOGIC;
    s00_axi_wready : out STD_LOGIC;
    s00_axi_bresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_bvalid : out STD_LOGIC;
    s00_axi_bready : in STD_LOGIC;
    s00_axi_araddr : in STD_LOGIC_VECTOR ( 5 downto 0 );
    s00_axi_arprot : in STD_LOGIC_VECTOR ( 2 downto 0 );
    s00_axi_arvalid : in STD_LOGIC;
    s00_axi_arready : out STD_LOGIC;
    s00_axi_rdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    s00_axi_rresp : out STD_LOGIC_VECTOR ( 1 downto 0 );
    s00_axi_rvalid : out STD_LOGIC;
    s00_axi_rready : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_PPM_0_3,PPM_v1_0,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "PPM_v1_0,Vivado 2020.1";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  attribute x_interface_info : string;
  attribute x_interface_info of s00_axi_aclk : signal is "xilinx.com:signal:clock:1.0 S00_AXI_CLK CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of s00_axi_aclk : signal is "XIL_INTERFACENAME S00_AXI_CLK, ASSOCIATED_BUSIF S00_AXI, ASSOCIATED_RESET s00_axi_aresetn, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.000, CLK_DOMAIN design_1_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0";
  attribute x_interface_info of s00_axi_aresetn : signal is "xilinx.com:signal:reset:1.0 S00_AXI_RST RST";
  attribute x_interface_parameter of s00_axi_aresetn : signal is "XIL_INTERFACENAME S00_AXI_RST, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of s00_axi_arready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARREADY";
  attribute x_interface_info of s00_axi_arvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARVALID";
  attribute x_interface_info of s00_axi_awready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWREADY";
  attribute x_interface_info of s00_axi_awvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWVALID";
  attribute x_interface_info of s00_axi_bready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BREADY";
  attribute x_interface_info of s00_axi_bvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BVALID";
  attribute x_interface_info of s00_axi_rready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RREADY";
  attribute x_interface_info of s00_axi_rvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RVALID";
  attribute x_interface_info of s00_axi_wready : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WREADY";
  attribute x_interface_info of s00_axi_wvalid : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WVALID";
  attribute x_interface_info of s00_axi_araddr : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARADDR";
  attribute x_interface_info of s00_axi_arprot : signal is "xilinx.com:interface:aximm:1.0 S00_AXI ARPROT";
  attribute x_interface_info of s00_axi_awaddr : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWADDR";
  attribute x_interface_parameter of s00_axi_awaddr : signal is "XIL_INTERFACENAME S00_AXI, WIZ_DATA_WIDTH 32, WIZ_NUM_REG 16, SUPPORTS_NARROW_BURST 0, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 100000000, ID_WIDTH 0, ADDR_WIDTH 6, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 1, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, NUM_READ_OUTSTANDING 2, NUM_WRITE_OUTSTANDING 2, MAX_BURST_LENGTH 1, PHASE 0.000, CLK_DOMAIN design_1_processing_system7_0_0_FCLK_CLK0, NUM_READ_THREADS 1, NUM_WRITE_THREADS 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0";
  attribute x_interface_info of s00_axi_awprot : signal is "xilinx.com:interface:aximm:1.0 S00_AXI AWPROT";
  attribute x_interface_info of s00_axi_bresp : signal is "xilinx.com:interface:aximm:1.0 S00_AXI BRESP";
  attribute x_interface_info of s00_axi_rdata : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RDATA";
  attribute x_interface_info of s00_axi_rresp : signal is "xilinx.com:interface:aximm:1.0 S00_AXI RRESP";
  attribute x_interface_info of s00_axi_wdata : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WDATA";
  attribute x_interface_info of s00_axi_wstrb : signal is "xilinx.com:interface:aximm:1.0 S00_AXI WSTRB";
begin
  s00_axi_bresp(1) <= \<const0>\;
  s00_axi_bresp(0) <= \<const0>\;
  s00_axi_rresp(1) <= \<const0>\;
  s00_axi_rresp(0) <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_PPM_v1_0
     port map (
      PPM_Input => PPM_Input,
      PPM_Output => PPM_Output,
      capture_state_probe(2 downto 0) => capture_state_probe(2 downto 0),
      s00_axi_aclk => s00_axi_aclk,
      s00_axi_araddr(3 downto 0) => s00_axi_araddr(5 downto 2),
      s00_axi_aresetn => s00_axi_aresetn,
      s00_axi_arready => s00_axi_arready,
      s00_axi_arvalid => s00_axi_arvalid,
      s00_axi_awaddr(3 downto 0) => s00_axi_awaddr(5 downto 2),
      s00_axi_awready => s00_axi_awready,
      s00_axi_awvalid => s00_axi_awvalid,
      s00_axi_bready => s00_axi_bready,
      s00_axi_bvalid => s00_axi_bvalid,
      s00_axi_rdata(31 downto 0) => s00_axi_rdata(31 downto 0),
      s00_axi_rready => s00_axi_rready,
      s00_axi_rvalid => s00_axi_rvalid,
      s00_axi_wdata(31 downto 0) => s00_axi_wdata(31 downto 0),
      s00_axi_wready => s00_axi_wready,
      s00_axi_wstrb(3 downto 0) => s00_axi_wstrb(3 downto 0),
      s00_axi_wvalid => s00_axi_wvalid
    );
end STRUCTURE;

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity GeneratePPM is
    Port (
        CLK : in std_logic; 
        RESET : in std_logic; 
        slv_reg20, slv_reg21, slv_reg22, slv_reg23, slv_reg24, slv_reg25 : in std_logic_vector(31 downto 0);  
        PPM_Done : out std_logic;
        sw_PPM_Output : out std_logic  
    );
end GeneratePPM;

architecture Behavioral of GeneratePPM is
    -- Define constants
    constant GAP_COUNT : std_logic_vector(15 downto 0) := X"9C40";  -- 40000
    constant TOTAL_COUNT : std_logic_vector(20 downto 0) := "111101000010010000000";  -- 2000000

    type state_type is (IDLE, GAP_LOW, PULSE_HIGH, NEXT_CHANNEL, FRAME_COMPLETE, IDLE_PULSE, IDLE_LOW_PULSE);
    signal PS, NS : state_type;
    
    -- Counters
    signal cycle_counter : std_logic_vector(31 downto 0);
    signal cycle_counter_total : std_logic_vector(31 downto 0);
    signal channel_index : integer range 0 to 5;
    
    -- Array of std_logic_vector
    type pulse_width_array is array(0 to 5) of std_logic_vector(31 downto 0);
    signal pulse_widths : pulse_width_array;
begin
    -- Synchronous state register with synchronous reset
    process(CLK)
    begin
        if rising_edge(CLK) then
            if RESET = '0' then  -- Active low reset
                PS <= IDLE;
            else
                PS <= NS;
            end if;
        end if;
    end process;

    -- Next State Logic
    process(PS, RESET)
    begin
        case PS is
            when IDLE_PULSE =>
                if cycle_counter_total < TOTAL_COUNT then
                    NS <= IDLE_PULSE;
                else
                    NS <= IDLE;
                end if;
            
            when IDLE =>
                if RESET = '0' then 
                    NS <= IDLE;
                else
                    NS <= GAP_LOW;
                end if;

            when IDLE_LOW_PULSE =>
                if cycle_counter >= GAP_COUNT then
                    NS <= IDLE_PULSE;
                else
                    NS <= IDLE_LOW_PULSE;
                end if;

            when GAP_LOW =>
                if cycle_counter >= GAP_COUNT then
                    NS <= PULSE_HIGH;
                else
                    NS <= GAP_LOW;
                end if;

            when PULSE_HIGH =>
                if (cycle_counter - GAP_COUNT) >= pulse_widths(channel_index)(31 downto 0) then
                    if channel_index = 5 then
                        NS <= FRAME_COMPLETE;
                    else
                        NS <= NEXT_CHANNEL;
                    end if;
                else
                    NS <= PULSE_HIGH;
                end if;

            when NEXT_CHANNEL =>
                NS <= GAP_LOW;

            when FRAME_COMPLETE =>
                NS <= IDLE_LOW_PULSE;

            when others =>
                NS <= IDLE;
        end case;
    end process;

    -- Output Logic with synchronous reset
    process(CLK)
    begin
        if rising_edge(CLK) then
            if RESET = '0' then
                cycle_counter <= (others => '0');
                cycle_counter_total <= (others => '0');
                channel_index <= 0;
                sw_PPM_Output <= '1';
                PPM_Done <= '0';
            else
                case PS is
                    when IDLE =>
                        cycle_counter <= (others => '0');
                        channel_index <= 0;
                        sw_PPM_Output <= '1';
                        PPM_Done <= '0';
                        cycle_counter_total <= (others => '0');
                        
                    when IDLE_PULSE =>
                        cycle_counter_total <= cycle_counter_total + 1;
                        sw_PPM_Output <= '1';
                        PPM_Done <= '1';
                        cycle_counter <= (others => '0');
                        channel_index <= 0;

                    when IDLE_LOW_PULSE =>
                        cycle_counter <= cycle_counter + 1;
                        cycle_counter_total <= cycle_counter_total + 1;
                        sw_PPM_Output <= '0';
                        PPM_Done <= '0';

                    when GAP_LOW =>
                        cycle_counter <= cycle_counter + 1;
                        cycle_counter_total <= cycle_counter_total + 1;
                        sw_PPM_Output <= '0';
                        PPM_Done <= '0';

                    when PULSE_HIGH =>
                        cycle_counter <= cycle_counter + 1;
                        cycle_counter_total <= cycle_counter_total + 1;
                        sw_PPM_Output <= '1';
                        PPM_Done <= '0';

                    when NEXT_CHANNEL =>
                        channel_index <= channel_index + 1;
                        cycle_counter <= (others => '0');
                        PPM_Done <= '0';

                    when FRAME_COMPLETE =>
                        cycle_counter <= (others => '0');
                        channel_index <= 0;
                        PPM_Done <= '0';

                    when others =>
                        cycle_counter <= (others => '0');
                end case;
            end if;
        end if;
    end process;

    -- Register updates with synchronous reset
    process(CLK)
    begin
        if rising_edge(CLK) then
            if RESET = '0' then
                pulse_widths <= (others => (others => '0'));
            else
                pulse_widths(0) <= slv_reg20;
                pulse_widths(1) <= slv_reg21;
                pulse_widths(2) <= slv_reg22;
                pulse_widths(3) <= slv_reg23;
                pulse_widths(4) <= slv_reg24;
                pulse_widths(5) <= slv_reg25;
            end if;
        end if;
    end process;

end Behavioral;